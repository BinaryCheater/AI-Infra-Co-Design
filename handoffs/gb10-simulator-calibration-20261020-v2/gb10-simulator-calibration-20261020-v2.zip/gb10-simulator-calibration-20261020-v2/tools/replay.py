"""Replay one archived callable on a GB10, with finite checks and bounded timing."""

import argparse
import contextlib
import json
import os
import signal
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def child(case, mode, output, lock):
    sys.path.insert(0, str(ROOT / "tools/runtime"))
    import worker

    payload = json.loads((ROOT / "cases" / case / f"{mode}-input.json").read_text())
    payload["execution_policy"] = {"allow_overlap": False}
    os.chdir(output)
    with contextlib.redirect_stdout(sys.stderr), worker.gpu_lock(str(lock)):
        result = worker.run(payload)
    result["handoff_replay"] = {
        "mode": mode,
        "scope": "Archived cubin replay"
        if mode == "exact"
        else "Rebuild; binary identity may change",
        "gpu_lock": str(lock),
        "allow_overlap": False,
    }
    print(json.dumps(result))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    parser.add_argument("--mode", choices=["exact", "rebuild"], default="exact")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--gpu-lock",
        type=Path,
        default=Path.home() / ".cache/gb10-calibration/gpu0.lock",
    )
    parser.add_argument("--timeout", type=int, default=360)
    parser.add_argument(
        "--plan",
        action="store_true",
        help="Inspect the command without executing GPU work",
    )
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    source = ROOT / "cases" / args.case / f"{args.mode}-input.json"
    if not source.is_file():
        parser.error("No archived input for this case/mode; see cases/<id>/case.json")
    if args.timeout <= 0:
        parser.error("Timeout must be positive")
    output, lock = args.out.resolve(), args.gpu_lock.expanduser().resolve()
    if args.child:
        child(args.case, args.mode, output, lock)
        return
    command = [
        sys.executable,
        str(Path(__file__).resolve()),
        "--case",
        args.case,
        "--mode",
        args.mode,
        "--out",
        str(output),
        "--gpu-lock",
        str(lock),
        "--timeout",
        str(args.timeout),
        "--child",
    ]
    if args.plan:
        print(
            json.dumps(
                {
                    "command": command,
                    "source": str(source),
                    "timeout_seconds": args.timeout,
                },
                indent=2,
            )
        )
        return
    output.mkdir(parents=True, exist_ok=False)
    lock.parent.mkdir(parents=True, exist_ok=True)
    (output / "replay-input.json").write_bytes(source.read_bytes())
    with (
        (output / "stdout.json").open("w") as stdout,
        (output / "stderr.log").open("w") as stderr,
    ):
        process = subprocess.Popen(
            command, stdout=stdout, stderr=stderr, start_new_session=True
        )
        try:
            code = process.wait(timeout=args.timeout)
            status = "returned" if code == 0 else "worker_failed"
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            code, status = process.returncode, "timeout"
    result = {
        "status": status,
        "returncode": code,
        "timeout_seconds": args.timeout,
        "command": command,
    }
    if status == "returned":
        receipt = json.loads((output / "stdout.json").read_text())
        result["case_statuses"] = [row["status"] for row in receipt["cases"]]
        if any(row["status"] != "measured" for row in receipt["cases"]):
            result["status"] = "not_admitted"
    (output / "execution.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    if result["status"] != "returned":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
