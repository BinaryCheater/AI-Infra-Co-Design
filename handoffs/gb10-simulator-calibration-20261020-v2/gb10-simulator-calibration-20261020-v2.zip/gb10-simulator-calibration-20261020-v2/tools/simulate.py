"""Run a frozen CPU simulation profile against a supplied upstream simulator checkout."""

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))


def run_case(name, upstream, probe):
    from calibration_tools import wrappers

    wrappers.UPSTREAM = upstream
    folder = ROOT / "cases" / name
    profile_path = folder / "simulation-profile.json"
    if probe:
        from calibration_tools.suite_simulate import probe as compatibility_probe

        return compatibility_probe(ROOT / "cases", name)
    profile = json.loads(profile_path.read_text()) if profile_path.exists() else {}
    if profile.get("kind") == "sm-traffic":
        point = wrappers.Point(**profile["point"])
        wrappers.SASS = folder
        result = wrappers.simulate(point)
        result["case_id"] = name
        return result
    if profile.get("kind") == "whole-grid-ws":
        from calibration_tools.whole_ws import simulate

        return simulate(ROOT / "cases", name)
    case = json.loads((folder / "case.json").read_text())
    return {
        "id": name,
        "status": "unsupported_mapping",
        "reason": case["analysis"],
        "scope": "No complete kernel prediction; --probe is a compatibility diagnostic only",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    parser.add_argument("--upstream", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--probe", action="store_true")
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not (ROOT / "cases" / args.case / "case.json").is_file():
        parser.error("Unknown case")
    if not (args.upstream / "agentic/gb10/sim/sm.py").is_file():
        parser.error(
            "Expected an AI-Infra-Co-Design checkout with agentic/gb10/sim/sm.py"
        )
    if args.timeout <= 0:
        parser.error("Timeout must be positive")
    if args.child:
        print(json.dumps(run_case(args.case, args.upstream.resolve(), args.probe)))
        return
    if args.out.exists():
        parser.error("Output already exists; select a new file")
    command = [
        sys.executable,
        str(Path(__file__).resolve()),
        "--case",
        args.case,
        "--upstream",
        str(args.upstream.resolve()),
        "--out",
        str(args.out),
        "--child",
    ]
    if args.probe:
        command.append("--probe")
    try:
        process = subprocess.run(
            command, capture_output=True, text=True, timeout=args.timeout
        )
        result = (
            json.loads(process.stdout)
            if process.returncode == 0
            else {
                "id": args.case,
                "status": "simulator_error",
                "stderr": process.stderr,
                "stdout": process.stdout,
            }
        )
    except subprocess.TimeoutExpired:
        result = {"id": args.case, "status": "timeout", "timeout_seconds": args.timeout}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x") as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2))
    if result.get("status") != "ok":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
