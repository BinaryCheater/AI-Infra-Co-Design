"""Frozen adapters; upstream simulator implementation is supplied separately."""
