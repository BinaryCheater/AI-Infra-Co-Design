"""Bounded SASS probes for every compiled inventory member, with explicit scope.

Unsupported execution structure stays unsupported even if a one-CTA probe emits
cycles. No coefficients are fitted and upstream simulator files are unchanged.
"""

import argparse
import json
import math
import re
import subprocess
import sys
from pathlib import Path

from . import wrappers
from .full_suite import write_new
from .points import POINTS
from .wrappers import Point


def probe(directory, name):
    folder = directory / name
    binary_folder = (
        folder if (folder / "compilation.json").exists() else folder / "repaired"
    )
    compilation = json.loads((binary_folder / "compilation.json").read_text())
    saved = json.loads((folder / "result.json").read_text())
    manifest = json.loads((directory / "inventory.json").read_text())
    row = next(r for r in manifest["targets"] if r["id"] == name)
    c = row["case"]
    evaluation_path = folder / "evaluation-v4.json"
    evaluation = (
        json.loads(evaluation_path.read_text()) if evaluation_path.exists() else {}
    )
    meta = evaluation.get("launch_metadata", compilation["compiler_metadata"])
    entries = meta.get("entries", [])
    symbol = compilation["symbols"][0]
    umodel, sm = wrappers.upstream()
    ins = sm.kernel_sass(binary_folder / "kernel.sass", kernel=symbol)
    from agentic.gb10.sim.sass import main_loop

    lp = main_loop(ins)
    bases = sorted(set(x.base for x in ins))
    info = {
        "id": name,
        "cubin_sha256": compilation["cubin_sha256"],
        "sass_sha256": compilation["sass_sha256"],
        "instructions": len(ins),
        "symbols": compilation["symbols"],
        "opcodes": bases,
        "main_loop": lp,
        "back_edges": [
            (i, x.target)
            for i, x in enumerate(ins)
            if x.base == "BRA" and x.target is not None and x.target < x.addr
        ],
        "timing_gaps": sorted(
            set(bases)
            & {
                "LDS",
                "STS",
                "SHFL",
                "REDUX",
                "CALL",
                "RET",
                "WARPSYNC",
                "ENDCOLLECTIVE",
            }
        ),
        "scope": "Instruction timing approximation; does not execute numerical kernel semantics",
    }
    if len(entries) == 1:
        entry = entries[0]
        ext = entry["launch_extents"]
        block = [int(ext.get("threadIdx." + a, 1)) for a in "xyz"]
        grid_dim = [int(ext.get("blockIdx." + a, 1)) for a in "xyz"]
        threads, grid, shared = (
            math.prod(block),
            math.prod(grid_dim),
            entry.get("dynamic_shared_bytes") or 0,
        )
    else:
        text = (binary_folder / "kernel.cu").read_text()
        threads = int(re.search(r"__launch_bounds__\((\d+)", text)[1])
        grid, grid_dim, shared = 1, [1, 1, 1], 0
        info["launch_scope"] = (
            "One-CTA compatibility probe only; full actual launch unavailable or multikernel"
        )
    info.update(threads=threads, grid=grid, shared=shared)
    assignment = saved.get("assignment", {})
    if "UTMALDG" in bases:
        # Existing WS simulator, actual symbol/threads. Its role/barrier model was
        # written for pipelined GEMM; other structures are only compatibility probes.
        from agentic.gb10.sim.ws import WSSM

        bk = assignment.get("BK", assignment.get("block_K", 64))
        bm = assignment.get("BM", assignment.get("block_M", 128))
        bn = assignment.get("BN", assignment.get("block_N", 128))
        stages = assignment.get("stages", assignment.get("num_stages", 2))
        kt = math.ceil(c.get("K", c.get("L", 4096)) / bk)
        consumers = max(32, threads - 128)
        n_mma = (
            sum(
                x.base in ("HMMA", "IMMA", "QMMA", "OMMA")
                for x in ins[lp[0] : lp[1] + 1]
            )
            if lp
            else 0
        )
        per_kt = bm * bn * bk / (16 * 8 * 16) / (consumers / 32)
        trips = max(1, kt // max(1, round(n_mma / per_kt))) if lp else 1
        machine = WSSM(
            ins,
            threads,
            1,
            trips,
            consumers,
            stages,
            (bm + bn) * bk * 2,
            2,
            kt=kt,
            active_sms=min(48, grid),
            miss_frac=0,
            resident=1,
            grid_blocks=grid,
        )
        limit = 1_000_000
        run = machine.run(limit=limit)
        complete = run["cycles"] < limit - 1 and all(w.done for w in machine.warps)
        info.update(
            status="unsupported_structure",
            probe_completed=complete,
            probe_cycles=run["cycles"],
            unterminated_warps=sum(not w.done for w in machine.warps),
            reason="WS one-CTA probe does not establish whole-grid TMA/persistent/grouped/convolution/attention mapping; no paired prediction admitted",
        )
        return info
    aliases = {"rmsnorm_resident": "rmsnorm"}
    if name in ("softmax", "rmsnorm_resident", "gemv", "w4_gemv", "gqa_decode"):
        from dataclasses import replace

        point = replace(
            POINTS[aliases.get(name, name)],
            name="kernel",
            kernel=symbol,
            threads=threads,
            grid=grid,
            regs=compilation["registers"][0],
            smem=shared,
            measured_us=1.0,
            extra={"grid_dim": tuple(grid_dim), "limit": 40_000_000},
        )
    elif name in ("elementwise_add", "rmsnorm", "softmax_resident"):
        count = c["M"] * c["N"]
        width = 4 if name != "softmax_resident" else 2
        point = Point(
            name="kernel",
            kernel=symbol,
            threads=threads,
            grid=grid,
            regs=compilation["registers"][0],
            measured_us=1.0,
            case=name,
            shape=c,
            reads=count * width * (2 if name == "elementwise_add" else 1),
            writes=count * width,
            reread=count * width if name == "rmsnorm" else 0,
            smem=shared,
            extra={"grid_dim": tuple(grid_dim), "limit": 40_000_000},
            notes="Frozen traffic mapping, no fit. Reduction/shared/shuffle timing gaps remain explicit.",
        )
    else:
        # Try the actual SASS under bounded execution; these loop/stage mappings
        # are not transferable from the five validated family adapters.
        machine = sm.SM(ins, threads, 1, 1, resident=1, grid_blocks=grid)
        limit = 1_000_000
        run = machine.run(limit=limit)
        info.update(
            status="unsupported_structure",
            probe_cycles=run["cycles"],
            probe_completed=run["cycles"] < limit - 1
            and all(w.done for w in machine.warps),
            reason="Requires kernel-specific multi-loop, copy/atomic, reduction or multi-stage callable mapping; one-CTA cycles are not a kernel prediction",
        )
        return info
    wrappers.SASS = binary_folder
    prediction = wrappers.simulate(point)
    prediction.pop("measured_us", None)
    prediction.pop("error_pct", None)
    info.update(
        status=prediction["status"],
        prediction=prediction,
        mapping="Existing five-family adapter"
        if name in ("softmax", "rmsnorm_resident", "gemv", "w4_gemv", "gqa_decode")
        else "New frozen traffic mapping; physical reduction/shared timing not independently calibrated",
    )
    return info


def run(directory, timeout):
    rows = json.loads((directory / "inventory.json").read_text())["targets"]
    for row in rows:
        folder = directory / row["id"]
        target = folder / "simulation-v2.json"
        if target.exists():
            continue
        if row.get("scope") == "composite_graph":
            result = {
                "id": row["id"],
                "status": "unsupported_composite",
                "reason": row["reason"],
            }
        else:
            try:
                proc = subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "knowledge.model.sim_migrate.suite_simulate",
                        "--directory",
                        str(directory),
                        "--one",
                        row["id"],
                    ],
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                )
                result = (
                    json.loads(proc.stdout)
                    if proc.returncode == 0
                    else {
                        "id": row["id"],
                        "status": "simulator_error",
                        "error": proc.stderr[-2400:],
                    }
                )
            except subprocess.TimeoutExpired:
                result = {
                    "id": row["id"],
                    "status": "timeout",
                    "timeout_seconds": timeout,
                }
            except Exception as error:
                result = {
                    "id": row["id"],
                    "status": "probe_setup_failed",
                    "error": str(error),
                }
        write_new(target, result)
        print(row["id"], result["status"], flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--one")
    parser.add_argument("--timeout", type=int, default=90)
    args = parser.parse_args()
    if args.one:
        print(json.dumps(probe(args.directory.resolve(), args.one)))
    else:
        run(args.directory.resolve(), args.timeout)


if __name__ == "__main__":
    main()
