"""Per-kernel case descriptions: one measured receipt each, plus the per-family facts the SM simulator needs.

Every field comes from the kernel-kit receipt (source, config, measured time) or from the kernel source
(grid, bytes per block, which loads re-read). Nothing comes from the measured time.
"""

from __future__ import annotations

from .wrappers import Point

POINTS = {
    "softmax": Point(
        name="softmax",
        kernel="softmax_kernel_kernel",
        threads=128,
        grid=4096 // 2,
        regs=128,
        measured_us=590.8639907836914,
        case="row_softmax 4096x8192 fp16",
        shape={"M": 4096, "N": 8192, "dtype": "fp16"},
        reads=4096 * 8192 * 2,
        writes=4096 * 8192 * 2,
        reread=4096 * 8192 * 2,
        ldg_hit_from=8,
        trips=1,
        miss_frac=1.0,
        notes="2 rows/block x 16384 elems; two passes over X (max+LSE, then exp/normalize from a re-read); "
        "8 LDG.256 per pass, the second 8 hit L1/L2",
    ),
    "rmsnorm": Point(
        name="rmsnorm",
        kernel="rms_norm_kernel",
        threads=128,
        grid=4096,
        regs=77,
        measured_us=1123.4464009602864,
        case="rmsnorm 4096x8192 fp32",
        shape={"M": 4096, "N": 8192, "dtype": "fp32"},
        reads=4096 * 8192 * 4,
        writes=4096 * 8192 * 4,
        trips=1,
        notes="1 row/block (8192 fp32 = 32 KB); one pass, the row stays in 64 registers/thread",
    ),
    "w4_gemv": Point(
        name="w4_gemv",
        kernel="main_kernel",
        threads=32,
        grid=14336 // 2,
        regs=50,
        measured_us=90.76693058013916,
        case="w4a16 gemv 1x14336x4096 int4 weights",
        shape={"M": 1, "N": 14336, "K": 4096, "dtype": "int4 weights / fp16 act"},
        reads=14336 * 4096 // 2,
        writes=14336 * 2,
        reread=14336 // 2 * 16 * 1024,
        ldg_hits=[False, True, False, False, True, True, True, False],
        trips=8,
        notes="32 threads, 2 output rows/block; 4 B of packed int4 per thread per k-step from DRAM, A (8 KB) "
        "re-read from L1 by every block; nibble unpack + FMA, no tensor ops",
    ),
    "gemv": Point(
        name="gemv",
        kernel="get_autotuned_kernel_kernel",
        threads=64,
        grid=14336 // 2,
        regs=48,
        measured_us=495.58080037434894,
        case="gemv 14336x4096 fp16 (BM=2, reduce_threads=32)",
        shape={"M": 14336, "N": 4096, "dtype": "fp16"},
        reads=14336 * 4096 * 2,
        writes=14336 * 2,
        reread=14336 // 2 * 4096 * 2,
        ldg_hits=[True, False],
        trips=16,
        miss_frac=1.0,
        smem=256,
        notes="2 rows of B per block, 16 k-steps; A (8 KB) is re-read by every block from L1/L2, B streams from DRAM",
    ),
    "gqa_decode": Point(
        name="gqa_decode",
        kernel="flashattn_gqa_decode_no_split_kernel",
        threads=128,
        grid=32,
        regs=177,
        measured_us=1104.26025390625,
        case="gqa decode B=4 Hq=32 Hkv=8 L=16384 D=128 fp16",
        shape={"B": 4, "Hq": 32, "Hkv": 8, "L": 16384, "D": 128, "dtype": "fp16"},
        reads=2 * 4 * 8 * 16384 * 128 * 2,
        writes=4 * 32 * 128 * 2,
        miss_frac=1.0,
        smem=49152,
        trips=256,
        extra={"copy_lines": [4] * 32, "ldsm_ways": (1, 1)},
        notes="flash-attention decode, 1 stage, cp.async + ldmatrix + mma; grid (4,8) = (batch, kv-head), 32 CTAs; "
        "each CTA loops over the 256 KV blocks of its own head with no cross-CTA reuse, so the whole stream is "
        "DRAM traffic (miss_frac 1.0); the earlier grid=512 / miss 0.0625 assumed a reuse that does not exist",
    ),
}
