"""Whole-grid WS GEMM probes using measured-library SASS and upstream cache rules.

Only regular nonpersistent GEMM has this mapping. No EXIT guard, coefficients,
or instruction decoder is patched. Incomplete or exceptional runs stay failures.
"""

import argparse
import json
import math
import subprocess
import sys
import time
from pathlib import Path

from . import wrappers
from .full_suite import write_new


def simulate(directory, name):
    wrappers.upstream()
    from agentic.gb10.model import dram_split_kslice
    from agentic.gb10.sim.kernel import dram_clk, wave_dram
    from agentic.gb10.sim.sass import main_loop
    from agentic.gb10.sim.sm import kernel_sass
    from agentic.gb10.sim.ws import WSSM

    folder = directory / name
    compilation = json.loads((folder / "compilation.json").read_text())
    evaluation_path = folder / "evaluation-v5.json"
    if not evaluation_path.exists():
        evaluation_path = folder / "evaluation-v4.json"
    evaluation = json.loads(evaluation_path.read_text())
    bound = json.loads((folder / "bound-library/manifest.json").read_text())
    row = json.loads((folder / "result.json").read_text())
    inventory = json.loads((directory / "inventory.json").read_text())
    case = next(r["case"] for r in inventory["targets"] if r["id"] == name)
    p = row["assignment"]
    h = {
        "block_M": p.get("BM", p.get("block_M")),
        "block_N": p.get("BN", p.get("block_N")),
        "block_K": p.get("BK", p.get("block_K")),
        "num_stages": p.get("stages", p.get("num_stages")),
        "threads": p["threads"],
        "swizzle": p.get("swizzle", 0),
    }
    if len(bound["images"]) != 1:
        raise ValueError("Need exactly one bound CUDA image")
    ins = kernel_sass(
        folder / "bound-library/bound-0.sass", kernel=compilation["symbols"][0]
    )
    entry = evaluation["launch_metadata"]["entries"][0]
    grid = math.prod(
        int(entry["launch_extents"].get("blockIdx." + a, 1)) for a in "xyz"
    )
    threads = math.prod(
        int(entry["launch_extents"].get("threadIdx." + a, 1)) for a in "xyz"
    )
    expected = math.ceil(case["M"] / h["block_M"]) * math.ceil(case["N"] / h["block_N"])
    if expected != grid or threads != h["threads"] + 128:
        raise ValueError("Actual launch differs from regular GEMM mapping")
    kt = math.ceil(case["K"] / h["block_K"])
    lp = main_loop(ins)
    per_kt = (
        h["block_M"] * h["block_N"] * h["block_K"] / (16 * 8 * 16) / (h["threads"] / 32)
    )
    n_mma = (
        sum(x.base in ("HMMA", "IMMA", "QMMA", "OMMA") for x in ins[lp[0] : lp[1] + 1])
        if lp
        else 0
    )
    trips = max(1, kt // max(1, round(n_mma / per_kt))) if lp else 1
    waits = [
        i
        for i, x in enumerate(ins)
        if x.op.startswith("SYNCS.PHASECHK") and "TRYWAIT" in x.op
    ]
    tmas = [i for i, x in enumerate(ins) if x.base == "UTMALDG"]
    before = max(i for i in waits if i < tmas[0])
    after = min((i for i in waits if i > tmas[0]), default=len(ins))
    tma_per = max(1, sum(before < i < after for i in tmas))
    sp = dram_split_kslice(h, case, 48)
    rb = seconds = 0.0
    for wave in sp["waves"]:
        read, duration = wave_dram(h, case, wave, True)
        rb += read
        seconds += duration
    tile = (
        (min(h["block_M"], case["M"]) + min(h["block_N"], case["N"])) * h["block_K"] * 2
    )
    cold = grid * kt * tile
    blocks = math.ceil(grid / 48)
    machine = WSSM(
        ins,
        threads,
        blocks,
        trips,
        h["threads"],
        h["num_stages"],
        tile,
        tma_per,
        kt=kt,
        active_sms=min(48, grid),
        miss_frac=min(1, rb / cold),
        dram_clk_per_512B=dram_clk(rb, seconds, min(48, grid)),
        ctile_bytes=min(h["block_M"], case["M"]) * min(h["block_N"], case["N"]) * 2,
        resident=1,
        grid_blocks=grid,
    )
    limit = 3_000_000 * blocks
    started = time.monotonic()
    run = machine.run(limit=limit)
    complete = (
        run["cycles"] < limit - 1
        and all(w.done for w in machine.warps)
        and machine.next_block >= machine.blocks
    )
    value = 2.6 + run["cycles"] / 2540
    measured = evaluation["fresh_execution"]["latency_us"]
    return {
        "id": name,
        "status": "ok" if complete else "incomplete",
        "sim_us": value if complete else None,
        "measured_us": measured,
        "error_pct": (value / measured - 1) * 100 if complete else None,
        "warps_done": sum(w.done for w in machine.warps),
        "warps": len(machine.warps),
        "cycles": run["cycles"],
        "limit": limit,
        "grid": grid,
        "threads": threads,
        "trips": trips,
        "wall_seconds": time.monotonic() - started,
        "bound_cubin_sha256": bound["images"][0]["sha256"],
        "bound_library_sha256": bound["library_sha256"],
        "cache_scope": "Unchanged upstream regular-GEMM warm wave_dram/dram_split_kslice mapping, not independently calibrated for this binary",
        "known_gaps": "WS role/barrier abstraction, actual compiler launch order versus inferred cache mapping; numerical correctness is from host receipt",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--one")
    args = parser.parse_args()
    if args.one:
        print(json.dumps(simulate(args.directory, args.one)))
        return
    for name in ["gemm", "gemm_basic"]:
        try:
            proc = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "knowledge.model.sim_migrate.whole_ws",
                    "--directory",
                    str(args.directory),
                    "--one",
                    name,
                ],
                capture_output=True,
                text=True,
                timeout=120,
            )
            result = (
                json.loads(proc.stdout)
                if proc.returncode == 0
                else {
                    "id": name,
                    "status": "simulator_error",
                    "error": proc.stderr[-2400:],
                }
            )
        except subprocess.TimeoutExpired:
            result = {"id": name, "status": "timeout", "timeout_seconds": 120}
        write_new(args.directory / name / "whole-ws-v1.json", result)
        print(name, result["status"], result.get("sim_us"), flush=True)


if __name__ == "__main__":
    main()
