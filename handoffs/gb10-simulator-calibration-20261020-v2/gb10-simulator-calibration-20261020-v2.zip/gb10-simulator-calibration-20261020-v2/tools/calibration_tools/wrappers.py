"""Migrate kernel-lab kernels onto the upstream GB10 instruction-level simulator (agentic/gb10/sim).

What is reused vs written here
------------------------------
Reused unchanged, from the upstream clone: `sass.py` (nvdisasm parser and scheduling control bits), `sm.py`
(the simulated SM: issue ports, dependency counters, pipes, LSU/L1/store/DRAM paths, barriers), and its
`gb10.json["sim"]` probe constants. Nothing in this module changes the simulator's numbers.

Written here: one *case description* per kernel family. The simulator models an SM; it has no idea how many
blocks a kernel launches, which of its loads are re-reads, or how much DRAM traffic a block causes. Those are
per-family facts about the kernel, taken from the kernel-lab source that produced the receipt (read from the
receipt's retained `cuda_source`), never from the measured time.

No coefficient is fitted to the measured time. The two numbers that decide the answer (DRAM rate, store rate)
come from the upstream probe constants; the L2 carry-over curve between back-to-back iterations comes from its
`l2_carryover_b2b` probe, which matters because our receipts are timed under CUDA-graph replay.

Reporting convention: `sim_sm_us` is the SASS-driven SM-side time. `bus_us` is the DRAM floor from the same
traffic. `sim_us = launch + max(sim_sm_us, bus_us)`; when bus_us binds the prediction is a bandwidth
calculation and exercises the instruction model only as a lower bound. Both are reported side by side so a
reader can see which one decided.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path

UPSTREAM = Path.home() / "Projects/ai-infra-codesign-ventus"
HERE = Path(__file__).resolve().parent
SASS = HERE / "sass"

CLOCK_GHZ = 2.54  # upstream `F` in sim/kernel.py, from its clock probe
LAUNCH_US = 2.6  # upstream launch_us(graph=False)


def upstream():
    import sys

    if str(UPSTREAM) not in sys.path:
        sys.path.insert(0, str(UPSTREAM))
    from agentic.gb10 import model as umodel
    from agentic.gb10.sim import kernel, sm

    sm.occupancy = kernel.occupancy
    return umodel, sm


def load_point(name: str):
    meta = json.loads((SASS / f"{name}.json").read_text())
    return meta


def ldg_shape(op: str) -> tuple[int, int]:
    """(bytes per lane, 128-byte lines a warp instruction touches) from the LDG width modifier."""
    if op.endswith(".256"):
        return 32, 8
    if ".128" in op:
        return 16, 4
    if ".64" in op:
        return 8, 2
    return 4, 1


def carry_over(working_set_bytes: float, umodel) -> float:
    """Fraction of a back-to-back iteration's reads still in the L2 (upstream probe l2_carryover_b2b)."""
    pts = umodel.C["l2_carryover_b2b"]
    mb = working_set_bytes / 1048576
    if mb <= pts[0][0]:
        return pts[0][1]
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if mb <= x1:
            return y0 + (y1 - y0) * (mb - x0) / (x1 - x0)
    return pts[-1][1]


@dataclass
class Point:
    """One kernel execution: the case the receipt measured, plus the per-family facts the SM simulator needs."""

    name: str
    kernel: str
    threads: int
    grid: int
    regs: int
    measured_us: float
    case: str
    shape: dict
    reads: int  # bytes the kernel reads from DRAM on a cold pass
    writes: int  # bytes it writes
    reread: int = 0  # bytes re-read by the same block (L1/L2 hits), not DRAM
    smem: int = 0
    trips: int = 1  # back-edge count of the SASS main loop (1 = fully unrolled)
    ldg_hit_from: int | None = (
        None  # LDG instructions from this index onward hit L1 (a re-read)
    )
    ldg_hits: list | None = (
        None  # explicit per-LDG hit flags, in program order (overrides ldg_hit_from)
    )
    miss_frac: float | None = (
        None  # default: reads/(reads+reread) over the miss-eligible loads
    )
    stg_width_bytes: int = 0
    notes: str = ""
    extra: dict = field(default_factory=dict)


def parse_sass(point: Point, sm):
    return sm.kernel_sass(SASS / f"{point.name}.sass", kernel=point.kernel)


def ldg_entries(ins, point: Point) -> list:
    ops = [x for x in ins if x.base == "LDG"]
    if not ops:
        return []
    out = []
    for i, x in enumerate(ops):
        width, lines = ldg_shape(x.op)
        if point.ldg_hits:
            hit = point.ldg_hits[i % len(point.ldg_hits)]
        else:
            hit = point.ldg_hit_from is not None and i >= point.ldg_hit_from
        out.append((lines, width * 32, hit))
    return out


def occupancy(point: Point, sm) -> int:
    return sm.occupancy({"threads": point.threads}, point.regs, point.smem)


def simulate(point: Point) -> dict:
    """One SM's share of the grid, from the real SASS. Pure CPU, no GPU, parallel-safe."""
    umodel, sm = upstream()
    ins = parse_sass(point, sm)
    smem_bytes = point.smem or point.extra.get("smem_bytes", 0)
    resident = sm.occupancy({"threads": point.threads}, point.regs, smem_bytes)
    blocks_per_sm = math.ceil(point.grid / 48)
    active = min(48, point.grid)
    carry = carry_over(point.reads, umodel) if point.extra.get("carry", True) else 0.0
    dram_read = point.reads * (1.0 - carry)
    # this SM's share of the chip's DRAM read rate, in cycles per 512 B (probe dram_read_GBs)
    rate = umodel.C["dram_read_GBs"] * 1e9 / active
    dram_clk = 512.0 / rate * CLOCK_GHZ * 1e9  # seconds -> cycles at 2.54 GHz
    entries = ldg_entries(ins, point)
    # `hit` marks the loads served by L1/L2 within the block; of the rest, the share the previous back-to-back
    # iteration left in the L2 (`carry_over`) hits there instead of reaching DRAM.
    miss = (1.0 - carry) if point.miss_frac is None else point.miss_frac
    machine = sm.SM(
        ins,
        point.threads,
        blocks_per_sm,
        point.trips,
        active_sms=active,
        ldg_lines=entries,
        miss_frac=miss,
        dram_clk_per_512B=dram_clk,
        copy_lines=point.extra.get("copy_lines"),
        ldsm_ways=point.extra.get("ldsm_ways", (1, 1)),
        ctile_bytes=point.extra.get("ctile_bytes", 0),
        resident=resident,
        grid_blocks=point.grid,
        grid_dim=point.extra.get("grid_dim"),
    )
    import time

    limit = point.extra.get("limit", 400_000_000)
    started = time.time()
    run = machine.run(limit=limit)
    wall = round(time.time() - started, 1)
    # A returned cycle count is not a finished kernel: the simulator stops at the cycle limit and leaves
    # warps mid-instruction. `incomplete` when the limit was reached, a warp never exited, or a block never started.
    unterminated = sum(1 for w in machine.warps if not w.done)
    blocks_left = machine.next_block < machine.blocks
    incomplete = bool(run["cycles"] >= limit - 1 or unterminated or blocks_left)
    completeness = {
        "incomplete": incomplete,
        "cyle_limit": limit,
        "cycles_used_pct": round(run["cycles"] / limit * 100, 3),
        "unterminated_warps": unterminated,
        "warps": len(machine.warps),
        "blocks_not_started": max(0, machine.blocks - machine.next_block),
    }
    sm_us = run["cycles"] / (CLOCK_GHZ * 1e3)
    bus_us = (
        dram_read / (umodel.C["dram_read_GBs"] * 1e9)
        + point.writes / (umodel.C["dram_write_GBs"] * 1e9)
    ) * 1e6
    total = LAUNCH_US + max(sm_us, bus_us)
    return {
        "name": point.name,
        "case": point.case,
        "shape": point.shape,
        "threads": point.threads,
        "grid": point.grid,
        "regs": point.regs,
        "resident": resident,
        "reads_MB": point.reads / 1e6,
        "carry": round(carry, 3),
        "miss_frac": round(miss, 3),
        "ldg_instructions": len(entries),
        "sim_sm_us": round(sm_us, 1),
        "bus_us": round(bus_us, 1),
        "sim_us": round(total, 1),
        "measured_us": round(point.measured_us, 1),
        "error_pct": round((total / point.measured_us - 1) * 100, 1),
        "binds": "bus" if bus_us >= sm_us else "sm",
        "cycles": round(run["cycles"]),
        "wall_s": wall,
        "busy": {
            k: round(v / max(1, run["cycles"]), 2) for k, v in run["busy"].items() if v
        },
        "counts": {
            k: v
            for k, v in run.items()
            if k in ("LDG", "LDGSTS", "HMMA", "LDSM", "BAR")
        },
        "notes": point.notes,
        "completeness": completeness,
        "status": "incomplete" if incomplete else "ok",
    }
