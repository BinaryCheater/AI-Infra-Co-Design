"""Exclusive result writer required by the frozen diagnostic adapters."""
import json

def write_new(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
