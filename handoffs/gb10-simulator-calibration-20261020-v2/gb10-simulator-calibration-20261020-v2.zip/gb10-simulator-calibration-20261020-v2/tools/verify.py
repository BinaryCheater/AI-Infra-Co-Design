"""Verify every archived file, receipt binding and full inventory before use."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    for relative, record in manifest["files"].items():
        path = ROOT / relative
        if (
            not path.is_file()
            or hashlib.sha256(path.read_bytes()).hexdigest() != record["sha256"]
        ):
            raise SystemExit(f"Missing or changed file: {relative}")
    cases = json.loads((ROOT / "index.json").read_text())["cases"]
    if len(cases) != 22 or len({case["id"] for case in cases}) != 22:
        raise SystemExit("Inventory coverage mismatch")
    compared = 0
    for row in cases:
        folder = ROOT / "cases" / row["id"]
        case = json.loads((folder / "case.json").read_text())
        if case["comparison"]["error_pct"] is None:
            continue
        compared += 1
        receipt = json.loads((folder / case["measurement_receipt"]).read_text())
        timed = receipt["cases"][0]
        if timed.get("status") != "measured" or timed.get("correct") is not True:
            raise SystemExit(f"Invalid measured comparison: {row['id']}")
        binding = case["binding"]
        binary = folder / binding["binary_file"]
        digest = hashlib.sha256(binary.read_bytes()).hexdigest()
        if digest != binding["binary_sha256"] or digest != timed["binary_sha256"]:
            raise SystemExit(f"Measured binary mismatch: {row['id']}")
        profile = json.loads((folder / "simulation-profile.json").read_text())
        if profile["kind"] == "whole-grid-ws":
            images = json.loads((folder / "bound-library/manifest.json").read_text())[
                "images"
            ]
            for image in images:
                if (
                    hashlib.sha256(
                        (folder / "bound-library" / image["cubin"]).read_bytes()
                    ).hexdigest()
                    != image["sha256"]
                ):
                    raise SystemExit(f"Extracted CUDA image mismatch: {row['id']}")
    if compared != 10:
        raise SystemExit(
            "Expected ten complete comparisons, including high-error cases"
        )
    print(
        f"Verified {len(manifest['files'])} files, all 22 inventory rows, and all 10 measured-binary comparison bindings."
    )


if __name__ == "__main__":
    main()
