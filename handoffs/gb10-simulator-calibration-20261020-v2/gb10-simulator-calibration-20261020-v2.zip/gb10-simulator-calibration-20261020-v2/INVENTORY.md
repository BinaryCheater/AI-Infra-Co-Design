# Complete case inventory

All times are microseconds. Error = simulation / measurement - 1. Unsupported and failed cases remain listed.

| Case | Priority | GPU | Simulation | Error |
|---|---|---:|---:|---:|
| softmax | P1-control | 595.9 | 626.4 | 5.1% |
| softmax_resident | P1-control | 578.2 | 626.4 | 8.3% |
| rmsnorm_resident | P1-control | 1187.3 | 1250.2 | 5.3% |
| w4_gemv | P0 | 75.7 | 130.2 | 71.9% |
| gemm | P0 | 5081.9 | 9251.4 | 82.0% |
| elementwise_add | P1-control | 857.1 | 909.6 | 6.1% |
| rmsnorm | P1-control | 1169.5 | 1250.2 | 6.9% |
| gemv | P1-control | 498.6 | 499.4 | 0.2% |
| w4a16 | P2-support | 206.8 | - | - |
| gemm_persistent | P2-support | 5327.8 | - | - |
| block_sparse_attention | P3-execution | - | - | - |
| gqa_decode | P0 | 1089.3 | 1687.3 | 54.9% |
| gqa_prefill | P2-support | 1990.1 | - | - |
| grouped_gemm | P2-support | 3048.6 | - | - |
| gemv_reducer | P2-support | 518.5 | - | - |
| gemm_basic | P1-control | 4878.5 | 5038.0 | 3.3% |
| gemm_splitk | P2-support | 25008.9 | - | - |
| gqa_splitkv | P3-correctness | - | - | - |
| conv2d | P2-support | 3497.6 | - | - |
| cumsum | P2-support | 726.6 | - | - |
| matmul_bias_relu | out-of-scope | - | - | - |
| llama_network | out-of-scope | - | - | - |
