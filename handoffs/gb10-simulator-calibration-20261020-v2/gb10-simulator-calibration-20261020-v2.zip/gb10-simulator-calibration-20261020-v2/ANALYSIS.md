# Brief calibration notes

The priority discrepancies are numerically checked and bound to measured binaries: `gemm` +82.0%, `w4_gemv` +71.9%, `gqa_decode` +54.9%. Their causes remain unresolved; no timing constants were fitted to these measurements.

- Contrast `gemm` with `gemm_basic` (+3.3%). Both launch 384 threads and 1,792 CTAs, but tile shapes and lowering differ. Audit producer/consumer control flow, loops, barriers and the inferred warm cache/wave mapping before adding a common correction.
- For W4 GEMV, inspect unpack/FMA/reduction timing and the explicit per-LDG hit assumptions. SM-side prediction dominates.
- GQA decode uses the corrected grid `(4,8,1)` and `miss_frac=1.0`. Earlier 512-CTA/0.0625-miss results were adapter mistakes and are excluded.
- Several low-error controls are dominated by the analytical bandwidth floor. Their agreement provides limited validation of detailed instruction timing; retain the separate SM and bus terms.
- Persistent GEMM, TMA/int4 and prefill probes remain incomplete. Other terminating single-CTA probes lack whole-kernel mappings. Neither condition supplies a valid full-kernel latency.
- Split-KV fails scaled-input correctness (maximum absolute error 0.314453). Sparse attention compiles after a mask repair but reaches the 360-second execution limit. Neither has an admitted time.

Freeze mappings and binary identities before calibration. Separate adapter fixes from machine-model changes, preserve negative cases, and validate any fitted change on independent configurations. This single-configuration-per-implementation collection cannot establish ranking accuracy. The two graph rows are scope boundaries rather than single-SM calibration targets.
