"""Build an English, portable GB10 simulator calibration handoff from frozen evidence."""

import argparse
import dataclasses
import hashlib
import json
import math
import shutil
import zipfile
from pathlib import Path

from knowledge.model.sim_migrate.points import POINTS
from knowledge.model.sim_migrate.wrappers import Point

ROOT = Path(__file__).resolve().parents[1]
SUITE = ROOT / "knowledge/model/sim_migrate/suites/full-20261020-v1"
UPSTREAM_COMMIT = "0eef4979390559f7cca72eac2b06e9cfc249ea30"

ANALYSIS = {
    "gemm": (
        "P0",
        "Large error on a numerically checked, measured-library-bound regular TMA GEMM. Whole-grid WSSM overpredicts by 82.0%. Inspect compiler-specific producer/consumer control flow, barrier accounting, and the warm wave/cache mapping separately. These are hypotheses, not established causes. Contrast with gemm_basic before introducing a shared correction.",
    ),
    "w4_gemv": (
        "P0",
        "SM-side timing dominates and overpredicts by 71.9%. The same cubin passes the host finite checker. Inspect SIMT unpack/FMA/reduction issue and dependency accounting, plus the declared per-LDG hit pattern. No coefficient was fitted to this runtime.",
    ),
    "gqa_decode": (
        "P0",
        "SM-side timing dominates and overpredicts by 54.9%. Actual grid is (4,8,1), 32 CTAs, not 512. Each CTA streams one KV head; miss_frac=1.0. The earlier 512-CTA/0.0625-miss result is invalid and excluded. Recheck loop, copy, tensor, barrier and memory overlap accounting; the residual is not causally isolated.",
    ),
    "gemm_basic": (
        "P1-control",
        "Regular TMA GEMM control: complete same-library-bound WSSM prediction is +3.3%. It uses different tile/lowering details from gemm despite equal grid size. Preserve it as a contrast while repairing gemm; one point does not validate the whole family.",
    ),
    "softmax": (
        "P1-control",
        "Online two-pass row softmax. Prediction is +5.1%, dominated by the analytical traffic floor rather than instruction timing. Useful for traffic/measurement consistency, weak evidence for instruction scheduler accuracy.",
    ),
    "softmax_resident": (
        "P1-control",
        "Resident row softmax. Prediction is +8.3%, dominated by the traffic floor. The new traffic mapping is frozen; shared-memory and shuffle timing are approximate.",
    ),
    "rmsnorm_resident": (
        "P1-control",
        "Resident FP32 RMSNorm. Prediction is +5.3%, dominated by the traffic floor. Keep as a bandwidth control rather than claiming instruction timing validation.",
    ),
    "rmsnorm": (
        "P1-control",
        "Two-pass FP32 RMSNorm. Prediction is +6.9%, dominated by the traffic floor. Re-read/cache and shared reduction timing remain explicit mapping assumptions.",
    ),
    "elementwise_add": (
        "P1-control",
        "FP32 two-input add. Prediction is +6.1%, dominated by the traffic floor. This is a simple measurement and traffic-accounting control.",
    ),
    "gemv": (
        "P1-control",
        "SIMT thread GEMV. Prediction is +0.2%; SM-side and traffic floor are close. Do not infer domain-wide ranking from this single configuration.",
    ),
    "w4a16": (
        "P2-support",
        "GPU correctness and timing are available. TMA/int4 WSSM compatibility probe reaches one million cycles with four warps unfinished. No valid full-kernel prediction. Role/barrier, unpack and shared-memory mappings need investigation before calibration.",
    ),
    "gemm_persistent": (
        "P2-support",
        "GPU correctness and timing are available; actual launch has 48 persistent CTAs. One-CTA WSSM probe reaches one million cycles with twelve unfinished warps. The internal tile loop is not represented by the regular one-tile-per-CTA mapping.",
    ),
    "gqa_prefill": (
        "P2-support",
        "The original adapter lacked BQ. Explicit BQ64/BKV64/stages1 repair passes checks on the original 4k workload; actual launch has 256 threads. The WSSM compatibility probe remains incomplete. Causal CTA-dependent work and attention pipeline mapping are unsupported.",
    ),
    "grouped_gemm": (
        "P2-support",
        "GPU callable passes checks and is timed. One-CTA compatibility probe terminates, but grouped metadata, variable group lengths and per-CTA work routing are not mapped. Probe cycles are not a whole-kernel prediction.",
    ),
    "conv2d": (
        "P2-support",
        "GPU callable passes checks and is timed. One-CTA compatibility probe terminates, but implicit-GEMM addressing, padding, kernel-dimension loops and traffic accounting are not mapped.",
    ),
    "gemv_reducer": (
        "P2-support",
        "Archived pointer-ABI cubin passes checks and is timed. Copy/loop/reducer mapping is missing for whole-grid simulation. A terminating one-CTA probe is not an admitted prediction.",
    ),
    "gemm_splitk": (
        "P2-support",
        "Measured callable includes zero-initialization, the split-K atomic core and FP16 output conversion. The archived core SASS alone does not represent that entire callable. Compose all stages before comparing a simulator prediction with the reported time.",
    ),
    "cumsum": (
        "P2-support",
        "Archived cubin passes the chunk-local scan checker and is timed. Scan collectives, WARPSYNC/ENDCOLLECTIVE/SHFL and two back edges lack a complete execution/resource mapping. One-CTA cycles are diagnostic only.",
    ),
    "gqa_splitkv": (
        "P3-correctness",
        "Compilation succeeds, random and zero inputs pass, but scaled inputs fail: maximum absolute error 0.314453. No timing is admitted. The callable has partial-output and merge kernels. Resolve numerical correctness before using it as a timing calibration target.",
    ),
    "block_sparse_attention": (
        "P3-execution",
        "Initial boolx32 mask lowering fails. The existing int32-mask variant compiles but the bounded execution job times out after 360 seconds. No complete correctness or timing receipt. The timeout stage was not instrumented finely enough to identify a specific hanging device instruction.",
    ),
    "matmul_bias_relu": (
        "out-of-scope",
        "Composite TVM graph. Included as an explicit inventory boundary, not as a single-kernel calibration target. Constituent kernels and graph scheduling require separate composition.",
    ),
    "llama_network": (
        "out-of-scope",
        "Full-network TVM graph. Included as an explicit inventory boundary, not as a single-SM prediction. Whole-network scheduling and kernel composition are outside this handoff's instruction-kernel calibration profiles.",
    ),
}


def read(path):
    return json.loads(path.read_text()) if path.exists() else {}


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=True)


def copy(source, destination):
    if source.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def build(destination):
    destination.mkdir(parents=True, exist_ok=False)
    inventory = read(SUITE / "inventory.json")
    summary = read(SUITE / "complete-summary.json")
    index = []
    for item in inventory["targets"]:
        name = item["id"]
        original, out = SUITE / name, destination / "cases" / name
        out.mkdir(parents=True)
        row = next(r for r in summary["rows"] if r["id"] == name)
        priority, analysis = ANALYSIS[name]
        version = 5 if (original / "evaluation-v5.json").exists() else 4
        fresh_dir = original / f"fresh-execution-v{version}"
        fresh_input, fresh_receipt = (
            read(fresh_dir / "remote-input.json"),
            read(fresh_dir / "receipt.json"),
        )
        normalized = {
            "id": name,
            "priority": priority,
            "operator": item["operator"],
            "workload": item.get("case"),
            "assignment": fresh_input.get("assignment", item.get("assignment")),
            "scope": item.get(
                "scope", "single kernel implementation or execution variant"
            ),
            "comparison": {
                key: row[key]
                for key in (
                    "gpu_status",
                    "gpu_us",
                    "sim_status",
                    "sim_us",
                    "sim_sm_us",
                    "bus_us",
                    "error_pct",
                    "paired_binary",
                )
            },
            "analysis": analysis,
            "replay_modes": [],
            "formal_equivalence": "open",
        }
        if fresh_input:
            write(out / "rebuild-input.json", fresh_input)
            (out / "candidate.py").write_text(fresh_input["source"])
            normalized["replay_modes"].append("rebuild")
            for filename in (
                "receipt.json",
                "remote-stderr.log",
                "remote-stdout.json",
                "remote-job.json",
            ):
                copy(fresh_dir / filename, out / "evidence/rebuild" / filename)
        if fresh_receipt:
            write(out / "rebuild-receipt.json", fresh_receipt)
            normalized["measurement_receipt"] = "rebuild-receipt.json"
        simulation = read(original / "simulation-v3.json") or read(
            original / "simulation-v2.json"
        )
        write(out / "simulation-observation.json", simulation)
        for filename in (
            "simulation-v2.json",
            "simulation-v3.json",
            "whole-ws-v1.json",
            "whole-ws-v2.json",
        ):
            copy(original / filename, out / "evidence" / filename)
        copy(
            original / f"evaluation-v{version}.json",
            out / f"evaluation-v{version}.json",
        )
        copy(original / "result.json", out / "result.json")
        binary_folder = (
            original
            if (original / "compilation.json").exists()
            else original / "repaired"
        )
        compilation = read(binary_folder / "compilation.json")
        for filename in (
            "kernel.cu",
            "kernel.cubin",
            "kernel.sass",
            "compilation.json",
            "build-stdout.log",
            "build-stderr.log",
        ):
            copy(binary_folder / filename, out / filename)
        if (original / "bound-library").exists():
            shutil.copytree(original / "bound-library", out / "bound-library")
        exact_version = None
        for selected in (3, 2):
            exact = read(original / f"exact-replay-v{selected}.json")
            if exact.get("case", {}).get("status") == "measured" and exact.get(
                "binary_matches"
            ):
                exact_version = selected
                break
        if exact_version is not None:
            source_dir = original / f"exact-execution-v{exact_version}"
            payload, receipt = (
                read(source_dir / "remote-input.json"),
                read(source_dir / "receipt.json"),
            )
            write(out / "exact-input.json", payload)
            write(out / "exact-receipt.json", receipt)
            (out / "exact-launcher.py").write_text(payload["source"])
            normalized["replay_modes"].insert(0, "exact")
            normalized["measurement_receipt"] = "exact-receipt.json"
            normalized["binding"] = {
                "type": "direct cubin",
                "binary_file": "kernel.cubin",
                "binary_sha256": receipt["cases"][0]["binary_sha256"],
            }
            for filename in (
                "remote-stderr.log",
                "worker-source.py",
                "baseline-source.py",
            ):
                copy(source_dir / filename, out / "evidence/exact" / filename)
        elif fresh_receipt and (out / "bound-library/manifest.json").exists():
            bound = read(out / "bound-library/manifest.json")
            libs = list((out / "bound-library").glob("*.so"))
            assert len(libs) == 1
            normalized["binding"] = {
                "type": "measured exported library and extracted CUDA images",
                "binary_file": str(libs[0].relative_to(out)),
                "binary_sha256": bound["library_sha256"],
            }
        if row["error_pct"] is not None and name not in ("gemm", "gemm_basic"):
            meta = read(original / "evaluation-v4.json")["launch_metadata"]["entries"][
                0
            ]
            ext = meta["launch_extents"]
            grid_dim = [int(ext.get("blockIdx." + a, 1)) for a in "xyz"]
            obs = simulation["prediction"]
            extra = {"grid_dim": grid_dim, "limit": 40_000_000}
            if name in ("softmax", "rmsnorm_resident", "gemv", "w4_gemv", "gqa_decode"):
                alias = "rmsnorm" if name == "rmsnorm_resident" else name
                point = dataclasses.replace(
                    POINTS[alias],
                    name="kernel",
                    kernel=compilation["symbols"][0],
                    threads=obs["threads"],
                    grid=obs["grid"],
                    regs=obs["regs"],
                    smem=meta.get("dynamic_shared_bytes") or 0,
                    measured_us=row["gpu_us"],
                    extra=extra,
                )
            else:
                c = item["case"]
                count, width = c["M"] * c["N"], 2 if name == "softmax_resident" else 4
                point = Point(
                    name="kernel",
                    kernel=compilation["symbols"][0],
                    threads=obs["threads"],
                    grid=obs["grid"],
                    regs=obs["regs"],
                    smem=meta.get("dynamic_shared_bytes") or 0,
                    measured_us=row["gpu_us"],
                    extra=extra,
                    case=name,
                    shape=c,
                    reads=count * width * (2 if name == "elementwise_add" else 1),
                    writes=count * width,
                    reread=count * width if name == "rmsnorm" else 0,
                    notes="Frozen traffic mapping; shared/reduction timing remains approximate.",
                )
            assert math.prod(grid_dim) == point.grid
            write(
                out / "simulation-profile.json",
                {
                    "kind": "sm-traffic",
                    "point": dataclasses.asdict(point),
                    "note": "Traffic, loop and load-hit assumptions are adapter inputs, not observations inferred from GPU runtime.",
                },
            )
        elif row["error_pct"] is not None:
            write(
                out / "simulation-profile.json",
                {
                    "kind": "whole-grid-ws",
                    "note": "Use measured-library extracted SASS, actual launch metadata and unchanged upstream warm cache/wave mapping. No PC guard.",
                },
            )
        write(out / "case.json", normalized)
        index.append(
            {
                key: normalized[key]
                for key in ("id", "priority", "comparison", "analysis", "replay_modes")
            }
        )
    write(
        destination / "index.json",
        {
            "schema": "gb10-simulator-calibration-handoff-v1",
            "upstream_commit": UPSTREAM_COMMIT,
            "inventory_rows": 22,
            "kernel_implementations": 20,
            "composite_boundaries": 2,
            "measured_correct": 18,
            "complete_comparisons": 10,
            "cases": index,
        },
    )
    targets = [
        {
            k: v
            for k, v in row.items()
            if k not in ("historical", "old_model_aggregate", "reason")
        }
        for row in inventory["targets"]
    ]
    write(
        destination / "cases/inventory.json",
        {
            "targets": targets,
            "scope": "Full frozen inventory; original result/cubin evidence is preserved per case",
        },
    )
    tools = destination / "tools"
    for name in ("replay.py", "simulate.py", "verify.py"):
        copy(ROOT / "scripts/gb10_handoff" / name, tools / name)
    for name in ("worker.py", "baseline.py"):
        copy(ROOT / "backend/nvidia" / name, tools / "runtime" / name)
    modules = tools / "calibration_tools"
    modules.mkdir(parents=True)
    (modules / "__init__.py").write_text(
        '"""Frozen adapters; upstream simulator implementation is supplied separately."""\n'
    )
    for name in ("wrappers.py", "points.py", "suite_simulate.py", "whole_ws.py"):
        copy(ROOT / "knowledge/model/sim_migrate" / name, modules / name)
    (modules / "full_suite.py").write_text(
        '"""Exclusive result writer required by the frozen diagnostic adapters."""\nimport json\n\ndef write_new(path, value):\n    with path.open("x") as stream:\n        json.dump(value, stream, indent=2)\n'
    )
    copy(Path(__file__), destination / "provenance/package_builder.py")
    copy(
        SUITE / "execution-provenance-final.json",
        destination / "provenance/original-suite-provenance.json",
    )
    copy(ROOT / "scripts/gb10_handoff/README.md", destination / "README.md")
    copy(ROOT / "scripts/gb10_handoff/ANALYSIS.md", destination / "ANALYSIS.md")
    for candidate in (
        ROOT / "kernel-lab/sources/tilelang/LICENSE",
        ROOT / "kernel-lab/sources/LICENSE",
    ):
        if candidate.exists():
            copy(candidate, destination / "provenance/TileLang-LICENSE")
            break
    lines = [
        "# Complete case inventory",
        "",
        "All times are microseconds. Error = simulation / measurement - 1. Unsupported and failed cases remain listed.",
        "",
        "| Case | Priority | GPU | Simulation | Error |",
        "|---|---|---:|---:|---:|",
    ]
    for row in index:
        c = row["comparison"]

        def fmt(x):
            return "-" if x is None else f"{x:.1f}"

        lines.append(
            f"| {row['id']} | {row['priority']} | {fmt(c['gpu_us'])} | {fmt(c['sim_us'])} | {fmt(c['error_pct']) + '%' if c['error_pct'] is not None else '-'} |"
        )
    (destination / "INVENTORY.md").write_text("\n".join(lines) + "\n")
    files = {}
    for path in sorted(destination.rglob("*")):
        if path.is_file():
            raw = path.read_bytes()
            files[str(path.relative_to(destination))] = {
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
            }
    write(
        destination / "MANIFEST.json",
        {
            "schema": "sha256-file-manifest-v1",
            "scope": "All payload files except this manifest; the archive itself has a separate SHA256 sidecar",
            "files": files,
        },
    )
    archive = destination.with_suffix(".zip")
    with zipfile.ZipFile(
        archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as bundle:
        for path in sorted(destination.rglob("*")):
            if path.is_file():
                bundle.write(
                    path, str(Path(destination.name) / path.relative_to(destination))
                )
    with archive.with_suffix(".zip.sha256").open("x") as stream:
        stream.write(
            hashlib.sha256(archive.read_bytes()).hexdigest()
            + "  "
            + archive.name
            + "\n"
        )
    print(
        json.dumps(
            {
                "directory": str(destination),
                "archive": str(archive),
                "archive_bytes": archive.stat().st_size,
                "files": len(files),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    build(args.out.resolve())
