# GB10 simulator calibration cases

A kernel handoff for AI-Infra-Co-Design's GB10 simulator, based on upstream commit `0eef4979390559f7cca72eac2b06e9cfc249ea30`.

**Start with:** `INVENTORY.md` and `cases/<id>/case.json`. Prioritize `gemm` (+82.0%), `w4_gemv` (+71.9%) and `gqa_decode` (+54.9%). Keep `gemm_basic` (+3.3%) as a contrasting regular TMA GEMM.

The inventory retains all 20 kernel implementations/execution variants and two composite-graph scope markers. Eighteen kernels have correct measured results; ten have complete binary-bound simulation comparisons. Correctness failures, timeouts and unsupported mappings are retained. Each implementation has one frozen workload/configuration; no domain-wide ranking is claimed. Full network binaries and weights are outside this kernel package.

## Contents

- `cases/<id>/case.json`: workload, final configuration, priority, outcome and brief analysis.
- `candidate.py`, `rebuild-input.json`: selected kernel source and construction input.
- `kernel.cu/.cubin/.sass`, `compilation.json`: direct-binary evidence where available.
- `bound-library/`: measured exported libraries and their extracted CUDA images/SASS. These differ from independently compiled cubins.
- `*-receipt.json`, `evidence/`: checks, samples, environments and recorded failures/probes.
- `simulation-profile.json`, `tools/`: frozen adapters and optional replay entry points.
- `MANIFEST.json`, ZIP `.sha256` sidecar: file and transport hashes.

## Optional replay

These commands are supplied for the recipient; no additional GPU measurements were taken during packaging.

```bash
python3 tools/verify.py
python3 tools/simulate.py --case w4_gemv --upstream /path/to/AI-Infra-Co-Design --out /tmp/w4-sim.json
python3 tools/replay.py --case w4_gemv --mode exact --out /tmp/w4-gpu --gpu-lock /path/to/shared/gpu0.lock
python3 tools/replay.py --case gemm --mode rebuild --out /tmp/gemm-gpu --gpu-lock /path/to/shared/gpu0.lock
```

CPU simulation uses the supplied upstream checkout. GPU replay requires Linux GB10/SM12.1, TileLang 0.1.15 and the matching Torch/TVM environment; historical versions are in the receipts (Torch 2.9.0+cu130, driver 580.95.05). `exact` uses archived pointer-ABI cubins; TMA callables use `rebuild`, which may change binary identity. Output paths must be new. GPU jobs are locked and bounded; the known sparse-attention timeout requires explicit invocation.

Timing uses ten warmups, 30 complete calls per CUDA Graph and seven event samples; report the per-call median. Seeds 17/random, 29/zeros and 41/scaled must pass before timing. `gemm_splitk` includes zeroing and conversion; `cumsum` is chunk-local scan with chunk size 64. W4 GEMV uses `fast_decoding=False`.

Absolute historical paths are provenance only. Portable tools resolve bundle-relative files. Preserve upstream attribution and the included TileLang license. No chat transcripts or credentials are included.
