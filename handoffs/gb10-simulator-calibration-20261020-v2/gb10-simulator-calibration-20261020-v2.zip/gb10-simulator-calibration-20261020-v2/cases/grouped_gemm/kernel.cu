#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void grouped_gemm_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap B_desc, half_t* __restrict__ C, const int* __restrict__ batch_offsets, const int* __restrict__ batch_padded_offsets, const int* __restrict__ batch_sizes);
extern "C" __global__ void __launch_bounds__(384, 1) grouped_gemm_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap B_desc, half_t* __restrict__ C, const int* __restrict__ batch_offsets, const int* __restrict__ batch_padded_offsets, const int* __restrict__ batch_sizes) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 49152));
  __shared__ __align__(16) uint64_t mbarrier_mem[6];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  int cur_batch_idx = 0;
  int cur_batch_size = 0;
  float C_local[32];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(A_desc);
    tl::prefetch_tma_descriptor(B_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(1);
    mbarrier[3].init(256);
    mbarrier[4].init(256);
    mbarrier[5].init(256);
  }
  tl::fence_barrier_init();
  __syncthreads();
  cur_batch_idx = 0;
  for (int i = 0; i < 5; ++i) {
    bool in_cur_batch_idx = (batch_padded_offsets[i] <= (((int)blockIdx.x) * 128));
    int condval;
    if (in_cur_batch_idx) {
      condval = i;
    } else {
      condval = cur_batch_idx;
    }
    cur_batch_idx = condval;
  }
  int condval_1;
  if (((0 <= cur_batch_idx) && (cur_batch_idx < 5))) {
    condval_1 = batch_sizes[cur_batch_idx];
  } else {
    condval_1 = 0;
  }
  cur_batch_size = condval_1;
  int condval_2;
  if (((0 <= cur_batch_idx) && (cur_batch_idx < 5))) {
    condval_2 = batch_offsets[cur_batch_idx];
  } else {
    condval_2 = 0;
  }
  int condval_3;
  if (((0 <= cur_batch_idx) && (cur_batch_idx < 5))) {
    condval_3 = batch_padded_offsets[cur_batch_idx];
  } else {
    condval_3 = 0;
  }
  int m_start = (((((int)blockIdx.x) * 128) + condval_2) - condval_3);
  int condval_4;
  if (((0 <= cur_batch_idx) && (cur_batch_idx < 5))) {
    condval_4 = batch_padded_offsets[cur_batch_idx];
  } else {
    condval_4 = 0;
  }
  int actual_rows = max(0, min(128, ((cur_batch_size + condval_4) - (((int)blockIdx.x) * 128))));
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    for (int k = 0; k < 64; ++k) {
      mbarrier[((k % 3) + 3)].wait((((k % 6) / 3) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[(k % 3)].expect_transaction(16384);
        tl::tma_load(A_desc, mbarrier[(k % 3)], (&(((half_t*)A_shared)[((k % 3) * 8192)])), (k * 64), m_start);
        mbarrier[(k % 3)].arrive_and_expect_tx(8192);
        tl::tma_load(B_desc, mbarrier[(k % 3)], (&(((half_t*)B_shared)[((k % 3) * 4096)])), (((int)blockIdx.y) * 64), (k * 64), cur_batch_idx);
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i_1 = 0; i_1 < 8; ++i_1) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(C_local + (i_1 * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    for (int k_1 = 0; k_1 < 64; ++k_1) {
      mbarrier[(k_1 % 3)].wait(((k_1 % 6) / 3));
      {
        half_t A_local[32];
        half_t B_local[8];
        for (int ki = 0; ki < 4; ++ki) {
          #pragma unroll
          for (int i_2 = 0; i_2 < 4; ++i_2) {
            tl::ptx_ldmatrix_x4((&(((half_t*)A_shared)[((((((((k_1 % 3) * 8192) + (((((int)threadIdx.x) & 63) >> 5) * 4096)) + (i_2 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_2 * 8)])));
          }
          tl::ptx_ldmatrix_x4_trans((&(((half_t*)B_shared)[(((((((k_1 % 3) * 4096) + (ki * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((((((int)threadIdx.x) >> 6) + 2) & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 127) >> 6) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[0])));
          for (int i_3 = 0; i_3 < 4; ++i_3) {
            tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_local + (i_3 * 8)), reinterpret_cast<const unsigned*>(A_local + (i_3 * 8)), reinterpret_cast<const unsigned*>(B_local + 0));
            tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_local + ((i_3 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_3 * 8)), reinterpret_cast<const unsigned*>(B_local + 4));
          }
        }
      }
      mbarrier[((k_1 % 3) + 3)].arrive();
    }
    #pragma unroll
    for (int i_4 = 0; i_4 < 16; ++i_4) {
      half_t C_local_cast[2];
      if (((((((((int)threadIdx.x) & 63) >> 5) * 64) + ((i_4 >> 2) * 16)) + ((i_4 & 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < actual_rows) {
        uint1 __1;
        float2 v_ = *(float2*)(C_local + (i_4 * 2));
        ((half2*)(&__1))[0] = __float22half2_rn(((float2*)(&v_))[0]);
        *(uint1*)(C_local_cast + 0) = __1;
        if (0 <= (((((((((int)threadIdx.x) & 63) >> 5) * 64) + ((i_4 >> 2) * 16)) + ((i_4 & 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)) + m_start)) {
          if ((((((((((int)threadIdx.x) & 63) >> 5) * 64) + ((i_4 >> 2) * 16)) + ((i_4 & 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)) + m_start) < 927) {
            *(uint1*)(C + ((((((((((((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)917504) + ((((int64_t)i_4) >> (int64_t)2) * (int64_t)229376)) + ((((int64_t)i_4) & (int64_t)1) * (int64_t)114688)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)14336)) + (((int64_t)m_start) * (int64_t)14336)) + (((int64_t)((int)blockIdx.y)) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)16)) + (((((int64_t)i_4) & (int64_t)3) >> (int64_t)1) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2)) - (int64_t)32)) = *(uint1*)(C_local_cast + 0);
          }
        }
      }
    }
  }
}

