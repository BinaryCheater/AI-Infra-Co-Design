import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
from typing import Any, Callable, Optional
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tvm import tirx
from tilelang.carver.arch import driver

class _ZeroedSplitK:

    def __init__(self, kernel, m, n):
        self.kernel = kernel
        self.m, self.n = (m, n)
        self.out = None

    def __call__(self, a, b):
        import torch
        if self.out is None or self.out.shape != (self.m, self.n):
            self.out = torch.zeros((self.m, self.n), dtype=torch.float32, device=a.device)
        else:
            self.out.zero_()
        self.kernel(a, b, self.out)
        return self.out.half()

@tilelang.jit
def grouped_gemm(A, B, batch_sizes, batch_offsets, batch_padded_offsets, batch_sizes_list, block_M, block_N, block_K, trans_b=False, num_stages=2, threads=128, dtype=T.float16):
    """
    args:
        a (torch.Tensor): Input tensor of shape (M, K).
        b (torch.Tensor): Input tensor of shape (G, K, N).
    """
    K, N = T.const('K, N')
    batch_sum = sum(batch_sizes_list)
    batch_count = len(batch_sizes_list)
    accum_dtype = T.float32
    total_m_blocks = sum(((size + block_M - 1) // block_M for size in batch_sizes_list))
    B_shape = [batch_count, K, N] if not trans_b else [batch_count, N, K]
    B_shared_shape = [block_K, block_N] if not trans_b else [block_N, block_K]
    A: T.Tensor([batch_sum, K], dtype)
    B: T.Tensor(B_shape, dtype)
    C = T.empty([batch_sum, N], dtype)
    batch_sizes: T.Tensor([batch_count], T.int32)
    batch_offsets: T.Tensor([batch_count], T.int32)
    batch_padded_offsets: T.Tensor([batch_count], T.int32)
    with T.Kernel(total_m_blocks, T.ceildiv(N, block_N), threads=threads) as (bx, by):
        A_shared = T.alloc_shared([block_M, block_K], dtype)
        B_shared = T.alloc_shared(B_shared_shape, dtype)
        C_local = T.alloc_fragment([block_M, block_N], accum_dtype)
        cur_batch_idx = T.alloc_var(dtype=T.int32)
        cur_batch_size = T.alloc_var(dtype=T.int32)
        m_start_padded = bx * block_M
        cur_batch_idx = 0
        for i in range(batch_count):
            in_cur_batch_idx = m_start_padded >= batch_padded_offsets[i]
            cur_batch_idx = T.if_then_else(in_cur_batch_idx, i, cur_batch_idx)
        cur_batch_size = batch_sizes[cur_batch_idx]
        m_start = m_start_padded - batch_padded_offsets[cur_batch_idx] + batch_offsets[cur_batch_idx]
        actual_rows = T.max(0, T.min(block_M, cur_batch_size + batch_padded_offsets[cur_batch_idx] - m_start_padded))
        T.clear(C_local)
        for k in T.Pipelined(T.ceildiv(K, block_K), num_stages=num_stages):
            T.copy(A[m_start:m_start + block_M, k * block_K:(k + 1) * block_K], A_shared)
            if trans_b:
                T.copy(B[cur_batch_idx, by * block_N:(by + 1) * block_N, k * block_K:(k + 1) * block_K], B_shared)
            else:
                T.copy(B[cur_batch_idx, k * block_K:(k + 1) * block_K, by * block_N:(by + 1) * block_N], B_shared)
            T.gemm(A_shared, B_shared, C_local, transpose_B=trans_b)
        for i, j in T.Parallel(block_M, block_N):
            if i < actual_rows:
                C[m_start + i, by * block_N + j] = C_local[i, j]
    return C

def build(c, p):
    return grouped_gemm.compile(K=c['K'], N=c['N'], batch_sizes_list=tuple(c['sizes']), block_M=p['BM'], block_N=p['BN'], block_K=p['BK'], threads=p['threads'], num_stages=p['stages'])
