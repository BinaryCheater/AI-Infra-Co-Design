#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void matmul_persistent_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap B_desc, __grid_constant__ const CUtensorMap C_desc);
extern "C" __global__ void __launch_bounds__(384, 1) matmul_persistent_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap B_desc, __grid_constant__ const CUtensorMap C_desc) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 32768));
  void* C_shared = ((void*)((char*)buf_dyn_shmem + 65536));
  __shared__ __align__(16) uint64_t mbarrier_mem[4];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  int producer_phase_cnt[1];
  int consumer_phase_cnt[1];
  float C_local[64];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(A_desc);
    tl::prefetch_tma_descriptor(B_desc);
    tl::prefetch_tma_descriptor(C_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(256);
    mbarrier[3].init(256);
  }
  tl::fence_barrier_init();
  __syncthreads();
  producer_phase_cnt[0] = 0;
  consumer_phase_cnt[0] = 0;
  for (int w = 0; w < 75; ++w) {
    if (((w * 3) + (((int)blockIdx.x) >> 4)) < 224) {
      if (((int)threadIdx.x) < 128) {
        tl::fence_proxy_async();
        for (int k = 0; k < 64; ++k) {
          mbarrier[((producer_phase_cnt[0] & 1) + 2)].wait((((producer_phase_cnt[0] & 3) >> 1) ^ 1));
          if (tl::tl_shuffle_elect<128>()) {
            mbarrier[(producer_phase_cnt[0] & 1)].expect_transaction(16384);
            tl::tma_load(A_desc, mbarrier[(producer_phase_cnt[0] & 1)], (&(((half_t*)A_shared)[((producer_phase_cnt[0] & 1) * 8192)])), (k * 64), (((((w * 48) + ((int)blockIdx.x)) % 256) / 8) * 128));
            mbarrier[(producer_phase_cnt[0] & 1)].arrive_and_expect_tx(16384);
            #pragma unroll
            for (int i = 0; i < 2; ++i) {
              tl::tma_load(B_desc, mbarrier[(producer_phase_cnt[0] & 1)], (&(((half_t*)B_shared)[(((producer_phase_cnt[0] & 1) * 8192) + (i * 4096))])), ((((((w * 48) + ((int)blockIdx.x)) / 256) * 1024) + ((((int)blockIdx.x) % 8) * 128)) + (i * 64)), (k * 64));
            }
          }
          producer_phase_cnt[0] = (producer_phase_cnt[0] + 1);
        }
      } else {
        #pragma unroll
        for (int i_1 = 0; i_1 < 16; ++i_1) {
          float broadcast_var = 0x0p+0f/*0.000000e+00*/;
          *(float4*)(C_local + (i_1 * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
        }
        for (int k_1 = 0; k_1 < 64; ++k_1) {
          mbarrier[(consumer_phase_cnt[0] & 1)].wait(((consumer_phase_cnt[0] & 3) >> 1));
          {
            half_t A_local[32];
            half_t B_local[16];
            for (int ki = 0; ki < 4; ++ki) {
              #pragma unroll
              for (int i_2 = 0; i_2 < 4; ++i_2) {
                tl::ptx_ldmatrix_x4((&(((half_t*)A_shared)[((((((((consumer_phase_cnt[0] & 1) * 8192) + (((((int)threadIdx.x) & 63) >> 5) * 4096)) + (i_2 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_2 * 8)])));
              }
              #pragma unroll
              for (int i_3 = 0; i_3 < 2; ++i_3) {
                tl::ptx_ldmatrix_x4_trans((&(((half_t*)B_shared)[((((((((consumer_phase_cnt[0] & 1) * 8192) + (((((((int)threadIdx.x) >> 6) + 2) & 3) >> 1) * 4096)) + (ki * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 127) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + i_3) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[(i_3 * 8)])));
              }
              for (int i_4 = 0; i_4 < 4; ++i_4) {
                for (int j = 0; j < 2; ++j) {
                  tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_local + ((i_4 * 16) + (j * 8))), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + (j * 8)));
                  tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_local + (((i_4 * 16) + (j * 8)) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + ((j * 8) + 4)));
                }
              }
            }
          }
          mbarrier[((consumer_phase_cnt[0] & 1) + 2)].arrive();
          consumer_phase_cnt[0] = (consumer_phase_cnt[0] + 1);
        }
        tl::__sync_thread_partial(3, 256);
        #pragma unroll
        for (int i_5 = 0; i_5 < 8; ++i_5) {
          tl::ptx_stmatrix_m8n8_x4((&(((half_t*)C_shared)[(((((((((((int)threadIdx.x) >> 7) * 8192) + (((((int)threadIdx.x) & 63) >> 5) * 4096)) + ((i_5 >> 1) * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 127) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (i_5 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) - 8192)])), __pack_half2(((half_t)C_local[(i_5 * 8)]), ((half_t)C_local[((i_5 * 8) + 1)])), __pack_half2(((half_t)C_local[((i_5 * 8) + 2)]), ((half_t)C_local[((i_5 * 8) + 3)])), __pack_half2(((half_t)C_local[((i_5 * 8) + 4)]), ((half_t)C_local[((i_5 * 8) + 5)])), __pack_half2(((half_t)C_local[((i_5 * 8) + 6)]), ((half_t)C_local[((i_5 * 8) + 7)])));
        }
        tl::__sync_thread_partial(3, 256);
        if (tl::tl_shuffle_elect<256>()) {
          tl::fence_proxy_async();
          #pragma unroll
          for (int i_6 = 0; i_6 < 2; ++i_6) {
            tl::tma_store(C_desc, (&(((half_t*)C_shared)[(i_6 * 8192)])), ((((((w * 48) + ((int)blockIdx.x)) / 256) * 1024) + ((((int)blockIdx.x) % 8) * 128)) + (i_6 * 64)), (((((w * 48) + ((int)blockIdx.x)) % 256) / 8) * 128));
          }
          tl::tma_store_arrive();
          tl::tma_store_wait<0, true>();
        }
      }
    }
  }
}

