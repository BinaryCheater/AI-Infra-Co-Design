import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tilelang.carver.arch import driver

@tilelang.jit
def matmul_non_persistent(A, B, block_M, block_N, block_K, threads, num_stages, dtype=T.float16, accum_dtype=T.float32):
    M, N, K = T.const('M, N, K')
    A: T.Tensor((M, K), dtype)
    B: T.Tensor((K, N), dtype)
    C = T.empty((M, N), dtype)
    with T.Kernel(T.ceildiv(M, block_M), T.ceildiv(N, block_N), threads=threads) as (bx, by):
        A_shared = T.alloc_shared((block_M, block_K), dtype)
        B_shared = T.alloc_shared((block_K, block_N), dtype)
        C_local = T.alloc_fragment((block_M, block_N), accum_dtype)
        C_shared = T.alloc_shared((block_M, block_N), dtype)
        T.use_swizzle(10)
        T.clear(C_local)
        for k in T.Pipelined(T.ceildiv(K, block_K), num_stages=num_stages):
            T.copy(A[bx * block_M, k * block_K], A_shared)
            T.copy(B[k * block_K, by * block_N], B_shared)
            T.gemm(A_shared, B_shared, C_local)
        T.copy(C_local, C_shared)
        T.copy(C_shared, C[bx * block_M, by * block_N])
    return C

def build(c, p):
    return matmul_non_persistent.compile(M=c['M'], N=c['N'], K=c['K'], block_M=p['BM'], block_N=p['BN'], block_K=p['BK'], threads=p['threads'], num_stages=p['stages'])
