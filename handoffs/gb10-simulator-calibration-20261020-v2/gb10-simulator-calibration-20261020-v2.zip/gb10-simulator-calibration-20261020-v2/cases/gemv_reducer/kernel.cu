#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/copy.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gemv_alloc_reducer_kernel(const half_t* __restrict__ a, half_t* __restrict__ o, const half_t* __restrict__ x);
extern "C" __global__ void __launch_bounds__(128, 1) gemv_alloc_reducer_kernel(const half_t* __restrict__ a, half_t* __restrict__ o, const half_t* __restrict__ x) {
  float o_reducer[2];
  extern __shared__ __align__(1024) half_t a_smem[];
  float a_frag[16];
  float x_frag[8];
  float o_reducer_result[2];
  float broadcast_var = 0x0p+0f/*0.000000e+00*/;
  *(float2*)(o_reducer + 0) = make_float2(broadcast_var, broadcast_var);
  #pragma unroll
  for (int i = 0; i < 2; ++i) {
    tl::cp_async_gs<16>((&(a_smem[((i * 1024) + (((int)threadIdx.x) * 8))])), (&(a[((((((int)blockIdx.x) * 131072) + (i * 65536)) + ((((int)threadIdx.x) >> 3) * 4096)) + ((((int)threadIdx.x) & 7) * 8))])));
  }
  tl::cp_async_commit();
  #pragma unroll
  for (int i_1 = 0; i_1 < 2; ++i_1) {
    tl::cp_async_gs<16>((&(a_smem[(((i_1 * 1024) + (((int)threadIdx.x) * 8)) + 2048)])), (&(a[(((((((int)blockIdx.x) * 131072) + (i_1 * 65536)) + ((((int)threadIdx.x) >> 3) * 4096)) + ((((int)threadIdx.x) & 7) * 8)) + 64)])));
  }
  tl::cp_async_commit();
  for (int i0_n = 0; i0_n < 62; ++i0_n) {
    tl::cp_async_wait<1>();
    __syncthreads();
    #pragma unroll
    for (int i_2 = 0; i_2 < 2; ++i_2) {
      half_t a_smem_local_cast[8];
      *(uint4*)(a_smem_local_cast + 0) = *(uint4*)(a_smem + ((((i0_n & 1) * 2048) + (i_2 * 1024)) + (((int)threadIdx.x) * 8)));
      for (int vec = 0; vec < 2; ++vec) {
        float4 __1;
        uint2 v_ = *(uint2*)(a_smem_local_cast + (vec * 4));
        ((float2*)(&__1))[0] = __half22float2(((half2*)(&v_))[0]);
        ((float2*)(&__1))[1] = __half22float2(((half2*)(&v_))[1]);
        *(float4*)(a_frag + ((i_2 * 8) + (vec * 4))) = __1;
      }
    }
    __syncthreads();
    #pragma unroll
    for (int i_3 = 0; i_3 < 2; ++i_3) {
      tl::cp_async_gs<16>((&(a_smem[((((i0_n & 1) * 2048) + (i_3 * 1024)) + (((int)threadIdx.x) * 8))])), (&(a[((((((((int)blockIdx.x) * 131072) + (i_3 * 65536)) + ((((int)threadIdx.x) >> 3) * 4096)) + (i0_n * 64)) + ((((int)threadIdx.x) & 7) * 8)) + 128)])));
    }
    tl::cp_async_commit();
    {
      half_t x_local_cast_1[8];
      *(uint4*)(x_local_cast_1 + 0) = *(uint4*)(x + ((i0_n * 64) + ((((int)threadIdx.x) & 7) * 8)));
      for (int i_4 = 0; i_4 < 2; ++i_4) {
        float4 __2;
        uint2 v__1 = *(uint2*)(x_local_cast_1 + (i_4 * 4));
        ((float2*)(&__2))[0] = __half22float2(((half2*)(&v__1))[0]);
        ((float2*)(&__2))[1] = __half22float2(((half2*)(&v__1))[1]);
        *(float4*)(x_frag + (i_4 * 4)) = __2;
      }
    }
    #pragma unroll
    for (int i_5 = 0; i_5 < 16; ++i_5) {
      o_reducer[(i_5 >> 3)] = (o_reducer[(i_5 >> 3)] + (a_frag[i_5] * x_frag[(i_5 & 7)]));
    }
  }
  tl::cp_async_wait<1>();
  __syncthreads();
  #pragma unroll
  for (int i_6 = 0; i_6 < 2; ++i_6) {
    half_t a_smem_local_cast_2[8];
    *(uint4*)(a_smem_local_cast_2 + 0) = *(uint4*)(a_smem + ((i_6 * 1024) + (((int)threadIdx.x) * 8)));
    for (int vec_1 = 0; vec_1 < 2; ++vec_1) {
      float4 __3;
      uint2 v__2 = *(uint2*)(a_smem_local_cast_2 + (vec_1 * 4));
      ((float2*)(&__3))[0] = __half22float2(((half2*)(&v__2))[0]);
      ((float2*)(&__3))[1] = __half22float2(((half2*)(&v__2))[1]);
      *(float4*)(a_frag + ((i_6 * 8) + (vec_1 * 4))) = __3;
    }
  }
  {
    half_t x_local_cast_3[8];
    *(uint4*)(x_local_cast_3 + 0) = *(uint4*)(x + (((((int)threadIdx.x) & 7) * 8) + 3968));
    for (int i_7 = 0; i_7 < 2; ++i_7) {
      float4 __4;
      uint2 v__3 = *(uint2*)(x_local_cast_3 + (i_7 * 4));
      ((float2*)(&__4))[0] = __half22float2(((half2*)(&v__3))[0]);
      ((float2*)(&__4))[1] = __half22float2(((half2*)(&v__3))[1]);
      *(float4*)(x_frag + (i_7 * 4)) = __4;
    }
  }
  #pragma unroll
  for (int i_8 = 0; i_8 < 16; ++i_8) {
    o_reducer[(i_8 >> 3)] = (o_reducer[(i_8 >> 3)] + (a_frag[i_8] * x_frag[(i_8 & 7)]));
  }
  tl::cp_async_wait<0>();
  __syncthreads();
  #pragma unroll
  for (int i_9 = 0; i_9 < 2; ++i_9) {
    half_t a_smem_local_cast_4[8];
    *(uint4*)(a_smem_local_cast_4 + 0) = *(uint4*)(a_smem + (((i_9 * 1024) + (((int)threadIdx.x) * 8)) + 2048));
    for (int vec_2 = 0; vec_2 < 2; ++vec_2) {
      float4 __5;
      uint2 v__4 = *(uint2*)(a_smem_local_cast_4 + (vec_2 * 4));
      ((float2*)(&__5))[0] = __half22float2(((half2*)(&v__4))[0]);
      ((float2*)(&__5))[1] = __half22float2(((half2*)(&v__4))[1]);
      *(float4*)(a_frag + ((i_9 * 8) + (vec_2 * 4))) = __5;
    }
  }
  {
    half_t x_local_cast_5[8];
    *(uint4*)(x_local_cast_5 + 0) = *(uint4*)(x + (((((int)threadIdx.x) & 7) * 8) + 4032));
    for (int i_10 = 0; i_10 < 2; ++i_10) {
      float4 __6;
      uint2 v__5 = *(uint2*)(x_local_cast_5 + (i_10 * 4));
      ((float2*)(&__6))[0] = __half22float2(((half2*)(&v__5))[0]);
      ((float2*)(&__6))[1] = __half22float2(((half2*)(&v__5))[1]);
      *(float4*)(x_frag + (i_10 * 4)) = __6;
    }
  }
  #pragma unroll
  for (int i_11 = 0; i_11 < 16; ++i_11) {
    o_reducer[(i_11 >> 3)] = (o_reducer[(i_11 >> 3)] + (a_frag[i_11] * x_frag[(i_11 & 7)]));
  }
  for (int __finred_0 = 0; __finred_0 < 2; ++__finred_0) {
    o_reducer[__finred_0] = tl::AllReduce<tl::SumOp, 8, 1, 0, tl::NamedBarrier<128>>::run(o_reducer[__finred_0]);
  }
  *(float2*)(o_reducer_result + 0) = *(float2*)(o_reducer + 0);
  if ((((int)threadIdx.x) % 8) == 0) {
    #pragma unroll
    for (int i_12 = 0; i_12 < 2; ++i_12) {
      o[(((((int)blockIdx.x) * 32) + (i_12 * 16)) + (((int)threadIdx.x) >> 3))] = ((half_t)o_reducer_result[i_12]);
    }
  }
}

