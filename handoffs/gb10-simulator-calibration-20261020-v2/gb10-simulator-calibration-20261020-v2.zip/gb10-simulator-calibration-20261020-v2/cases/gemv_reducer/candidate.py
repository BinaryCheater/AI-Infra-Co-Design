import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
from typing import Any, Callable, Optional
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tvm import tirx
from tilelang.carver.arch import driver

class _ZeroedSplitK:

    def __init__(self, kernel, m, n):
        self.kernel = kernel
        self.m, self.n = (m, n)
        self.out = None

    def __call__(self, a, b):
        import torch
        if self.out is None or self.out.shape != (self.m, self.n):
            self.out = torch.zeros((self.m, self.n), dtype=torch.float32, device=a.device)
        else:
            self.out.zero_()
        self.kernel(a, b, self.out)
        return self.out.half()

@tl.jit(pass_configs={tl.PassConfigKey.TL_DISABLE_TMA_LOWER: True, tl.PassConfigKey.TL_DISABLE_WARP_SPECIALIZED: True})
def gemv_alloc_reducer(a, x, block_M=128, block_N=128, num_stages=2, threads=256, dtype: T.dtype=T.float16, accum_dtype: T.dtype=T.float):
    M, N = T.const('M, N')
    a: T.Tensor((M, N), dtype)
    x: T.Tensor((N,), dtype)
    o = T.empty((M,), dtype)
    with T.Kernel(T.ceildiv(M, block_M), threads=threads) as i0_m:
        o_reducer = T.alloc_reducer(block_M, accum_dtype, replication='all')
        T.clear(o_reducer)
        for i0_n in T.Pipelined(T.ceildiv(N, block_N), num_stages=num_stages):
            a_smem = T.alloc_shared((block_M, block_N), dtype)
            T.copy(a[i0_m * block_M, i0_n * block_N], a_smem)
            a_frag = T.alloc_fragment((block_M, block_N), accum_dtype)
            T.copy(a_smem, a_frag)
            x_frag = T.alloc_fragment(block_N, accum_dtype)
            T.copy(x[i0_n * block_N], x_frag)
            for i1_m, i1_n in T.Parallel(block_M, block_N):
                o_reducer[i1_m] += a_frag[i1_m, i1_n] * x_frag[i1_n]
        T.finalize_reducer(o_reducer)
        T.copy(o_reducer, o[i0_m * block_M])
    return o

def build(c, p):
    return gemv_alloc_reducer.compile(M=c['M'], N=c['N'], block_M=p['BM'], block_N=p['BN'], threads=p['threads'], num_stages=p['stages'])
