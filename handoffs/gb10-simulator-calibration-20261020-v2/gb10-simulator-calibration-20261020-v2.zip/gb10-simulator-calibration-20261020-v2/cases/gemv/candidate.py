import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import tilelang
import tilelang.language as T
from tvm import DataType
@tilelang.jit(target='auto')
def get_autotuned_kernel(A, B, BLOCK_N=None, reduce_threads=None):
    N, K = T.const('N, K')
    dtype = T.float16
    accum_dtype = T.float32
    MAX_TRANSACTION_SIZE_IN_BITS = 128
    TILE_K = MAX_TRANSACTION_SIZE_IN_BITS // DataType(dtype).bits
    BLOCK_K = reduce_threads * TILE_K
    A: T.Tensor((K,), dtype)
    B: T.Tensor((N, K), dtype)
    C = T.empty((N,), dtype)
    with T.Kernel(T.ceildiv(N, BLOCK_N), threads=(BLOCK_N, reduce_threads)) as bn:
        tn = T.get_thread_binding(0)
        tk = T.get_thread_binding(1)
        A_local = T.alloc_local((TILE_K,), dtype)
        B_local = T.alloc_local((TILE_K,), dtype)
        C_accum = T.alloc_local((1,), accum_dtype)
        T.clear(C_accum)
        for bk in T.serial(T.ceildiv(K, BLOCK_K)):
            for k in T.vectorized(TILE_K):
                A_local[k] = A[bk * BLOCK_K + tk * TILE_K + k]
                B_local[k] = B[bn * BLOCK_N + tn, bk * BLOCK_K + tk * TILE_K + k]
            for k in T.serial(TILE_K):
                C_accum[0] += A_local[k].astype(accum_dtype) * B_local[k].astype(accum_dtype)
        C_reduced = T.alloc_local((1,), accum_dtype)
        with T.attr(T.comm_reducer(lambda x, y: x + y, [T.cast(0, accum_dtype)]), 'reduce_scope', T.reinterpret(T.uint64(0), dtype='handle')):
            T.evaluate(T.tvm_thread_allreduce(T.uint32(1), C_accum[0], True, C_reduced[0], tk, dtype='handle'))
        C[bn * BLOCK_N + tn] = C_reduced[0]
    return C
def build(c,p):
    return get_autotuned_kernel.compile(N=c['M'],K=c['N'],BLOCK_N=p['BM'],reduce_threads=p['reduce_threads'])
