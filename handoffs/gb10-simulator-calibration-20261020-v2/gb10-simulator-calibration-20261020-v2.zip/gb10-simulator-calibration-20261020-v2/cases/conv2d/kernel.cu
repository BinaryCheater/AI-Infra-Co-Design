#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void convolution_kernel(const half_t* __restrict__ data, __grid_constant__ const CUtensorMap kernel_flat_desc, half_t* __restrict__ out_flat);
extern "C" __global__ void __launch_bounds__(384, 1) convolution_kernel(const half_t* __restrict__ data, __grid_constant__ const CUtensorMap kernel_flat_desc, half_t* __restrict__ out_flat) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* kernel_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* out_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* data_shared = ((void*)((char*)buf_dyn_shmem + 49152));
  __shared__ __align__(16) uint64_t mbarrier_mem[6];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float out_local[64];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(kernel_flat_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(1);
    mbarrier[3].init(256);
    mbarrier[4].init(256);
    mbarrier[5].init(256);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    for (int k_iter = 0; k_iter < 18; ++k_iter) {
      mbarrier[((k_iter % 3) + 3)].wait((((k_iter % 6) / 3) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[(k_iter % 3)].arrive_and_expect_tx(16384);
        #pragma unroll
        for (int i = 0; i < 2; ++i) {
          tl::tma_load(kernel_flat_desc, mbarrier[(k_iter % 3)], (&(((half_t*)kernel_shared)[(((k_iter % 3) * 8192) + (i * 4096))])), (i * 64), (k_iter * 64));
        }
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i_1 = 0; i_1 < 16; ++i_1) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(out_local + (i_1 * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    for (int k_iter_1 = 0; k_iter_1 < 18; ++k_iter_1) {
      tl::__sync_thread_partial(3, 256);
      #pragma unroll
      for (int i_2 = 0; i_2 < 32; ++i_2) {
        half_t condval;
        if (((((((((1 <= ((k_iter_1 / 6) + (((((int)blockIdx.y) * 2) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 4080) >> 6)) & 63))) && (1 <= (((k_iter_1 % 6) >> 1) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 48) & 63)))) && (((k_iter_1 / 6) + (((((int)blockIdx.y) * 2) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 4080) >> 6)) & 63)) < 65)) && ((((k_iter_1 % 6) >> 1) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 48) & 63)) < 65)) && (1 <= (((k_iter_1 % 6) >> 1) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 48) & 63)))) && ((((k_iter_1 % 6) >> 1) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 48) & 63)) < 65)) && (1 <= ((k_iter_1 / 6) + (((((int)blockIdx.y) * 2) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 4080) >> 6)) & 63)))) && (((k_iter_1 / 6) + (((((int)blockIdx.y) * 2) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 4080) >> 6)) & 63)) < 65))) {
          condval = data[(((((((((((int)blockIdx.y) >> 5) * 524288) + ((k_iter_1 / 6) * 8192)) + ((((((int)blockIdx.y) * 2) + (((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 4080) >> 6)) & 63) * 8192)) + ((((((i_2 >> 3) * 32) + (((int)threadIdx.x) >> 3)) + 48) & 63) * 128)) + ((k_iter_1 % 6) * 64)) + ((((int)threadIdx.x) & 7) * 8)) + (i_2 & 7)) - 8320)];
        } else {
          condval = half_t(0x0p+0f/*0.000000e+00*/);
        }
        ((half_t*)data_shared)[(((((((((k_iter_1 % 3) * 8192) + ((i_2 >> 3) * 2048)) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + (i_2 & 7)) - 1024)] = condval;
      }
      mbarrier[(k_iter_1 % 3)].wait(((k_iter_1 % 6) / 3));
      {
        half_t A_local[32];
        half_t B_local[16];
        tl::__sync_thread_partial(3, 256);
        for (int ki = 0; ki < 4; ++ki) {
          #pragma unroll
          for (int i_3 = 0; i_3 < 4; ++i_3) {
            tl::ptx_ldmatrix_x4((&(((half_t*)data_shared)[((((((((k_iter_1 % 3) * 8192) + (((((int)threadIdx.x) & 63) >> 5) * 4096)) + (i_3 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_3 * 8)])));
          }
          #pragma unroll
          for (int i_4 = 0; i_4 < 2; ++i_4) {
            tl::ptx_ldmatrix_x4_trans((&(((half_t*)kernel_shared)[((((((((k_iter_1 % 3) * 8192) + (((((((int)threadIdx.x) >> 6) + 2) & 3) >> 1) * 4096)) + (ki * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 127) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + i_4) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[(i_4 * 8)])));
          }
          for (int i_5 = 0; i_5 < 4; ++i_5) {
            for (int j = 0; j < 2; ++j) {
              tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(out_local + ((i_5 * 16) + (j * 8))), reinterpret_cast<const unsigned*>(A_local + (i_5 * 8)), reinterpret_cast<const unsigned*>(B_local + (j * 8)));
              tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(out_local + (((i_5 * 16) + (j * 8)) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_5 * 8)), reinterpret_cast<const unsigned*>(B_local + ((j * 8) + 4)));
            }
          }
        }
      }
      mbarrier[((k_iter_1 % 3) + 3)].arrive();
    }
    tl::__sync_thread_partial(3, 256);
    #pragma unroll
    for (int i_6 = 0; i_6 < 8; ++i_6) {
      tl::ptx_stmatrix_m8n8_x4((&(((half_t*)out_shared)[(((((((((((int)threadIdx.x) & 63) >> 5) * 8192) + ((i_6 >> 1) * 2048)) + ((((int)threadIdx.x) & 15) * 128)) + ((((int)threadIdx.x) >> 6) * 32)) + ((i_6 & 1) * 16)) + (((((int)threadIdx.x) & 31) >> 4) * 8)) - 64)])), __pack_half2(((half_t)out_local[(i_6 * 8)]), ((half_t)out_local[((i_6 * 8) + 1)])), __pack_half2(((half_t)out_local[((i_6 * 8) + 2)]), ((half_t)out_local[((i_6 * 8) + 3)])), __pack_half2(((half_t)out_local[((i_6 * 8) + 4)]), ((half_t)out_local[((i_6 * 8) + 5)])), __pack_half2(((half_t)out_local[((i_6 * 8) + 6)]), ((half_t)out_local[((i_6 * 8) + 7)])));
    }
    tl::__sync_thread_partial(3, 256);
    if (tl::tl_shuffle_elect<256>()) {
      tl::fence_proxy_async();
      tl::tma_store((&(out_flat[(((int)blockIdx.y) * 16384)])), (&(((half_t*)out_shared)[0])), 32768);
      tl::tma_store_arrive();
      tl::tma_store_wait<0, true>();
    }
  }
}

