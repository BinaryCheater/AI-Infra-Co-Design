import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
from typing import Any, Callable, Optional
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tvm import tirx
from tilelang.carver.arch import driver

class _ZeroedSplitK:

    def __init__(self, kernel, m, n):
        self.kernel = kernel
        self.m, self.n = (m, n)
        self.out = None

    def __call__(self, a, b):
        import torch
        if self.out is None or self.out.shape != (self.m, self.n):
            self.out = torch.zeros((self.m, self.n), dtype=torch.float32, device=a.device)
        else:
            self.out.zero_()
        self.kernel(a, b, self.out)
        return self.out.half()

@tilelang.jit
def convolution(data, kernel, S, D, P, block_M, block_N, block_K, num_stages, threads, dtype=T.float16, accum_dtype=T.float32):
    N, C, H, W, F, K = T.const('N, C, H, W, F, K')
    KH, KW = (K, K)
    OH = (H + 2 * P - D * (K - 1) - 1) // S + 1
    OW = (W + 2 * P - D * (K - 1) - 1) // S + 1
    dtype = T.float16
    accum_dtype = T.float32
    data: T.Tensor((N, H, W, C), dtype)
    kernel: T.Tensor((KH, KW, C, F), dtype)
    out = T.empty((N, OH, OW, F), dtype)
    with T.Kernel(T.ceildiv(F, block_N), T.ceildiv(N * OH * OW, block_M), threads=threads) as (bx, by):
        data_shared = T.alloc_shared((block_M, block_K), dtype)
        kernel_shared = T.alloc_shared((block_K, block_N), dtype)
        out_local = T.alloc_fragment((block_M, block_N), accum_dtype)
        out_shared = T.alloc_shared((block_M, block_N), dtype)
        kernel_flat = T.Tensor((KH * KW * C, F), dtype, kernel.data)
        out_flat = T.Tensor((N * OH * OW, F), dtype, out.data)
        T.clear(out_local)
        for k_iter in T.Pipelined(T.ceildiv(KH * KW * C, block_K), num_stages=num_stages):
            T.im2col(data, data_shared, by, k_iter, KH, S, D, P)
            T.copy(kernel_flat[k_iter * block_K, bx * block_N], kernel_shared)
            T.gemm(data_shared, kernel_shared, out_local)
        T.copy(out_local, out_shared)
        T.copy(out_shared, out_flat[by * block_M, bx * block_N])
    return out

def build(c, p):
    return convolution.compile(N=c['N'], C=c['C'], H=c['H'], W=c['W'], F=c['F'], K=c['K'], S=c['S'], D=c['D'], P=c['P'], block_M=p['BM'], block_N=p['BN'], block_K=p['BK'], num_stages=p['stages'], threads=p['threads'])
