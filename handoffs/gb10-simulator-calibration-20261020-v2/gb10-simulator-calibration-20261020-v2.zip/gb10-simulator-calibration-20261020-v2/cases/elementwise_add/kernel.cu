#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void elementwise_add_kernel(const float* __restrict__ A, const float* __restrict__ B, float* __restrict__ C);
extern "C" __global__ void __launch_bounds__(256, 1) elementwise_add_kernel(const float* __restrict__ A, const float* __restrict__ B, float* __restrict__ C) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* C_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 2048));
  float C_local[2];
  *(float2*)(((float*)A_shared) + (((int)threadIdx.x) * 2)) = *(float2*)(A + (((((int)blockIdx.y) * 4096) + (((int)blockIdx.x) * 512)) + (((int)threadIdx.x) * 2)));
  *(float2*)(((float*)B_shared) + (((int)threadIdx.x) * 2)) = *(float2*)(B + (((((int)blockIdx.y) * 4096) + (((int)blockIdx.x) * 512)) + (((int)threadIdx.x) * 2)));
  float2 __1;
    float2 v_ = *(float2*)(((float*)A_shared) + (((int)threadIdx.x) * 2));
    float2 v__1 = *(float2*)(((float*)B_shared) + (((int)threadIdx.x) * 2));
    *(float2*)(&(__1.x)) = tl::add2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
  *(float2*)(C_local + 0) = __1;
  *(float2*)(((float*)C_shared) + (((int)threadIdx.x) * 2)) = *(float2*)(C_local + 0);
  __syncthreads();
  if (tl::tl_shuffle_elect<256>()) {
    tl::fence_proxy_async();
    tl::tma_store((&(C[((((int)blockIdx.y) * 4096) + (((int)blockIdx.x) * 512))])), (&(((float*)C_shared)[0])), 2048);
    tl::tma_store_arrive();
    tl::tma_store_wait<0, true>();
  }
}

