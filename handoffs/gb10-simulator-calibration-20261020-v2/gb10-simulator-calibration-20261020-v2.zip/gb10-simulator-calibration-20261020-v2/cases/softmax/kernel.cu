#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/copy_sm100.h>
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void softmax_kernel_kernel(const half_t* __restrict__ X, half_t* __restrict__ Y);
extern "C" __global__ void __launch_bounds__(128, 1) softmax_kernel_kernel(const half_t* __restrict__ X, half_t* __restrict__ Y) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* workspace = ((void*)((char*)buf_dyn_shmem + 0));
  void* workspace_1 = ((void*)((char*)buf_dyn_shmem + 0));
  float lse[2];
  half_t x[128];
  half_t max_x[2];
  float exp_x[128];
  float sum_exp_x[2];
  half_t y[128];
  float broadcast_var = -CUDART_INF_F;
  *(float2*)(lse + 0) = make_float2(broadcast_var, broadcast_var);
  #pragma unroll
  for (int i = 0; i < 8; ++i) {
    *(ulonglong4*)(x + (i * 16)) = tl::load_global_256(&(*(ulonglong4*)(X + (((((int)blockIdx.x) * 16384) + (i * 2048)) + (((int)threadIdx.x) * 16)))));
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 2; ++i_1) {
    max_x[i_1] = -std::numeric_limits<half_t>::infinity();
    #pragma unroll
    for (int rv = 0; rv < 64; ++rv) {
      max_x[i_1] = cutlass::half_t(__hmax((max_x[i_1]).to_half(), (x[(((i_1 * 64) + ((rv & 3) * 16)) + (rv >> 2))]).to_half()));
    }
    __syncthreads();
    max_x[i_1] = tl::AllReduce<tl::MaxOp, 128, 1, 0, tl::NamedBarrier<128>>::run(max_x[i_1], (&(((half_t*)workspace_1)[0])));
  }
  #pragma unroll
  for (int i_2 = 0; i_2 < 32; ++i_2) {
    float broadcast_var_1 = 0x1.7154764ee6c2fp+0f/*1.442695e+00*/;
    float4 __1;
    float4 __2;
      float4 __3;
        float4 __4;
        uint2 v_ = *(uint2*)(x + (i_2 * 4));
        ((float2*)(&__4))[0] = __half22float2(((half2*)(&v_))[0]);
        ((float2*)(&__4))[1] = __half22float2(((half2*)(&v_))[1]);
        float4 v__1 = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
        *(float2*)(&(__3.x)) = tl::mul2(*(float2*)(&(__4.x)), *(float2*)(&(v__1.x)));
        *(float2*)(&(__3.z)) = tl::mul2(*(float2*)(&(__4.z)), *(float2*)(&(v__1.z)));
      float4 v__2 = make_float4((((float)max_x[(i_2 >> 4)]) * 0x1.7154764ee6c2fp+0f/*1.442695e+00*/), (((float)max_x[(i_2 >> 4)]) * 0x1.7154764ee6c2fp+0f/*1.442695e+00*/), (((float)max_x[(i_2 >> 4)]) * 0x1.7154764ee6c2fp+0f/*1.442695e+00*/), (((float)max_x[(i_2 >> 4)]) * 0x1.7154764ee6c2fp+0f/*1.442695e+00*/));
      *(float2*)(&(__2.x)) = tl::sub2(*(float2*)(&(__3.x)), *(float2*)(&(v__2.x)));
      *(float2*)(&(__2.z)) = tl::sub2(*(float2*)(&(__3.z)), *(float2*)(&(v__2.z)));
    __1.x = exp2f(__2.x);
    __1.y = exp2f(__2.y);
    __1.z = exp2f(__2.z);
    __1.w = exp2f(__2.w);
    *(float4*)(exp_x + (i_2 * 4)) = __1;
  }
  #pragma unroll
  for (int i_3 = 0; i_3 < 2; ++i_3) {
    sum_exp_x[i_3] = 0x0p+0f/*0.000000e+00*/;
    #pragma unroll
    for (int rv_1 = 0; rv_1 < 64; ++rv_1) {
      sum_exp_x[i_3] = (sum_exp_x[i_3] + exp_x[(((i_3 * 64) + ((rv_1 & 3) * 16)) + (rv_1 >> 2))]);
    }
    __syncthreads();
    sum_exp_x[i_3] = tl::AllReduce<tl::SumOp, 128, 1, 0, tl::NamedBarrier<128>>::run(sum_exp_x[i_3], (&(((float*)workspace)[0])));
  }
  float broadcast_var_2 = 0x1.7154764ee6c2fp+0f/*1.442695e+00*/;
  float broadcast_var_3 = 0x1.7154764ee6c2fp+0f/*1.442695e+00*/;
  float2 __5;
    float2 __6;
    uint1 v__3 = *(uint1*)(max_x + 0);
    ((float2*)(&__6))[0] = __half22float2(((half2*)(&v__3))[0]);
    float2 v__4 = make_float2(broadcast_var_2, broadcast_var_2);
    float2 __7;
    float2 __8;
      float2 __9;
      float2 __10;
        float2 v__5 = *(float2*)(lse + 0);
        float2 __11;
          float2 __12;
          ((float2*)(&__12))[0] = __half22float2(((half2*)(&v__3))[0]);
          float2 v__6 = make_float2(broadcast_var_3, broadcast_var_3);
          *(float2*)(&(__11.x)) = tl::mul2(*(float2*)(&(__12.x)), *(float2*)(&(v__6.x)));
        *(float2*)(&(__10.x)) = tl::sub2(*(float2*)(&(v__5.x)), *(float2*)(&(__11.x)));
      __9.x = exp2f(__10.x);
      __9.y = exp2f(__10.y);
      float2 v__7 = *(float2*)(sum_exp_x + 0);
      *(float2*)(&(__8.x)) = tl::add2(*(float2*)(&(__9.x)), *(float2*)(&(v__7.x)));
    __7.x = log2f(__8.x);
    __7.y = log2f(__8.y);
    *(float2*)(&(__5.x)) = tl::fma2(*(float2*)(&(__6.x)), *(float2*)(&(v__4.x)), *(float2*)(&(__7.x)));
  *(float2*)(lse + 0) = __5;
  #pragma unroll
  for (int i_4 = 0; i_4 < 8; ++i_4) {
    *(ulonglong4*)(x + (i_4 * 16)) = tl::load_global_256(&(*(ulonglong4*)(X + (((((int)blockIdx.x) * 16384) + (i_4 * 2048)) + (((int)threadIdx.x) * 16)))));
  }
  #pragma unroll
  for (int i_5 = 0; i_5 < 32; ++i_5) {
    float broadcast_var_4 = 0x1.7154764ee6c2fp+0f/*1.442695e+00*/;
    uint2 __13;
    float4 __14;
    float4 __15;
      float4 __16;
        float4 __17;
        uint2 v__8 = *(uint2*)(x + (i_5 * 4));
        ((float2*)(&__17))[0] = __half22float2(((half2*)(&v__8))[0]);
        ((float2*)(&__17))[1] = __half22float2(((half2*)(&v__8))[1]);
        float4 v__9 = make_float4(broadcast_var_4, broadcast_var_4, broadcast_var_4, broadcast_var_4);
        *(float2*)(&(__16.x)) = tl::mul2(*(float2*)(&(__17.x)), *(float2*)(&(v__9.x)));
        *(float2*)(&(__16.z)) = tl::mul2(*(float2*)(&(__17.z)), *(float2*)(&(v__9.z)));
      float4 v__10 = make_float4(lse[(i_5 >> 4)], lse[(i_5 >> 4)], lse[(i_5 >> 4)], lse[(i_5 >> 4)]);
      *(float2*)(&(__15.x)) = tl::sub2(*(float2*)(&(__16.x)), *(float2*)(&(v__10.x)));
      *(float2*)(&(__15.z)) = tl::sub2(*(float2*)(&(__16.z)), *(float2*)(&(v__10.z)));
    __14.x = exp2f(__15.x);
    __14.y = exp2f(__15.y);
    __14.z = exp2f(__15.z);
    __14.w = exp2f(__15.w);
    ((half2*)(&__13))[0] = __float22half2_rn(((float2*)(&__14))[0]);
    ((half2*)(&__13))[1] = __float22half2_rn(((float2*)(&__14))[1]);
    *(uint2*)(y + (i_5 * 4)) = __13;
  }
  #pragma unroll
  for (int i_6 = 0; i_6 < 8; ++i_6) {
    tl::store_global_256(&(*(ulonglong4*)(Y + (((((int)blockIdx.x) * 16384) + (i_6 * 2048)) + (((int)threadIdx.x) * 16)))), *(ulonglong4*)(y + (i_6 * 16)));
  }
}

