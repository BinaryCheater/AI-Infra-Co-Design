import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tvm import tirx
from tilelang.carver.arch import driver

@tilelang.jit(pass_configs={'tl.disable_tma_lower': True})
def rms_norm(A, blk_m):
    M, N = T.const('M, N')
    dtype = T.float
    A: T.Tensor((M, N), dtype)
    B = T.empty((M, N), dtype)
    with T.Kernel(T.ceildiv(M, blk_m), threads=128) as bx:
        A_local = T.alloc_fragment((blk_m, N), dtype)
        A_pow_local = T.alloc_fragment((blk_m, N), dtype)
        A_powsum = T.alloc_fragment((blk_m,), dtype)
        T.copy(A[bx * blk_m:(bx + 1) * blk_m, :], A_local)
        for i, j in T.Parallel(blk_m, N):
            A_pow_local[i, j] = A_local[i, j] * A_local[i, j]
        T.reduce_sum(A_pow_local, A_powsum, dim=1)
        for i in T.Parallel(blk_m):
            A_powsum[i] = T.rsqrt(A_powsum[i] / N + 1e-12)
        for i, j in T.Parallel(blk_m, N):
            A_local[i, j] *= A_powsum[i]
        T.copy(A_local, B[bx * blk_m:(bx + 1) * blk_m, :])
    return B

def build(c, p):
    return rms_norm.compile(M=c['M'], N=c['N'], blk_m=p['BR'])
