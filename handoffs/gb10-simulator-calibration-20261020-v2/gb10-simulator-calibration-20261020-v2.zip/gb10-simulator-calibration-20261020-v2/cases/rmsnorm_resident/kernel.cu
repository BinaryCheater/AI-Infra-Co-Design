#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/copy_sm100.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void rms_norm_kernel(const float* __restrict__ A, float* __restrict__ B);
extern "C" __global__ void __launch_bounds__(128, 1) rms_norm_kernel(const float* __restrict__ A, float* __restrict__ B) {
  float A_local[64];
  float A_pow_local[64];
  float A_powsum[1];
  extern __shared__ __align__(1024) float workspace[];
  #pragma unroll
  for (int i = 0; i < 8; ++i) {
    *(ulonglong4*)(A_local + (i * 8)) = tl::load_global_256(&(*(ulonglong4*)(A + (((((int)blockIdx.x) * 8192) + (i * 1024)) + (((int)threadIdx.x) * 8)))));
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 16; ++i_1) {
    float4 __1;
      float4 v_ = *(float4*)(A_local + (i_1 * 4));
      *(float2*)(&(__1.x)) = tl::mul2(*(float2*)(&(v_.x)), *(float2*)(&(v_.x)));
      *(float2*)(&(__1.z)) = tl::mul2(*(float2*)(&(v_.z)), *(float2*)(&(v_.z)));
    *(float4*)(A_pow_local + (i_1 * 4)) = __1;
  }
  A_powsum[0] = 0x0p+0f/*0.000000e+00*/;
  #pragma unroll
  for (int rv = 0; rv < 64; ++rv) {
    A_powsum[0] = (A_powsum[0] + A_pow_local[(((rv & 7) * 8) + (rv >> 3))]);
  }
  A_powsum[0] = tl::AllReduce<tl::SumOp, 128, 1, 0, tl::NamedBarrier<128>>::run(A_powsum[0], (&(workspace[0])));
  A_powsum[0] = rsqrtf(((A_powsum[0] / 0x1p+13f/*8.192000e+03*/) + 0x1.19799812dea11p-40f/*1.000000e-12*/));
  #pragma unroll
  for (int i_2 = 0; i_2 < 16; ++i_2) {
    float4 __2;
      float4 v__1 = *(float4*)(A_local + (i_2 * 4));
      float4 v__2 = make_float4(A_powsum[0], A_powsum[0], A_powsum[0], A_powsum[0]);
      *(float2*)(&(__2.x)) = tl::mul2(*(float2*)(&(v__1.x)), *(float2*)(&(v__2.x)));
      *(float2*)(&(__2.z)) = tl::mul2(*(float2*)(&(v__1.z)), *(float2*)(&(v__2.z)));
    *(float4*)(A_local + (i_2 * 4)) = __2;
  }
  #pragma unroll
  for (int i_3 = 0; i_3 < 8; ++i_3) {
    tl::store_global_256(&(*(ulonglong4*)(B + (((((int)blockIdx.x) * 8192) + (i_3 * 1024)) + (((int)threadIdx.x) * 8)))), *(ulonglong4*)(A_local + (i_3 * 8)));
  }
}

