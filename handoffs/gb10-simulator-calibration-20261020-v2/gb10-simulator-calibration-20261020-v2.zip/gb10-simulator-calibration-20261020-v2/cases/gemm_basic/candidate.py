import os
os.environ['TILELANG_DISABLE_CACHE']='1'
"""Family gemm_basic: TileLang's examples/gemm/example_gemm.py with its integer knobs lifted to parameters (holes).
Holes: block_M, block_N, block_K, num_stages, threads. A hole left out takes the example's value."""
import tilelang
import tilelang.language as T


@tilelang.jit
def matmul(A, B, block_M=128, block_N=128, block_K=32, num_stages=3, threads=128, swizzle=0, dtype=T.float16, accum_dtype=T.float32):
    M, N, K = T.const("M, N, K")

    A: T.Tensor((M, K), dtype)
    B: T.Tensor((K, N), dtype)
    C = T.empty((M, N), dtype)

    with T.Kernel(T.ceildiv(N, block_N), T.ceildiv(M, block_M), threads=threads) as (bx, by):
        A_shared = T.alloc_shared((block_M, block_K), dtype)
        B_shared = T.alloc_shared((block_K, block_N), dtype)
        C_local = T.alloc_fragment((block_M, block_N), accum_dtype)

        T.use_swizzle(panel_size=swizzle, enable=swizzle > 0)
        T.clear(C_local)
        for k in T.Pipelined(T.ceildiv(K, block_K), num_stages=num_stages):
            T.copy(A[by * block_M, k * block_K], A_shared)
            T.copy(B[k * block_K, bx * block_N], B_shared)
            T.gemm(A_shared, B_shared, C_local)

        T.copy(C_local, C[by * block_M, bx * block_N])

    return C


def build(c, p):
    return matmul.compile(
        M=c["M"], N=c["N"], K=c["K"],
        block_M=p["block_M"], block_N=p["block_N"],
        block_K=p["block_K"], num_stages=p["num_stages"],
        threads=p["threads"], swizzle=p["swizzle"],
    )
