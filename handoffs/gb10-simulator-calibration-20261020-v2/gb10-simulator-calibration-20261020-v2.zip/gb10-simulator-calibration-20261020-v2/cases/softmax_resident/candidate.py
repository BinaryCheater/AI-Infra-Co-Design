import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import tilelang
import tilelang.language as T

def build(case, p):
    M, N = case["M"], case["N"]
    rows, cols, threads = p["rows"], (1 << (N - 1).bit_length()), p["threads"]
    @T.prim_func
    def main(A: T.Tensor((M, N), "float16"), B: T.Tensor((M, N), "float16")):
        with T.Kernel(T.ceildiv(M, rows), threads=threads) as bx:
            X = T.alloc_fragment((rows, cols), "float32")
            R = T.alloc_fragment((rows,), "float32")
            S = T.alloc_fragment((rows,), "float32")
            for i, j in T.Parallel(rows, cols):
                X[i, j] = T.if_then_else((bx * rows + i < M) & (j < N), A[bx * rows + i, j], -T.infinity("float32"))
            T.reduce_max(X, R, dim=1)
            for i, j in T.Parallel(rows, cols):
                X[i, j] = T.exp(X[i, j] - R[i])
            T.reduce_sum(X, S, dim=1)
            for i, j in T.Parallel(rows, cols):
                B[bx * rows + i, j] = X[i, j] / S[i]
    return tilelang.compile(main, out_idx=[1], target={"kind": "cuda", "arch": "sm_121"}, execution_backend="tvm_ffi", pass_configs={"tl.disable_warp_specialized": True})
