#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/copy_sm100.h>
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void main_kernel(const half_t* __restrict__ A, half_t* __restrict__ B);
extern "C" __global__ void __launch_bounds__(128, 1) main_kernel(const half_t* __restrict__ A, half_t* __restrict__ B) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* workspace = ((void*)((char*)buf_dyn_shmem + 0));
  void* workspace_1 = ((void*)((char*)buf_dyn_shmem + 0));
  float X[64];
  float R[1];
  float S[1];
  #pragma unroll
  for (int i = 0; i < 4; ++i) {
    half_t A_local_cast[16];
    *(ulonglong4*)(A_local_cast + 0) = tl::load_global_256(&(*(ulonglong4*)(A + (((((int)blockIdx.x) * 8192) + (i * 2048)) + (((int)threadIdx.x) * 16)))));
    for (int vec = 0; vec < 4; ++vec) {
      float broadcast_var = -CUDART_INF_F;
      float4 condval;
      if (((bool)1 & (bool)1)) {
        float4 __1;
        uint2 v_ = *(uint2*)(A_local_cast + (vec * 4));
        ((float2*)(&__1))[0] = __half22float2(((half2*)(&v_))[0]);
        ((float2*)(&__1))[1] = __half22float2(((half2*)(&v_))[1]);
        condval = __1;
      } else {
        condval = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
      }
      *(float4*)(X + ((i * 16) + (vec * 4))) = condval;
    }
  }
  R[0] = -CUDART_INF_F;
  #pragma unroll
  for (int rv = 0; rv < 64; ++rv) {
    R[0] = max(R[0], X[(((rv & 3) * 16) + (rv >> 2))]);
  }
  R[0] = tl::AllReduce<tl::MaxOp, 128, 1, 0, tl::NamedBarrier<128>>::run(R[0], (&(((float*)workspace_1)[0])));
  #pragma unroll
  for (int i_1 = 0; i_1 < 16; ++i_1) {
    float4 __2;
    float4 __3;
      float4 v__1 = *(float4*)(X + (i_1 * 4));
      float4 v__2 = make_float4(R[0], R[0], R[0], R[0]);
      *(float2*)(&(__3.x)) = tl::sub2(*(float2*)(&(v__1.x)), *(float2*)(&(v__2.x)));
      *(float2*)(&(__3.z)) = tl::sub2(*(float2*)(&(v__1.z)), *(float2*)(&(v__2.z)));
    __2.x = expf(__3.x);
    __2.y = expf(__3.y);
    __2.z = expf(__3.z);
    __2.w = expf(__3.w);
    *(float4*)(X + (i_1 * 4)) = __2;
  }
  S[0] = 0x0p+0f/*0.000000e+00*/;
  #pragma unroll
  for (int rv_1 = 0; rv_1 < 64; ++rv_1) {
    S[0] = (S[0] + X[(((rv_1 & 3) * 16) + (rv_1 >> 2))]);
  }
  __syncthreads();
  S[0] = tl::AllReduce<tl::SumOp, 128, 1, 0, tl::NamedBarrier<128>>::run(S[0], (&(((float*)workspace)[0])));
  #pragma unroll
  for (int i_2 = 0; i_2 < 4; ++i_2) {
    half_t B_local_cast_1[16];
    for (int vec_1 = 0; vec_1 < 4; ++vec_1) {
      uint2 __4;
      float4 __5;
        float4 v__3 = *(float4*)(X + ((i_2 * 16) + (vec_1 * 4)));
        float4 v__4 = make_float4(S[0], S[0], S[0], S[0]);
        __5.x = (v__3.x/v__4.x);
        __5.y = (v__3.y/v__4.y);
        __5.z = (v__3.z/v__4.z);
        __5.w = (v__3.w/v__4.w);
      ((half2*)(&__4))[0] = __float22half2_rn(((float2*)(&__5))[0]);
      ((half2*)(&__4))[1] = __float22half2_rn(((float2*)(&__5))[1]);
      *(uint2*)(B_local_cast_1 + (vec_1 * 4)) = __4;
    }
    tl::store_global_256(&(*(ulonglong4*)(B + (((((int)blockIdx.x) * 8192) + (i_2 * 2048)) + (((int)threadIdx.x) * 16)))), *(ulonglong4*)(B_local_cast_1 + 0));
  }
}

