import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tilelang.carver.arch import driver

@tilelang.jit(pass_configs={'tl.disable_tma_lower': True})
def rms_norm_splitk(A, blk_m, blk_k):
    M, N = T.const('M, N')
    dtype = T.float
    A: T.Tensor((M, N), dtype)
    B = T.empty((M, N), dtype)
    with T.Kernel(T.ceildiv(M, blk_m), threads=128) as bx:
        A_shared = T.alloc_shared((blk_m, blk_k), dtype)
        A_local = T.alloc_fragment((blk_m, blk_k), dtype)
        A_powsum = T.alloc_fragment((blk_m,), dtype)
        num_k_step = T.ceildiv(N, blk_k)
        T.clear(A_local)
        for k in T.Serial(num_k_step):
            T.copy(A[bx * blk_m, k * blk_k], A_shared)
            for i, j in T.Parallel(blk_m, blk_k):
                A_local[i, j] += A_shared[i, j] * A_shared[i, j]
        T.reduce_sum(A_local, A_powsum, dim=1)
        for i in T.Parallel(blk_m):
            A_powsum[i] = T.rsqrt(A_powsum[i] / N + 1e-12)
        for k in T.Serial(num_k_step):
            T.copy(A[bx * blk_m, (num_k_step - 1 - k) * blk_k], A_shared)
            for i, j in T.Parallel(blk_m, blk_k):
                A_shared[i, j] *= A_powsum[i]
            T.copy(A_shared, B[bx * blk_m, (num_k_step - 1 - k) * blk_k])
    return B

def build(c, p):
    return rms_norm_splitk.compile(M=c['M'], N=c['N'], blk_m=p['BR'], blk_k=p['BC'])
