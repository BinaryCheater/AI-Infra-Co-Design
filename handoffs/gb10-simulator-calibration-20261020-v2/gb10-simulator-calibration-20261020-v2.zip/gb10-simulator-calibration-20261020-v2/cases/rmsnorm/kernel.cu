#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void rms_norm_splitk_kernel(const float* __restrict__ A, float* __restrict__ B);
extern "C" __global__ void __launch_bounds__(128, 1) rms_norm_splitk_kernel(const float* __restrict__ A, float* __restrict__ B) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* workspace = ((void*)((char*)buf_dyn_shmem + 1024));
  float A_local[2];
  float2 A_powsum_pack[1];
  float A_powsum[1];
  float broadcast_var = 0x0p+0f/*0.000000e+00*/;
  *(float2*)(A_local + 0) = make_float2(broadcast_var, broadcast_var);
  for (int k = 0; k < 32; ++k) {
    *(float2*)(((float*)A_shared) + (((int)threadIdx.x) * 2)) = *(float2*)(A + (((((int)blockIdx.x) * 8192) + (k * 256)) + (((int)threadIdx.x) * 2)));
    float2 __1;
      float2 v_ = *(float2*)(((float*)A_shared) + (((int)threadIdx.x) * 2));
      float2 v__1 = *(float2*)(A_local + 0);
      *(float2*)(&(__1.x)) = tl::fma2(*(float2*)(&(v_.x)), *(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
    *(float2*)(A_local + 0) = __1;
  }
  float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
  A_powsum_pack[0] = make_float2(broadcast_var_1, broadcast_var_1);
  A_powsum_pack[0] = tl::add2(A_powsum_pack[0], *(float2*)(A_local + 0));
  A_powsum[0] = ((A_powsum_pack[0]).x + (A_powsum_pack[0]).y);
  __syncthreads();
  A_powsum[0] = tl::AllReduce<tl::SumOp, 128, 1, 0, tl::NamedBarrier<128>>::run(A_powsum[0], (&(((float*)workspace)[0])));
  A_powsum[0] = rsqrtf(((A_powsum[0] / 0x1p+13f/*8.192000e+03*/) + 0x1.19799812dea11p-40f/*1.000000e-12*/));
  __syncthreads();
  for (int k_1 = 0; k_1 < 32; ++k_1) {
    *(float2*)(((float*)A_shared) + (((int)threadIdx.x) * 2)) = *(float2*)(A + ((((((int)blockIdx.x) * 8192) + (((int)threadIdx.x) * 2)) + 7936) - (k_1 * 256)));
    float2 __2;
      float2 v__2 = *(float2*)(((float*)A_shared) + (((int)threadIdx.x) * 2));
      float2 v__3 = make_float2(A_powsum[0], A_powsum[0]);
      *(float2*)(&(__2.x)) = tl::mul2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
    *(float2*)(((float*)A_shared) + (((int)threadIdx.x) * 2)) = __2;
    *(float2*)(B + ((((((int)blockIdx.x) * 8192) + (((int)threadIdx.x) * 2)) + 7936) - (k_1 * 256))) = *(float2*)(((float*)A_shared) + (((int)threadIdx.x) * 2));
  }
}

