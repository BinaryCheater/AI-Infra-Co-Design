import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
from typing import Any, Callable, Optional
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tvm import tirx
from tilelang.carver.arch import driver

class _ZeroedSplitK:

    def __init__(self, kernel, m, n):
        self.kernel = kernel
        self.m, self.n = (m, n)
        self.out = None

    def __call__(self, a, b):
        import torch
        if self.out is None or self.out.shape != (self.m, self.n):
            self.out = torch.zeros((self.m, self.n), dtype=torch.float32, device=a.device)
        else:
            self.out.zero_()
        self.kernel(a, b, self.out)
        return self.out.half()

def _tir_packed_to_unsigned_convert(storage_type='uint', storage_nbit=8):
    storage_dtype = storage_type + str(storage_nbit)

    def f_convert(nbit: int, val: tvm.tirx.PrimExpr, pos: tvm.tirx.PrimExpr, dtype: str):
        assert val.dtype == storage_dtype, f'{val.dtype} != {storage_dtype}'
        mask = tvm.tirx.const((1 << nbit) - 1, storage_dtype)
        return (val >> (pos * nbit).astype(storage_dtype) & mask).astype(dtype)
    return f_convert

@tilelang.jit(out_idx=[2])
def matmul(M, N, K, block_M, block_N, block_K, in_dtype, out_dtype, accum_dtype, num_stages, threads, num_bits=4):
    num_elems_per_byte = 8 // num_bits
    storage_dtype = T.int8
    storage_nbit = int(''.join((c for c in storage_dtype if c.isdigit())))
    storage_type = str(''.join((c for c in storage_dtype if not c.isdigit())))
    A_shape = (M, K)
    B_shape = (N, K // num_elems_per_byte)
    A_shared_shape = (block_M, block_K)
    B_shared_shape = (block_N, block_K // num_elems_per_byte)
    B_dequantize_shared_shape = (block_N, block_K)
    MAX_TRANSACTION_SIZE_IN_BITS = 128
    local_size = MAX_TRANSACTION_SIZE_IN_BITS // DataType(in_dtype).bits
    local_size_compressed = local_size // num_elems_per_byte

    @T.prim_func
    def main(A: T.Tensor(A_shape, in_dtype), B: T.Tensor(B_shape, storage_dtype), C: T.Tensor((M, N), out_dtype)):
        with T.Kernel(T.ceildiv(N, block_N), T.ceildiv(M, block_M), threads=threads) as (bx, by):
            A_shared = T.alloc_shared(A_shared_shape, in_dtype)
            B_shared = T.alloc_shared(B_shared_shape, storage_dtype)
            B_local = T.alloc_local([local_size_compressed], storage_dtype)
            B_dequantize_local = T.alloc_local([local_size], in_dtype)
            B_dequantize_shared = T.alloc_shared(B_dequantize_shared_shape, in_dtype)
            C_local = T.alloc_fragment((block_M, block_N), accum_dtype)
            tx = T.get_thread_binding()
            T.clear(C_local)
            for k in T.Pipelined(T.ceildiv(K, block_K), num_stages=num_stages):
                T.copy(A[by * block_M, k * block_K], A_shared)
                T.copy(B[bx * block_N, k * block_K // num_elems_per_byte], B_shared)
                for i in T.serial(block_N * block_K // num_elems_per_byte // (threads * local_size_compressed)):
                    for v in T.vectorized(0, local_size_compressed):
                        index = i * threads * local_size_compressed + tx * local_size_compressed + v
                        vi = index // (block_K // num_elems_per_byte)
                        vj = index % (block_K // num_elems_per_byte)
                        B_local[v] = B_shared[vi, vj]
                    for v in T.serial(0, local_size):
                        B_dequantize_local[v] = _tir_packed_to_unsigned_convert(storage_type, storage_nbit)(num_bits, B_local[v // num_elems_per_byte], v % num_elems_per_byte, dtype=in_dtype)
                    for v in T.vectorized(0, local_size):
                        index = i * threads * local_size + tx * local_size + v
                        vi = index // block_K
                        vj = index % block_K
                        B_dequantize_shared[vi, vj] = B_dequantize_local[v]
                T.gemm(A_shared, B_dequantize_shared, C_local, transpose_B=True)
            T.copy(C_local, C[by * block_M, bx * block_N])
    return main

def build(c, p):
    return matmul(c['M'], c['N'], c['K'], p['BM'], p['BN'], p['BK'], 'float16', 'float16', 'float32', p['stages'], p['threads'])
