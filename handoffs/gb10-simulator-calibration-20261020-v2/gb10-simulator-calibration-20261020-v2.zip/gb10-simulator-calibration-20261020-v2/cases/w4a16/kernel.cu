#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void main_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap B_desc, half_t* __restrict__ C);
extern "C" __global__ void __launch_bounds__(384, 1) main_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap B_desc, half_t* __restrict__ C) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 12288));
  void* B_dequantize_shared = ((void*)((char*)buf_dyn_shmem + 18432));
  __shared__ __align__(16) uint64_t mbarrier_mem[12];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float C_local[8];
  signed char B_local[4];
  half_t B_dequantize_local[8];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(A_desc);
    tl::prefetch_tma_descriptor(B_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(1);
    mbarrier[3].init(1);
    mbarrier[4].init(1);
    mbarrier[5].init(1);
    mbarrier[6].init(256);
    mbarrier[7].init(256);
    mbarrier[8].init(256);
    mbarrier[9].init(256);
    mbarrier[10].init(256);
    mbarrier[11].init(256);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    for (int k = 0; k < 64; ++k) {
      mbarrier[((k % 3) + 6)].wait((((k % 6) / 3) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[(k % 3)].arrive_and_expect_tx(2048);
        tl::tma_load(A_desc, mbarrier[(k % 3)], (&(((half_t*)A_shared)[((k % 3) * 1024)])), (k * 64), 0);
      }
      mbarrier[((k % 3) + 9)].wait((((k % 6) / 3) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[((k % 3) + 3)].arrive_and_expect_tx(4096);
        tl::tma_load(B_desc, mbarrier[((k % 3) + 3)], (&(((signed char*)B_shared)[((k % 3) * 4096)])), (k * 32), (((int)blockIdx.x) * 128));
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i = 0; i < 2; ++i) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(C_local + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    for (int k_1 = 0; k_1 < 64; ++k_1) {
      mbarrier[((k_1 % 3) + 3)].wait(((k_1 % 6) / 3));
      tl::__sync_thread_partial(3, 256);
      for (int i_1 = 0; i_1 < 4; ++i_1) {
        *(int*)(B_local + 0) = *(int*)(((signed char*)B_shared) + (((((k_1 % 3) * 4096) + (i_1 * 1024)) + (((int)threadIdx.x) * 4)) - 512));
        for (int v = 0; v < 8; ++v) {
          B_dequantize_local[v] = ((half_t)((B_local[(v >> 1)] >> ((signed char)((v & 1) * 4))) & (signed char)15));
        }
        *(uint4*)(((half_t*)B_dequantize_shared) + ((((((i_1 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) - 1024)) = *(uint4*)(B_dequantize_local + 0);
      }
      mbarrier[((k_1 % 3) + 9)].arrive();
      mbarrier[(k_1 % 3)].wait(((k_1 % 6) / 3));
      {
        half_t A_local[8];
        half_t B_local_1[8];
        tl::__sync_thread_partial(3, 256);
        for (int ki = 0; ki < 4; ++ki) {
          tl::ptx_ldmatrix_x4((&(((half_t*)A_shared)[((((((k_1 % 3) * 1024) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[0])));
          tl::ptx_ldmatrix_x4((&(((half_t*)B_dequantize_shared)[(((((((((((int)threadIdx.x) >> 5) + 4) & 7) * 1024) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_1[0])));
          tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_local + 0), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local_1 + 0));
          tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_local + 4), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local_1 + 4));
        }
      }
      mbarrier[((k_1 % 3) + 6)].arrive();
    }
    #pragma unroll
    for (int i_2 = 0; i_2 < 4; ++i_2) {
      half_t C_local_cast[2];
      if ((((i_2 & 1) * 8) + ((((int)threadIdx.x) & 31) >> 2)) < 1) {
        uint1 __1;
        float2 v_ = *(float2*)(C_local + (i_2 * 2));
        ((half2*)(&__1))[0] = __float22half2_rn(((float2*)(&v_))[0]);
        *(uint1*)(C_local_cast + 0) = __1;
        *(uint1*)(C + ((((((((i_2 & 1) * 114688) + (((((int)threadIdx.x) & 31) >> 2) * 14336)) + (((int)blockIdx.x) * 128)) + ((((int)threadIdx.x) >> 5) * 16)) + ((i_2 >> 1) * 8)) + ((((int)threadIdx.x) & 3) * 2)) - 64)) = *(uint1*)(C_local_cast + 0);
      }
    }
  }
}

