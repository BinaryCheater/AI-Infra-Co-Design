import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
from typing import Any, Callable, Optional
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tvm import tirx
from tilelang.carver.arch import driver

class _ZeroedSplitK:

    def __init__(self, kernel, m, n):
        self.kernel = kernel
        self.m, self.n = (m, n)
        self.out = None

    def __call__(self, a, b):
        import torch
        if self.out is None or self.out.shape != (self.m, self.n):
            self.out = torch.zeros((self.m, self.n), dtype=torch.float32, device=a.device)
        else:
            self.out.zero_()
        self.kernel(a, b, self.out)
        return self.out.half()

def _tir_packed_to_unsigned_convert(storage_type='uint', storage_nbit=8):
    storage_dtype = storage_type + str(storage_nbit)

    def f_convert(nbit: int, val: tvm.tirx.PrimExpr, pos: tvm.tirx.PrimExpr, dtype: str):
        assert val.dtype == storage_dtype, f'{val.dtype} != {storage_dtype}'
        mask = tvm.tirx.const((1 << nbit) - 1, storage_dtype)
        return (val >> (pos * nbit).astype(storage_dtype) & mask).astype(dtype)
    return f_convert

@tilelang.jit(**{'target': {'kind': 'cuda', 'arch': 'sm_121'}, 'execution_backend': 'tvm_ffi', 'pass_configs': {'tl.disable_warp_specialized': True}, 'out_idx': [2]})
def dequantize_gemv(M: int, N: int, K: int, in_dtype: str, out_dtype: str, accum_dtype: str, num_bits: int=4, storage_dtype: T.dtype=T.int8, source_format: str='uint', n_partition: int=4, reduce_thread: int=32, fast_decoding: bool=False, trans_A: bool=False, trans_B: bool=True, group_size: int=-1, with_scaling: bool=False) -> Callable[..., Any]:
    assert n_partition is not None, 'n_partition must be provided'
    assert reduce_thread is not None, 'reduce_thread must be provided currently, as related bitblas.gpu.gemv.GEMVsch_outer_reduction_with_config is not implemented'
    assert trans_A is False, 'Dequantize only implement for trans_A=False currently'
    assert trans_B is True, 'Dequantize only implement for trans_B=TRue currently'
    storage_type = ''.join((c for c in storage_dtype if not c.isdigit()))
    storage_nbit = int(''.join((c for c in storage_dtype if c.isdigit())))
    num_elems_per_byte = storage_nbit // num_bits
    MAX_TRANSACTION_SIZE_IN_BITS = 128
    micro_size_k = MAX_TRANSACTION_SIZE_IN_BITS // DataType(in_dtype).bits
    micro_size_k_compressed = micro_size_k // num_elems_per_byte
    block_K = reduce_thread * micro_size_k
    if group_size == -1:
        group_size = K
    A_shape = (M, K)
    B_shape = (N, K // storage_nbit * num_bits)
    C_shape = (M, N)
    dp4a_size = 4
    use_dp4a = in_dtype == T.int8 and accum_dtype == T.int32
    import_source: Optional[str] = None
    func_name: str = ''
    if fast_decoding is True:
        from quantize import get_lop3_intrin_group
        lop3_intrin_info = get_lop3_intrin_group(out_dtype=in_dtype, source_format=source_format, source_bit=num_bits, storage_dtype=storage_dtype, with_scaling=with_scaling, with_zeros=False)
        import_source = lop3_intrin_info['c_source']
        func_name = lop3_intrin_info['func_name']
        assert import_source is not None, 'lop3_intrin_info is not found'
        assert func_name is not None, 'lop3_intrin_info is not found'
        import_source = import_source

    @T.prim_func
    def main(A: T.Tensor[A_shape, in_dtype], B: T.Tensor[B_shape, storage_dtype], C: T.Tensor[C_shape, out_dtype]):
        with T.Kernel(T.ceildiv(N, n_partition), M, threads=(reduce_thread, n_partition)) as (bx, by):
            A_local = T.alloc_local((micro_size_k,), in_dtype)
            B_quant_local = T.alloc_local([micro_size_k_compressed], storage_dtype)
            B_dequantize_local = T.alloc_local([micro_size_k], in_dtype)
            accum_res = T.alloc_local((1,), accum_dtype)
            reduced_accum_res = T.alloc_local((1,), accum_dtype)
            kr = T.thread_binding(0, reduce_thread, thread='threadIdx.x')
            ni = T.thread_binding(0, n_partition, thread='threadIdx.y')
            T.import_source(import_source)
            T.clear(accum_res)
            for ko in T.serial(T.ceildiv(K, block_K)):
                for v in T.vectorized(micro_size_k):
                    A_local[v] = A[by, ko * block_K + kr * micro_size_k + v]
                for v in T.vectorized(micro_size_k_compressed):
                    B_quant_local[v] = B[bx * n_partition + ni, ko * (reduce_thread * micro_size_k_compressed) + kr * micro_size_k_compressed + v]
                if fast_decoding:
                    T.call_extern(func_name, T.access_ptr(B_quant_local, 'r'), T.access_ptr(B_dequantize_local, 'w'), dtype=in_dtype)
                else:
                    for ki in T.serial(micro_size_k):
                        B_dequantize_local[ki] = _tir_packed_to_unsigned_convert(storage_type, storage_nbit)(num_bits, B_quant_local[ki // num_elems_per_byte], ki % num_elems_per_byte, in_dtype)
                if use_dp4a:
                    for ki in T.serial(micro_size_k // dp4a_size):
                        T.dp4a(A_local[ki * dp4a_size], B_dequantize_local[ki * dp4a_size], accum_res[0])
                else:
                    for ki in T.serial(micro_size_k):
                        accum_res[0] += T.cast(A_local[ki], accum_dtype) * T.cast(B_dequantize_local[ki], accum_dtype)
            with T.attr(T.comm_reducer(lambda x, y: x + y, [T.cast(0, accum_dtype)]), 'reduce_scope', T.reinterpret(T.uint64(0), dtype='handle')):
                T.evaluate(T.tvm_thread_allreduce(T.uint32(1), accum_res[0], True, reduced_accum_res[0], kr, dtype='handle'))
            if kr == 0:
                C[by, bx * n_partition + ni] = reduced_accum_res[0]
    return main

def build(c, p):
    return dequantize_gemv(c['M'], c['N'], c['K'], 'float16', 'float16', 'float32', num_bits=4, storage_dtype='int8', n_partition=p['n_partition'], reduce_thread=p['reduce_thread'], fast_decoding=False)
