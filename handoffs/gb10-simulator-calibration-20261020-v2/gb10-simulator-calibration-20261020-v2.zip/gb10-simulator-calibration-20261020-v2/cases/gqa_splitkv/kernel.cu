#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void flashattn_gqa_decode_split_kernel(const half_t* __restrict__ K, __grid_constant__ const CUtensorMap Output_partial_desc, const half_t* __restrict__ Q, const half_t* __restrict__ V, half_t* __restrict__ glse, const uchar* __restrict__ mask);
extern "C" __global__ void flashattn_gqa_decode_split_kernel_1(half_t* __restrict__ Output, const half_t* __restrict__ Output_partial, const half_t* __restrict__ glse);
extern "C" __global__ void __launch_bounds__(128, 1) flashattn_gqa_decode_split_kernel(const half_t* __restrict__ K, __grid_constant__ const CUtensorMap Output_partial_desc, const half_t* __restrict__ Q, const half_t* __restrict__ V, half_t* __restrict__ glse, const uchar* __restrict__ mask) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* O_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* Q_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* K_shared = ((void*)((char*)buf_dyn_shmem + 16384));
  void* V_shared = ((void*)((char*)buf_dyn_shmem + 32768));
  float acc_o[64];
  float logsum[2];
  float scores_max[2];
  uchar mask_local[16];
  float acc_s[32];
  float scores_max_prev[2];
  float scores_scale[2];
  float scores_sum[2];
  half_t acc_s_cast[32];
  float scores_max_clear[2];
  float scores_max_clear_1[2];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(Output_partial_desc);
  }
  #pragma unroll
  for (int i = 0; i < 8; ++i) {
    half_t broadcast_var = half_t(0x0p+0f/*0.000000e+00*/);
    uint4 condval;
    if ((((((((int)threadIdx.x) >> 6) + ((int)blockIdx.y)) >> 1) + i) < 4)) {
      condval = *(uint4*)(Q + ((((((int)blockIdx.x) * 4096) + (i * 1024)) + (((int)blockIdx.y) * 512)) + (((int)threadIdx.x) * 8)));
    } else {
      condval = make_uint4(__pack_half2(broadcast_var, broadcast_var), __pack_half2(broadcast_var, broadcast_var), __pack_half2(broadcast_var, broadcast_var), __pack_half2(broadcast_var, broadcast_var));
    }
    *(uint4*)(((half_t*)Q_shared) + ((((((((((int)threadIdx.x) & 15) >> 3) * 4096) + (i * 512)) + ((((int)threadIdx.x) >> 4) * 64)) + ((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))) = condval;
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 16; ++i_1) {
    float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(acc_o + (i_1 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
  }
  float broadcast_var_2 = 0x0p+0f/*0.000000e+00*/;
  *(float2*)(logsum + 0) = make_float2(broadcast_var_2, broadcast_var_2);
  float broadcast_var_3 = -CUDART_INF_F;
  *(float2*)(scores_max + 0) = make_float2(broadcast_var_3, broadcast_var_3);
  __syncthreads();
  #pragma unroll
  for (int i_2 = 0; i_2 < 8; ++i_2) {
    tl::cp_async_gs<16>((&(((half_t*)K_shared)[((((((((((int)threadIdx.x) & 15) >> 3) * 4096) + (i_2 * 512)) + ((((int)threadIdx.x) >> 4) * 64)) + ((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(K[((((((((int)blockIdx.x) * 16777216) + (((int)blockIdx.z) * 2097152)) + (i_2 * 8192)) + ((((int)threadIdx.x) >> 4) * 1024)) + (((int)blockIdx.y) * 128)) + ((((int)threadIdx.x) & 15) * 8))])));
  }
  tl::cp_async_commit();
  #pragma unroll
  for (int i_3 = 0; i_3 < 8; ++i_3) {
    tl::cp_async_gs<16>((&(((half_t*)V_shared)[((((((((((int)threadIdx.x) & 15) >> 3) * 4096) + (i_3 * 512)) + ((((int)threadIdx.x) >> 4) * 64)) + ((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(V[((((((((int)blockIdx.x) * 16777216) + (((int)blockIdx.z) * 2097152)) + (i_3 * 8192)) + ((((int)threadIdx.x) >> 4) * 1024)) + (((int)blockIdx.y) * 128)) + ((((int)threadIdx.x) & 15) * 8))])));
  }
  tl::cp_async_commit();
  for (int k = 0; k < 31; ++k) {
    #pragma unroll
    for (int i_4 = 0; i_4 < 16; ++i_4) {
      mask_local[i_4] = mask[(((((((((int)blockIdx.x) * 131072) + (((int)blockIdx.z) * 16384)) + (k * 512)) + ((i_4 >> 1) * 64)) + ((((int)threadIdx.x) & 3) * 16)) + ((i_4 & 1) * 8)) + ((int)blockIdx.y))];
    }
    #pragma unroll
    for (int i_5 = 0; i_5 < 8; ++i_5) {
      float broadcast_var_4 = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(acc_s + (i_5 * 4)) = make_float4(broadcast_var_4, broadcast_var_4, broadcast_var_4, broadcast_var_4);
    }
    tl::cp_async_wait<1>();
    __syncthreads();
    {
      half_t A_local[8];
      half_t B_local[32];
      for (int ki = 0; ki < 8; ++ki) {
        tl::ptx_ldmatrix_x4((&(((half_t*)Q_shared)[(((((((ki >> 2) * 4096) + ((((int)threadIdx.x) >> 5) * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[0])));
        #pragma unroll
        for (int i_6 = 0; i_6 < 4; ++i_6) {
          tl::ptx_ldmatrix_x4((&(((half_t*)K_shared)[((((((((ki >> 2) * 4096) + (i_6 * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[(i_6 * 8)])));
        }
        for (int j = 0; j < 4; ++j) {
          tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_s + (j * 8)), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local + (j * 8)));
          tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_s + ((j * 8) + 4)), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local + ((j * 8) + 4)));
        }
      }
    }
    __syncthreads();
    #pragma unroll
    for (int i_7 = 0; i_7 < 8; ++i_7) {
      tl::cp_async_gs<16>((&(((half_t*)K_shared)[((((((((((int)threadIdx.x) & 15) >> 3) * 4096) + (i_7 * 512)) + ((((int)threadIdx.x) >> 4) * 64)) + ((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(K[((((((((((int)blockIdx.x) * 16777216) + (((int)blockIdx.z) * 2097152)) + (k * 65536)) + (i_7 * 8192)) + ((((int)threadIdx.x) >> 4) * 1024)) + (((int)blockIdx.y) * 128)) + ((((int)threadIdx.x) & 15) * 8)) + 65536)])));
    }
    tl::cp_async_commit();
    #pragma unroll
    for (int i_8 = 0; i_8 < 32; ++i_8) {
      float condval_1;
      if (((0 < ((int)mask_local[(((i_8 >> 2) * 2) + (i_8 & 1))])) & (bool)1)) {
        condval_1 = acc_s[i_8];
      } else {
        condval_1 = -CUDART_INF_F;
      }
      acc_s[i_8] = condval_1;
    }
    *(float2*)(scores_max_prev + 0) = *(float2*)(scores_max + 0);
    float broadcast_var_5 = -CUDART_INF_F;
    *(float2*)(scores_max + 0) = make_float2(broadcast_var_5, broadcast_var_5);
    #pragma unroll
    for (int i_9 = 0; i_9 < 2; ++i_9) {
      scores_max_clear[i_9] = -CUDART_INF_F;
      #pragma unroll
      for (int rv = 0; rv < 16; ++rv) {
        scores_max_clear[i_9] = max(scores_max_clear[i_9], acc_s[((((rv & 7) * 4) + (i_9 * 2)) + (rv >> 3))]);
      }
      scores_max_clear[i_9] = tl::AllReduce<tl::MaxOp, 4, 1, 0, tl::NamedBarrier<128>>::run(scores_max_clear[i_9]);
      scores_max[i_9] = max(scores_max[i_9], scores_max_clear[i_9]);
    }
    float2 __1;
      float2 v_ = *(float2*)(scores_max + 0);
      float2 v__1 = *(float2*)(scores_max_prev + 0);
      *(float2*)(&(__1.x)) = tl::max2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
    *(float2*)(scores_max + 0) = __1;
    float broadcast_var_6 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
    float broadcast_var_7 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
    float2 __2;
    float2 __3;
      float2 __4;
        float2 v__2 = *(float2*)(scores_max_prev + 0);
        float2 v__3 = make_float2(broadcast_var_6, broadcast_var_6);
        *(float2*)(&(__4.x)) = tl::mul2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
      float2 __5;
        float2 v__4 = *(float2*)(scores_max + 0);
        float2 v__5 = make_float2(broadcast_var_7, broadcast_var_7);
        *(float2*)(&(__5.x)) = tl::mul2(*(float2*)(&(v__4.x)), *(float2*)(&(v__5.x)));
      *(float2*)(&(__3.x)) = tl::sub2(*(float2*)(&(__4.x)), *(float2*)(&(__5.x)));
    __2.x = exp2f(__3.x);
    __2.y = exp2f(__3.y);
    *(float2*)(scores_scale + 0) = __2;
    #pragma unroll
    for (int i_10 = 0; i_10 < 16; ++i_10) {
      float broadcast_var_8 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
      float2 __6;
      float2 __7;
        float2 __8;
          float2 v__6 = *(float2*)(acc_s + (i_10 * 2));
          float2 v__7 = make_float2(broadcast_var_8, broadcast_var_8);
          *(float2*)(&(__8.x)) = tl::mul2(*(float2*)(&(v__6.x)), *(float2*)(&(v__7.x)));
        float2 v__8 = make_float2((scores_max[(i_10 & 1)] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/), (scores_max[(i_10 & 1)] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/));
        *(float2*)(&(__7.x)) = tl::sub2(*(float2*)(&(__8.x)), *(float2*)(&(v__8.x)));
      __6.x = exp2f(__7.x);
      __6.y = exp2f(__7.y);
      *(float2*)(acc_s + (i_10 * 2)) = __6;
    }
    #pragma unroll
    for (int i_11 = 0; i_11 < 2; ++i_11) {
      scores_sum[i_11] = 0x0p+0f/*0.000000e+00*/;
      #pragma unroll
      for (int rv_1 = 0; rv_1 < 16; ++rv_1) {
        scores_sum[i_11] = (scores_sum[i_11] + acc_s[((((rv_1 & 7) * 4) + (i_11 * 2)) + (rv_1 >> 3))]);
      }
      scores_sum[i_11] = tl::AllReduce<tl::SumOp, 4, 1, 0, tl::NamedBarrier<128>>::run(scores_sum[i_11]);
    }
    float2 __9;
      float2 v__9 = *(float2*)(logsum + 0);
      float2 v__10 = *(float2*)(scores_scale + 0);
      float2 v__11 = *(float2*)(scores_sum + 0);
      *(float2*)(&(__9.x)) = tl::fma2(*(float2*)(&(v__9.x)), *(float2*)(&(v__10.x)), *(float2*)(&(v__11.x)));
    *(float2*)(logsum + 0) = __9;
    #pragma unroll
    for (int i_12 = 0; i_12 < 8; ++i_12) {
      uint2 __10;
      float4 v__12 = *(float4*)(acc_s + (i_12 * 4));
      ((half2*)(&__10))[0] = __float22half2_rn(((float2*)(&v__12))[0]);
      ((half2*)(&__10))[1] = __float22half2_rn(((float2*)(&v__12))[1]);
      *(uint2*)(acc_s_cast + (i_12 * 4)) = __10;
    }
    #pragma unroll
    for (int i_13 = 0; i_13 < 32; ++i_13) {
      float2 __11;
        float2 v__13 = *(float2*)(acc_o + (i_13 * 2));
        float2 v__14 = make_float2(scores_scale[(i_13 & 1)], scores_scale[(i_13 & 1)]);
        *(float2*)(&(__11.x)) = tl::mul2(*(float2*)(&(v__13.x)), *(float2*)(&(v__14.x)));
      *(float2*)(acc_o + (i_13 * 2)) = __11;
    }
    tl::cp_async_wait<1>();
    __syncthreads();
    {
      half_t B_local_1[64];
      for (int ki_1 = 0; ki_1 < 4; ++ki_1) {
        #pragma unroll
        for (int i_14 = 0; i_14 < 8; ++i_14) {
          tl::ptx_ldmatrix_x4_trans((&(((half_t*)V_shared)[(((((((i_14 >> 2) * 4096) + (ki_1 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((i_14 & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (i_14 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_1[(i_14 * 8)])));
        }
        for (int j_1 = 0; j_1 < 8; ++j_1) {
          tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_o + (j_1 * 8)), reinterpret_cast<const unsigned*>(acc_s_cast + (ki_1 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + (j_1 * 8)));
          tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_o + ((j_1 * 8) + 4)), reinterpret_cast<const unsigned*>(acc_s_cast + (ki_1 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + ((j_1 * 8) + 4)));
        }
      }
    }
    __syncthreads();
    #pragma unroll
    for (int i_15 = 0; i_15 < 8; ++i_15) {
      tl::cp_async_gs<16>((&(((half_t*)V_shared)[((((((((((int)threadIdx.x) & 15) >> 3) * 4096) + (i_15 * 512)) + ((((int)threadIdx.x) >> 4) * 64)) + ((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(V[((((((((((int)blockIdx.x) * 16777216) + (((int)blockIdx.z) * 2097152)) + (k * 65536)) + (i_15 * 8192)) + ((((int)threadIdx.x) >> 4) * 1024)) + (((int)blockIdx.y) * 128)) + ((((int)threadIdx.x) & 15) * 8)) + 65536)])));
    }
    tl::cp_async_commit();
  }
  #pragma unroll
  for (int i_16 = 0; i_16 < 16; ++i_16) {
    mask_local[i_16] = mask[(((((((((int)blockIdx.x) * 131072) + (((int)blockIdx.z) * 16384)) + ((i_16 >> 1) * 64)) + ((((int)threadIdx.x) & 3) * 16)) + ((i_16 & 1) * 8)) + ((int)blockIdx.y)) + 15872)];
  }
  #pragma unroll
  for (int i_17 = 0; i_17 < 8; ++i_17) {
    float broadcast_var_9 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(acc_s + (i_17 * 4)) = make_float4(broadcast_var_9, broadcast_var_9, broadcast_var_9, broadcast_var_9);
  }
  tl::cp_async_wait<1>();
  __syncthreads();
  {
    half_t A_local_1[8];
    half_t B_local_2[32];
    for (int ki_2 = 0; ki_2 < 8; ++ki_2) {
      tl::ptx_ldmatrix_x4((&(((half_t*)Q_shared)[(((((((ki_2 >> 2) * 4096) + ((((int)threadIdx.x) >> 5) * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki_2 & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local_1[0])));
      #pragma unroll
      for (int i_18 = 0; i_18 < 4; ++i_18) {
        tl::ptx_ldmatrix_x4((&(((half_t*)K_shared)[((((((((ki_2 >> 2) * 4096) + (i_18 * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki_2 & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_2[(i_18 * 8)])));
      }
      for (int j_2 = 0; j_2 < 4; ++j_2) {
        tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_s + (j_2 * 8)), reinterpret_cast<const unsigned*>(A_local_1 + 0), reinterpret_cast<const unsigned*>(B_local_2 + (j_2 * 8)));
        tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_s + ((j_2 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local_1 + 0), reinterpret_cast<const unsigned*>(B_local_2 + ((j_2 * 8) + 4)));
      }
    }
  }
  #pragma unroll
  for (int i_19 = 0; i_19 < 32; ++i_19) {
    float condval_2;
    if (((0 < ((int)mask_local[(((i_19 >> 2) * 2) + (i_19 & 1))])) & (bool)1)) {
      condval_2 = acc_s[i_19];
    } else {
      condval_2 = -CUDART_INF_F;
    }
    acc_s[i_19] = condval_2;
  }
  *(float2*)(scores_max_prev + 0) = *(float2*)(scores_max + 0);
  float broadcast_var_10 = -CUDART_INF_F;
  *(float2*)(scores_max + 0) = make_float2(broadcast_var_10, broadcast_var_10);
  #pragma unroll
  for (int i_20 = 0; i_20 < 2; ++i_20) {
    scores_max_clear_1[i_20] = -CUDART_INF_F;
    #pragma unroll
    for (int rv_2 = 0; rv_2 < 16; ++rv_2) {
      scores_max_clear_1[i_20] = max(scores_max_clear_1[i_20], acc_s[((((rv_2 & 7) * 4) + (i_20 * 2)) + (rv_2 >> 3))]);
    }
    scores_max_clear_1[i_20] = tl::AllReduce<tl::MaxOp, 4, 1, 0, tl::NamedBarrier<128>>::run(scores_max_clear_1[i_20]);
    scores_max[i_20] = max(scores_max[i_20], scores_max_clear_1[i_20]);
  }
  float2 __12;
    float2 v__15 = *(float2*)(scores_max + 0);
    float2 v__16 = *(float2*)(scores_max_prev + 0);
    *(float2*)(&(__12.x)) = tl::max2(*(float2*)(&(v__15.x)), *(float2*)(&(v__16.x)));
  *(float2*)(scores_max + 0) = __12;
  float broadcast_var_11 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
  float broadcast_var_12 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
  float2 __13;
  float2 __14;
    float2 __15;
      float2 v__17 = *(float2*)(scores_max_prev + 0);
      float2 v__18 = make_float2(broadcast_var_11, broadcast_var_11);
      *(float2*)(&(__15.x)) = tl::mul2(*(float2*)(&(v__17.x)), *(float2*)(&(v__18.x)));
    float2 __16;
      float2 v__19 = *(float2*)(scores_max + 0);
      float2 v__20 = make_float2(broadcast_var_12, broadcast_var_12);
      *(float2*)(&(__16.x)) = tl::mul2(*(float2*)(&(v__19.x)), *(float2*)(&(v__20.x)));
    *(float2*)(&(__14.x)) = tl::sub2(*(float2*)(&(__15.x)), *(float2*)(&(__16.x)));
  __13.x = exp2f(__14.x);
  __13.y = exp2f(__14.y);
  *(float2*)(scores_scale + 0) = __13;
  #pragma unroll
  for (int i_21 = 0; i_21 < 16; ++i_21) {
    float broadcast_var_13 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
    float2 __17;
    float2 __18;
      float2 __19;
        float2 v__21 = *(float2*)(acc_s + (i_21 * 2));
        float2 v__22 = make_float2(broadcast_var_13, broadcast_var_13);
        *(float2*)(&(__19.x)) = tl::mul2(*(float2*)(&(v__21.x)), *(float2*)(&(v__22.x)));
      float2 v__23 = make_float2((scores_max[(i_21 & 1)] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/), (scores_max[(i_21 & 1)] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/));
      *(float2*)(&(__18.x)) = tl::sub2(*(float2*)(&(__19.x)), *(float2*)(&(v__23.x)));
    __17.x = exp2f(__18.x);
    __17.y = exp2f(__18.y);
    *(float2*)(acc_s + (i_21 * 2)) = __17;
  }
  #pragma unroll
  for (int i_22 = 0; i_22 < 2; ++i_22) {
    scores_sum[i_22] = 0x0p+0f/*0.000000e+00*/;
    #pragma unroll
    for (int rv_3 = 0; rv_3 < 16; ++rv_3) {
      scores_sum[i_22] = (scores_sum[i_22] + acc_s[((((rv_3 & 7) * 4) + (i_22 * 2)) + (rv_3 >> 3))]);
    }
    scores_sum[i_22] = tl::AllReduce<tl::SumOp, 4, 1, 0, tl::NamedBarrier<128>>::run(scores_sum[i_22]);
  }
  float2 __20;
    float2 v__24 = *(float2*)(logsum + 0);
    float2 v__25 = *(float2*)(scores_scale + 0);
    float2 v__26 = *(float2*)(scores_sum + 0);
    *(float2*)(&(__20.x)) = tl::fma2(*(float2*)(&(v__24.x)), *(float2*)(&(v__25.x)), *(float2*)(&(v__26.x)));
  *(float2*)(logsum + 0) = __20;
  #pragma unroll
  for (int i_23 = 0; i_23 < 8; ++i_23) {
    uint2 __21;
    float4 v__27 = *(float4*)(acc_s + (i_23 * 4));
    ((half2*)(&__21))[0] = __float22half2_rn(((float2*)(&v__27))[0]);
    ((half2*)(&__21))[1] = __float22half2_rn(((float2*)(&v__27))[1]);
    *(uint2*)(acc_s_cast + (i_23 * 4)) = __21;
  }
  #pragma unroll
  for (int i_24 = 0; i_24 < 32; ++i_24) {
    float2 __22;
      float2 v__28 = *(float2*)(acc_o + (i_24 * 2));
      float2 v__29 = make_float2(scores_scale[(i_24 & 1)], scores_scale[(i_24 & 1)]);
      *(float2*)(&(__22.x)) = tl::mul2(*(float2*)(&(v__28.x)), *(float2*)(&(v__29.x)));
    *(float2*)(acc_o + (i_24 * 2)) = __22;
  }
  tl::cp_async_wait<0>();
  __syncthreads();
  {
    half_t B_local_3[64];
    for (int ki_3 = 0; ki_3 < 4; ++ki_3) {
      #pragma unroll
      for (int i_25 = 0; i_25 < 8; ++i_25) {
        tl::ptx_ldmatrix_x4_trans((&(((half_t*)V_shared)[(((((((i_25 >> 2) * 4096) + (ki_3 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((i_25 & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (i_25 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_3[(i_25 * 8)])));
      }
      for (int j_3 = 0; j_3 < 8; ++j_3) {
        tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_o + (j_3 * 8)), reinterpret_cast<const unsigned*>(acc_s_cast + (ki_3 * 8)), reinterpret_cast<const unsigned*>(B_local_3 + (j_3 * 8)));
        tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_o + ((j_3 * 8) + 4)), reinterpret_cast<const unsigned*>(acc_s_cast + (ki_3 * 8)), reinterpret_cast<const unsigned*>(B_local_3 + ((j_3 * 8) + 4)));
      }
    }
  }
  #pragma unroll
  for (int i_26 = 0; i_26 < 32; ++i_26) {
    float2 __23;
      float2 v__30 = *(float2*)(acc_o + (i_26 * 2));
      float2 v__31 = make_float2(logsum[(i_26 & 1)], logsum[(i_26 & 1)]);
      __23.x = (v__30.x/v__31.x);
      __23.y = (v__30.y/v__31.y);
    *(float2*)(acc_o + (i_26 * 2)) = __23;
  }
  float broadcast_var_14 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
  float2 __24;
    float2 v__32 = *(float2*)(scores_max + 0);
    float2 v__33 = make_float2(broadcast_var_14, broadcast_var_14);
    float2 __25;
    float2 v__34 = *(float2*)(logsum + 0);
    __25.x = log2f(v__34.x);
    __25.y = log2f(v__34.y);
    *(float2*)(&(__24.x)) = tl::fma2(*(float2*)(&(v__32.x)), *(float2*)(&(v__33.x)), *(float2*)(&(__25.x)));
  *(float2*)(logsum + 0) = __24;
  if ((((int)threadIdx.x) % 4) == 0) {
    #pragma unroll
    for (int i_27 = 0; i_27 < 2; ++i_27) {
      if (((((((int)threadIdx.x) >> 5) * 4) + (i_27 * 2)) + ((((int)threadIdx.x) & 31) >> 4)) < 1) {
        glse[((((((((int)blockIdx.x) * 256) + ((((int)threadIdx.x) >> 5) * 128)) + (i_27 * 64)) + (((int)blockIdx.y) * 32)) + (((((int)threadIdx.x) & 31) >> 2) * 8)) + ((int)blockIdx.z))] = ((half_t)logsum[i_27]);
      }
    }
  }
  __syncthreads();
  #pragma unroll
  for (int i_28 = 0; i_28 < 32; ++i_28) {
    half_t O_shared_local_cast[2];
    if (((((((int)threadIdx.x) >> 5) * 4) + ((i_28 & 1) * 2)) + ((((int)threadIdx.x) & 31) >> 4)) < 1) {
      uint1 __26;
      float2 v__35 = *(float2*)(acc_o + (i_28 * 2));
      ((half2*)(&__26))[0] = __float22half2_rn(((float2*)(&v__35))[0]);
      *(uint1*)(O_shared_local_cast + 0) = __26;
      *(uint1*)(((half_t*)O_shared) + ((((((((int)threadIdx.x) >> 5) * 2048) + ((i_28 & 1) * 1024)) + (((((int)threadIdx.x) & 31) >> 2) * 128)) + ((i_28 >> 1) * 8)) + ((((int)threadIdx.x) & 3) * 2))) = *(uint1*)(O_shared_local_cast + 0);
    }
  }
  __syncthreads();
  if (tl::tl_shuffle_elect<128>()) {
    tl::fence_proxy_async();
    tl::tma_store(Output_partial_desc, (&(((half_t*)O_shared)[0])), 0, (((int)blockIdx.y) * 4), ((int)blockIdx.z), ((int)blockIdx.x));
    tl::tma_store_arrive();
    tl::tma_store_wait<0, true>();
  }
}

extern "C" __global__ void __launch_bounds__(128, 1) flashattn_gqa_decode_split_kernel_1(half_t* __restrict__ Output, const half_t* __restrict__ Output_partial, const half_t* __restrict__ glse) {
  float lse_logsum_local[1];
  float o_accum_local[1];
  half_t lse_local[8];
  float2 lse_max_local_pack[1];
  float lse_max_local[1];
  half_t po_local[1];
  float scale_local[1];
  lse_logsum_local[0] = 0x0p+0f/*0.000000e+00*/;
  o_accum_local[0] = 0x0p+0f/*0.000000e+00*/;
  *(uint4*)(lse_local + 0) = *(uint4*)(glse + ((((int)blockIdx.y) * 256) + (((int)blockIdx.x) * 8)));
  float broadcast_var = -CUDART_INF_F;
  lse_max_local_pack[0] = make_float2(broadcast_var, broadcast_var);
  #pragma unroll
  for (int rv = 0; rv < 4; ++rv) {
    float2 __1;
    uint1 v_ = *(uint1*)(lse_local + (rv * 2));
    ((float2*)(&__1))[0] = __half22float2(((half2*)(&v_))[0]);
    lse_max_local_pack[0] = tl::max2(lse_max_local_pack[0], __1);
  }
  lse_max_local[0] = max((lse_max_local_pack[0]).x, (lse_max_local_pack[0]).y);
  for (int k = 0; k < 8; ++k) {
    lse_logsum_local[0] = (lse_logsum_local[0] + exp2f((((float)lse_local[k]) - lse_max_local[0])));
  }
  lse_logsum_local[0] = (log2f(lse_logsum_local[0]) + lse_max_local[0]);
  for (int k_1 = 0; k_1 < 8; ++k_1) {
    po_local[0] = Output_partial[((((((int)blockIdx.y) * 32768) + (((int)blockIdx.x) * 1024)) + (k_1 * 128)) + ((int)threadIdx.x))];
    scale_local[0] = exp2f((((float)lse_local[k_1]) - lse_logsum_local[0]));
    o_accum_local[0] = (o_accum_local[0] + (((float)po_local[0]) * scale_local[0]));
  }
  Output[(((((int)blockIdx.y) * 4096) + (((int)blockIdx.x) * 128)) + ((int)threadIdx.x))] = ((half_t)o_accum_local[0]);
}

