import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
from typing import Any, Callable, Optional
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tvm import tirx
from tilelang.carver.arch import driver

class _ZeroedSplitK:

    def __init__(self, kernel, m, n):
        self.kernel = kernel
        self.m, self.n = (m, n)
        self.out = None

    def __call__(self, a, b):
        import torch
        if self.out is None or self.out.shape != (self.m, self.n):
            self.out = torch.zeros((self.m, self.n), dtype=torch.float32, device=a.device)
        else:
            self.out.zero_()
        self.kernel(a, b, self.out)
        return self.out.half()

@tilelang.jit
def matmul(A, B, C, block_M, block_N, block_K, split_k, dtype=T.float16, accum_dtype=T.float32, out_dtype=T.float32):
    M, N, K = T.const('M, N, K')
    splitK = K // split_k
    A: T.Tensor((M, K), dtype)
    B: T.Tensor((K, N), dtype)
    C: T.Tensor((M, N), out_dtype)
    with T.Kernel(T.ceildiv(N, block_N), T.ceildiv(M, block_M), split_k, threads=128) as (bx, by, bz):
        A_shared = T.alloc_shared((block_M, block_K), dtype)
        B_shared = T.alloc_shared((block_K, block_N), dtype)
        C_local = T.alloc_fragment((block_M, block_N), accum_dtype)
        T.clear(C_local)
        for ko in T.Pipelined(T.ceildiv(splitK, block_K), num_stages=0):
            T.copy(A[by * block_M, bz * splitK + ko * block_K], A_shared)
            T.copy(B[bz * splitK + ko * block_K, bx * block_N], B_shared)
            T.gemm(A_shared, B_shared, C_local)
        for i, j in T.Parallel(block_M, block_N):
            T.atomic_add(C[by * block_M + i, bx * block_N + j], C_local[i, j])

def build(c, p):
    return _ZeroedSplitK(matmul.compile(M=c['M'], N=c['N'], K=c['K'], block_M=p['BM'], block_N=p['BN'], block_K=p['BK'], split_k=p['split']), c['M'], c['N'])

_ZeroedSplitK.get_kernel_source = lambda self: self.kernel.get_kernel_source()
_ZeroedSplitK.adapter = property(lambda self: self.kernel.adapter)
_ZeroedSplitK._tilelang_cache_path = property(lambda self: self.kernel._tilelang_cache_path)
