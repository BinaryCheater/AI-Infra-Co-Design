#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void kernel_kernel(const half_t* __restrict__ G, float* __restrict__ G_new);
extern "C" __global__ void __launch_bounds__(256, 1) kernel_kernel(const half_t* __restrict__ G, float* __restrict__ G_new) {
  __shared__ __align__(16) float G_shared[64];
  if (((int)threadIdx.x) < 64) {
    G_shared[((int)threadIdx.x)] = ((float)G[(((((((int)blockIdx.y) >> 5) * 262144) + (((int)blockIdx.x) * 2048)) + (((int)threadIdx.x) * 32)) + (((int)blockIdx.y) & 31))]);
  }
  __syncthreads();
  tl::CumSum2D<256, 1, false>::run((&(G_shared[0])), (&(G_shared[0])), 1, 64, 64, 64);
  __syncthreads();
  if (((int)threadIdx.x) < 64) {
    G_new[(((((((int)blockIdx.y) >> 5) * 262144) + (((int)blockIdx.x) * 2048)) + (((int)threadIdx.x) * 32)) + (((int)blockIdx.y) & 31))] = G_shared[((int)threadIdx.x)];
  }
}

