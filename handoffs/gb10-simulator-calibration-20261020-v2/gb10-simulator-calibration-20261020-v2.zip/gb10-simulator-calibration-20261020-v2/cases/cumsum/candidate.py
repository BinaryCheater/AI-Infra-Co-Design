import os
os.environ['TILELANG_DISABLE_CACHE']='1'
import math
from typing import Any, Callable, Optional
import tilelang
import tilelang as tl
import tilelang.language as T
from tilelang import tvm
from tvm import DataType
from tvm import tirx
from tilelang.carver.arch import driver

class _ZeroedSplitK:

    def __init__(self, kernel, m, n):
        self.kernel = kernel
        self.m, self.n = (m, n)
        self.out = None

    def __call__(self, a, b):
        import torch
        if self.out is None or self.out.shape != (self.m, self.n):
            self.out = torch.zeros((self.m, self.n), dtype=torch.float32, device=a.device)
        else:
            self.out.zero_()
        self.kernel(a, b, self.out)
        return self.out.half()

@tilelang.jit(out_idx=[-1], pass_configs={tilelang.PassConfigKey.TL_DISABLE_WARP_SPECIALIZED: True})
def tilelang_chunk_local_cumsum_scalar(B, S, H, chunk_size=64, is_varlen=False, head_first=False, reverse=False, input_dtype=T.float16, output_dtype=T.float32, block_S=64, threads=256, use_fragment=False):
    G_shape = (B, H, S) if head_first else (B, S, H)
    assert chunk_size == 2 ** (chunk_size.bit_length() - 1), 'chunk_size must be a power of 2'
    assert chunk_size == block_S, 'chunk_size must be equal to block_S'

    @T.prim_func
    def kernel(G: T.Tensor(G_shape, dtype=input_dtype), G_new: T.Tensor(G_shape, dtype=output_dtype)):
        with T.Kernel(T.ceildiv(S, block_S), B * H, threads=threads) as (bs, bbh):
            bb, bh = (bbh // H, bbh % H)
            G_shared = T.alloc_shared((1, block_S), dtype=output_dtype, scope='shared')
            if head_first:
                T.copy(G[bb, bh, bs * block_S:(bs + 1) * block_S], G_shared)
            else:
                T.copy(G[bb, bs * block_S:(bs + 1) * block_S, bh], G_shared)
            if use_fragment:
                G_fragment = T.alloc_fragment((1, block_S), dtype=output_dtype, scope='shared')
                T.copy(G_shared, G_fragment)
                T.cumsum(G_fragment, dim=1, reverse=reverse)
                if head_first:
                    T.copy(G_fragment, G_new[bb, bh, bs * block_S:(bs + 1) * block_S])
                else:
                    T.copy(G_fragment, G_new[bb, bs * block_S:(bs + 1) * block_S, bh])
            else:
                T.cumsum(G_shared, dim=1, reverse=reverse)
                if head_first:
                    T.copy(G_shared, G_new[bb, bh, bs * block_S:(bs + 1) * block_S])
                else:
                    T.copy(G_shared, G_new[bb, bs * block_S:(bs + 1) * block_S, bh])
    return kernel

def build(c, p):
    return tilelang_chunk_local_cumsum_scalar(c['B'], c['S'], c['H'], chunk_size=64, block_S=64, threads=p['threads'], use_fragment=p['use_fragment'])
