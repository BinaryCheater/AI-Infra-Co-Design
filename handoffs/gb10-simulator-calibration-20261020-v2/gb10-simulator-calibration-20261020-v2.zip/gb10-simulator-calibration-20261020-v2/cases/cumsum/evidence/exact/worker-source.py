"""Bounded Spark worker. Receipts contain real compilation, tests or CUDA timings.

Executed only in a unique remote job directory. Input source is authorized generated
code, not a security sandbox. stdout is one JSON object; compiler logs go to stderr.
"""

import contextlib
import fcntl
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import signal
import statistics
import struct
import subprocess
import sys
import threading
import time
from pathlib import Path


@contextlib.contextmanager
def gpu_lock(path=None):
    """Serialize this project's workers before they create CUDA contexts."""
    file = Path(path or "/home/memx/dingyi/agentic-codesign/gpu0.lock")
    with file.open("a") as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError(
                "GPU is owned by another project worker; no parallel measurement"
            ) from error
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def require_idle_peers():
    """Reject surviving/external GPU contexts; a lock only covers this project."""
    peers = []
    for _ in range(20):
        raw = subprocess.run(
            [
                "nvidia-smi",
                "-i",
                "0",
                "--query-compute-apps=pid",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=5,
            check=True,
        ).stdout
        peers = [
            int(x.strip())
            for x in raw.splitlines()
            if x.strip().isdigit() and int(x.strip()) != os.getpid()
        ]
        if not peers:
            return
        time.sleep(0.25)
    raise ValueError(
        f"Other GPU process(es) still active: {peers}; measurement refused"
    )


def digest(data):
    return hashlib.sha256(data).hexdigest()


def compiler_metadata(kernel, case_name):
    """Read lowered device IR; logical buffers are not physical resources."""
    mod = getattr(kernel.adapter, "device_mod", None)
    if mod is None:
        mod = getattr(getattr(kernel, "artifact", None), "device_mod", None)
    if mod is None:
        mod = getattr(getattr(kernel.adapter, "wrapper", None), "device_mod", None)
    if mod is None:
        return {"available": False, "reason": "Adapter did not retain device IR"}
    from tvm import tirx

    text = str(mod)
    Path(case_name + ".device-ir.txt").write_text(text)
    entries = []
    for _, func in mod.functions.items():
        attrs = func.attrs
        if attrs is None or "global_symbol" not in attrs:
            continue
        extents = {}

        def visit(node):
            if isinstance(node, tirx.AttrStmt) and node.attr_key == "thread_extent":
                extents[str(node.node.thread_tag)] = str(node.value)

        tirx.stmt_functor.post_order_visit(func.body, visit)
        entries.append(
            {
                "symbol": str(attrs["global_symbol"]),
                "launch_extents": extents,
                "dynamic_shared_bytes": int(attrs["dyn_shared_memory_buf"])
                if "dyn_shared_memory_buf" in attrs
                else None,
            }
        )
    return {
        "available": True,
        "device_ir_sha256": digest(text.encode()),
        "entries": entries,
        "scope": "Lowered compiler IR entries and extents, not a runtime timeline",
    }


def gqa_inputs(case, seed, pattern, device="cuda"):
    """Independent dense FP32 reference; empty visible-key sets yield zero."""
    import torch

    torch.manual_seed(seed)
    b, hq, hkv, length, dim = (case[k] for k in ("B", "Hq", "Hkv", "L", "D"))
    q = torch.randn((b, hq, dim), device=device, dtype=torch.float16)
    k = torch.randn((b, length, hkv, dim), device=device, dtype=torch.float16)
    v = torch.randn_like(k)
    mask = torch.ones((b, length, hkv), device=device, dtype=torch.uint8)
    if pattern == "zeros":
        q.zero_()
        k.zero_()
        v.zero_()
    elif pattern == "extreme":
        q.mul_(20)
        k.mul_(20)
    elif pattern == "holes":
        mask = torch.randint(0, 2, mask.shape, device=device, dtype=torch.uint8)
        mask[:, -1, :] = 1
    elif pattern == "empty_split":
        mask[:, : length // 2, :] = 0
    elif pattern == "all_masked":
        mask.zero_()
    elif pattern == "one_key":
        mask.zero_()
        mask[:, -1, :] = 1
    elif pattern == "head_groups":
        q.zero_()
        for head in range(hkv):
            v[:, :, head, :] = (head + 1) / max(1, hkv)
    elif pattern != "random":
        raise ValueError("Unknown GQA check pattern")
    group = hq // hkv
    kr = k.float().repeat_interleave(group, dim=2).permute(0, 2, 1, 3)
    vr = v.float().repeat_interleave(group, dim=2).permute(0, 2, 1, 3)
    visible = mask.bool().repeat_interleave(group, dim=2).permute(0, 2, 1).unsqueeze(2)
    score = (q.float().unsqueeze(2) @ kr.transpose(-1, -2)) * dim**-0.5
    nonempty = visible.any(-1, keepdim=True)
    score = score.masked_fill(~visible, -torch.inf)
    safe_score = torch.where(nonempty, score, torch.zeros_like(score))
    weights = torch.where(nonempty, torch.softmax(safe_score, -1), 0)
    reference = (weights @ vr).squeeze(2).half()
    return (q, k, v, mask), reference


def run(payload):
    import torch

    generic_compile = (
        payload["phase"] in ("compile", "check")
        and payload["workload"].get("execution_abi") == "kernel-lab-v1"
    )
    if (
        not generic_compile
        and payload["phase"] not in ("baseline", "tune", "transformer")
        and payload["workload"]["operator"]
        not in (
            "gemm",
            "softmax",
            "gqa_decode",
        )
    ):
        raise ValueError("Unregistered worker semantic ABI")
    torch.backends.cuda.matmul.allow_tf32 = False

    def cancelled():
        while not Path("cancel").exists():
            time.sleep(0.1)
        os.killpg(os.getpgrp(), signal.SIGTERM)

    Path("process.json").write_text(
        json.dumps({"pid": os.getpid(), "pgid": os.getpgrp()})
    )
    threading.Thread(target=cancelled, daemon=True).start()

    if importlib.metadata.version("tilelang") != "0.1.15":
        raise ValueError("Pinned TileLang 0.1.15 required")
    props = torch.cuda.get_device_properties(0)
    if (props.major, props.minor) != (12, 1):
        raise ValueError("This model/target requires SM121; no target fallback")
    if (
        payload.get("hardware", {}).get("sms", props.multi_processor_count)
        != props.multi_processor_count
    ):
        raise ValueError("Remote SM count differs from frozen hardware")
    if payload["phase"] in (
        "tune",
        "baseline",
        "measure",
        "check",
        "transformer",
    ) and not overlap_allowed(payload):
        require_idle_peers()
    if payload["phase"] == "transformer":
        Path("candidate.py").write_text(payload["source"])
        spec = importlib.util.spec_from_file_location(
            "candidate", Path("candidate.py").resolve()
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if payload["workload"].get("operator") == "llama_paired_replay":
            return module.run(payload, props)
        from transformer_runtime import run as transformer_run

        return transformer_run(payload, props, module)
    if payload["phase"] == "tune":
        from tuning import run as tuning_run

        return tuning_run(payload, props)
    if payload["phase"] == "baseline" or (
        payload["phase"] in ("compile", "check")
        and payload.get("workload", {}).get("execution_abi") == "kernel-lab-v1"
    ):
        from baseline import run as baseline_run

        return baseline_run(payload, props)
    source = payload["source"]
    Path("candidate.py").write_text(source)
    spec = importlib.util.spec_from_file_location(
        "candidate", Path("candidate.py").resolve()
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for case in payload["workload"]["cases"]:
        begin = time.monotonic()
        kernel = module.build(case, payload["assignment"])
        cuda = kernel.get_kernel_source()
        Path(case["name"] + ".cu").write_text(cuda)
        binary = getattr(kernel.adapter, "libpath", None)
        if not binary:
            binary = getattr(
                getattr(kernel.adapter, "lib_generator", None), "libpath", None
            )
        if not binary:
            cache = getattr(kernel, "_tilelang_cache_path", None)
            candidate = Path(cache) / "executable.so" if cache else None
            binary = str(candidate) if candidate and candidate.is_file() else None
        if not binary or not Path(binary).is_file():
            raise ValueError("Compiled adapter library missing; cannot bind binary")
        binary_sha = digest(Path(binary).read_bytes())
        # TVM serializes device modules inside its host .so. Extract embedded
        # CUDA ELF images, including section and program tables, from that exact library.
        data = Path(binary).read_bytes()
        images, position = [], 0
        while True:
            position = data.find(b"\x7fELF", position)
            if position < 0:
                break
            image = data[position:]
            position += 4
            if (
                len(image) < 64
                or image[4:6] != b"\x02\x01"
                or struct.unpack_from("<H", image, 18)[0] != 190
            ):
                continue
            phoff, shoff = struct.unpack_from("<QQ", image, 32)
            phent, phnum, shent, shnum = struct.unpack_from("<HHHH", image, 54)
            size = max(64, phoff + phent * phnum, shoff + shent * shnum)
            if shent < 64 or size > len(image):
                raise ValueError("Malformed serialized CUDA ELF")
            for index in range(shnum):
                offset = shoff + index * shent
                kind = struct.unpack_from("<I", image, offset + 4)[0]
                section_offset, section_size = struct.unpack_from(
                    "<QQ", image, offset + 24
                )
                if kind != 8:
                    size = max(size, section_offset + section_size)
            for index in range(phnum):
                offset = phoff + index * phent
                segment_offset = struct.unpack_from("<Q", image, offset + 8)[0]
                segment_size = struct.unpack_from("<Q", image, offset + 32)[0]
                size = max(size, segment_offset + segment_size)
            if size > len(image):
                raise ValueError("Truncated serialized CUDA ELF")
            cubin = image[:size]
            path = Path(case["name"] + f"-{len(images)}.cubin")
            path.write_bytes(cubin)
            dump = subprocess.run(
                ["/usr/local/cuda/bin/cuobjdump", "--dump-resource-usage", str(path)],
                capture_output=True,
                text=True,
                timeout=30,
                check=True,
            )
            images.append(
                {
                    "sha256": digest(cubin),
                    "bytes": len(cubin),
                    "resources_raw": dump.stdout,
                }
            )
        if not images:
            raise ValueError(
                "No bound CUDA ELF in compiled TVM library; no fabricated resource record"
            )
        row = {
            "case": case["name"],
            "cuda_source": cuda,
            "cuda_sha256": digest(cuda.encode()),
            "binary_sha256": binary_sha,
            "binary_path": str(binary),
            "resources_raw": "\n".join(x["resources_raw"] for x in images),
            "device_binaries": images,
            "resource_scope": "cuobjdump static per-thread registers, static shared/stack/local; dynamic shared is additionally checked by actual launch, not inferred from source buffers. No achieved occupancy trace.",
            "compile_seconds": time.monotonic() - begin,
            "compiler_metadata": compiler_metadata(kernel, case["name"]),
        }
        expected = payload.get("compiled", {}).get(case["name"])
        if expected and (
            expected["binary_sha256"] != binary_sha
            or expected["cuda_sha256"] != row["cuda_sha256"]
        ):
            raise ValueError("Rebuilt binary/source differs from realized artifact")
        if payload["phase"] != "compile":
            dtype = torch.float16

            def inputs(seed, pattern):
                if payload["workload"]["operator"] == "gqa_decode":
                    return gqa_inputs(case, seed, pattern)
                torch.manual_seed(seed)
                shape = (
                    case["M"],
                    case["K"]
                    if payload["workload"]["operator"] == "gemm"
                    else case["N"],
                )
                a = torch.randn(shape, device="cuda", dtype=dtype)
                if pattern == "zeros":
                    a.zero_()
                elif pattern == "extreme":
                    a.mul_(10 if payload["workload"]["operator"] == "softmax" else 0.1)
                if payload["workload"]["operator"] == "gemm":
                    b = torch.randn((case["K"], case["N"]), device="cuda", dtype=dtype)
                    return (a, b), (a.float() @ b.float()).half()
                return (a,), torch.softmax(a.float(), dim=-1).half()

            checks = []
            patterns = [(17, "random"), (29, "zeros"), (41, "extreme")]
            if payload["workload"]["operator"] == "gqa_decode":
                patterns += [
                    (53, "holes"),
                    (67, "empty_split"),
                    (71, "all_masked"),
                    (83, "one_key"),
                    (97, "head_groups"),
                ]
            for seed, pattern in patterns:
                args, reference = inputs(seed, pattern)
                actual = kernel(*args)
                torch.cuda.synchronize()
                softmax = payload["workload"]["operator"] == "softmax"
                rtol = 0.01
                atol = 0.0001 if softmax else (0.0 if pattern == "zeros" else 0.01)
                passed = (
                    isinstance(actual, torch.Tensor)
                    and actual.shape == reference.shape
                    and actual.dtype == reference.dtype
                    and bool(torch.isfinite(actual).all())
                    and torch.allclose(actual, reference, rtol=rtol, atol=atol)
                )
                normalized = (
                    bool(
                        torch.allclose(
                            actual.float().sum(dim=-1),
                            torch.ones(case["M"], device="cuda"),
                            rtol=0.005,
                            atol=0.005,
                        )
                    )
                    if softmax
                    else None
                )
                if softmax:
                    passed = passed and normalized and bool((actual >= 0).all())
                checks.append(
                    {
                        "seed": seed,
                        "pattern": pattern,
                        "passed": passed,
                        "max_abs_error": float(
                            (actual.float() - reference.float()).abs().max()
                        ),
                        "rtol": rtol,
                        "atol": atol,
                        "row_normalized": normalized,
                    }
                )
            row["checks"] = checks
            if not all(x["passed"] for x in checks):
                row["correct"] = False
            else:
                row["correct"] = True
            if payload["phase"] == "measure" and row["correct"]:
                if payload["workload"]["operator"] == "gqa_decode":
                    args, _ = inputs(17, "random")
                    row["timed_input_pattern"] = "random_all_valid"
                for _ in range(10):
                    kernel(*args)
                torch.cuda.synchronize()
                graph = torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):
                    for _ in range(30):
                        kernel(*args)
                graph.replay()
                torch.cuda.synchronize()
                samples = []
                # Batched CUDA events amortize timer quantization; no host launch time claim.
                for _ in range(7):
                    start, stop = (
                        torch.cuda.Event(enable_timing=True),
                        torch.cuda.Event(enable_timing=True),
                    )
                    start.record()
                    graph.replay()
                    stop.record()
                    stop.synchronize()
                    samples.append(start.elapsed_time(stop) * 1000 / 30)
                row.update(
                    latency_us=statistics.median(samples),
                    samples_us=samples,
                    warmup=10,
                    launches_per_sample=30,
                    callable_invocations_per_sample=30,
                    timing="cuda-event-graph-replay-v1",
                    timing_boundary="Complete compiled callable, including split/combine and device graph gaps. Input/reference creation and CPU allocation excluded. 30 callable invocations, not necessarily 30 device kernels.",
                )
        rows.append(row)
    driver = subprocess.run(
        ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
        capture_output=True,
        text=True,
        timeout=10,
        check=True,
    ).stdout.strip()
    return {
        "phase": payload["phase"],
        "job_directory": str(Path.cwd()),
        "source_sha256": digest(source.encode()),
        "assignment": payload["assignment"],
        "cases": rows,
        "environment": {
            "hostname": os.uname().nodename,
            "gpu": props.name,
            "sms": props.multi_processor_count,
            "compute_capability": f"{props.major}.{props.minor}",
            "tilelang": importlib.metadata.version("tilelang"),
            "torch": torch.__version__,
            "driver": driver,
            "python": sys.version,
            "worker_sha256": digest(Path(__file__).read_bytes()),
        },
    }


def overlap_allowed(payload):
    return (
        payload.get("phase") == "baseline"
        and payload.get("workload", {}).get("execution_abi") == "kernel-lab-v1"
        and payload.get("execution_policy", {}).get("allow_overlap") is True
    )


def peer_sample():
    raw = subprocess.run(
        [
            "nvidia-smi",
            "-i",
            "0",
            "--query-compute-apps=pid",
            "--format=csv,noheader,nounits",
        ],
        capture_output=True,
        text=True,
        timeout=5,
    )
    return {
        "time": time.time(),
        "other_compute_pids": [
            int(v.strip())
            for v in raw.stdout.splitlines()
            if v.strip().isdigit() and int(v.strip()) != os.getpid()
        ],
        "query_returncode": raw.returncode,
    }


if __name__ == "__main__":
    payload = json.load(sys.stdin)
    concurrent = overlap_allowed(payload)
    before = peer_sample() if concurrent else None
    with (
        contextlib.redirect_stdout(sys.stderr),
        contextlib.nullcontext() if concurrent else gpu_lock(),
    ):
        result = run(payload)
    result["execution_policy"] = {
        **payload.get("execution_policy", {}),
        "allow_overlap": concurrent,
        "peer_samples": [before, peer_sample()] if concurrent else [],
        "limits": "Boundary process samples only; no continuous overlap trace. Concurrent timings may include contention."
        if concurrent
        else "Project GPU lock and idle-peer checks enabled.",
    }
    print(json.dumps(result))
