"""Baseline semantics and timing; invoked by the existing bounded Spark worker.

This module adds evaluation ABIs, not optimizer/model ABIs.
"""

import hashlib
import importlib.metadata
import importlib.util
import os
import statistics
import subprocess
import sys
import time
import traceback
from pathlib import Path


def unpack(w):
    import torch

    u = w.to(torch.uint8)
    return torch.stack((u & 15, (u >> 4) & 15), dim=-1).reshape(w.shape[0], -1).half()


def sparse_mask(c, device):
    import torch

    n = c["L"] // 64
    block = torch.eye(n, device=device, dtype=torch.bool)
    block[:, 0] = True
    return block.expand(c["B"], c["heads"], n, n).contiguous()


def dense_mask(block, length):
    import torch

    return (
        block.repeat_interleave(64, -2).repeat_interleave(64, -1)
        & torch.ones((length, length), device=block.device, dtype=torch.bool).tril()
    )


def inputs(op, c, seed, pattern, device="cuda", assignment=None):
    import torch

    torch.manual_seed(seed)
    dtype = torch.float32 if op in ("elementwise_add", "rmsnorm") else torch.float16

    def rand(shape):
        x = torch.randn(shape, device=device, dtype=dtype)
        if pattern == "zeros":
            x.zero_()
        elif pattern == "scaled":
            x.mul_(3 if "attention" in op or "gqa" in op or op == "softmax" else 0.1)
        return x

    if op == "elementwise_add":
        a, b = rand((c["M"], c["N"])), rand((c["M"], c["N"]))
        return (a, b), a + b
    if op == "matmul_bias_relu":
        a, b, bias = rand((c["M"], c["K"])), rand((c["K"], c["N"])), rand((c["N"],))
        if pattern == "bias_only":
            a.zero_()
            bias.copy_(torch.linspace(-1, 1, c["N"], device=device, dtype=dtype))
        elif pattern == "relu_boundary":
            bias.copy_(-(a.float() @ b.float())[0].half())
        return (a, b, bias), torch.relu(a.float() @ b.float() + bias.float()).half()
    if op in ("softmax", "rmsnorm"):
        a = rand((c["M"], c["N"]))
        ref = (
            torch.softmax(a.float(), -1)
            if op == "softmax"
            else a.float()
            * torch.rsqrt(a.float().square().mean(-1, keepdim=True) + 1e-12)
        )
        return (a,), ref.to(dtype)
    if op == "gemv":
        a, x = rand((c["M"], c["N"])), rand((c["N"],))
        return (a, x), (a.float() @ x.float()).half()
    if op in ("gemm", "w4a16"):
        a = rand((c["M"], c["K"]))
        if op == "gemm":
            b = rand((c["K"], c["N"]))
            return (a, b), (a.float() @ b.float()).half()
        b = torch.randint(
            -128, 128, (c["N"], c["K"] // 2), device=device, dtype=torch.int8
        )
        return (a, b), (a.float() @ unpack(b).float().T).half()
    if op == "grouped_gemm":
        sizes = c["sizes"]
        a, b = rand((sum(sizes), c["K"])), rand((len(sizes), c["K"], c["N"]))
        offsets, padded = [0], [0]
        for s in sizes[:-1]:
            offsets.append(offsets[-1] + s)
            bm = (assignment or {}).get("BM", 64)
            padded.append(padded[-1] + (s + bm - 1) // bm * bm)
        meta = [
            torch.tensor(x, device=device, dtype=torch.int32)
            for x in (sizes, offsets, padded)
        ]
        ref = torch.cat(
            [
                (a[o : o + s].float() @ b[i].float()).half()
                for i, (o, s) in enumerate(zip(offsets, sizes, strict=True))
            ]
        )
        return (a, b, *meta), ref
    if op == "gqa_decode":
        from worker import gqa_inputs

        return gqa_inputs(
            c, seed, "extreme" if pattern == "scaled" else pattern, device
        )
    if op == "gqa_prefill":
        q = rand((c["B"], c["L"], c["Hq"], c["D"]))
        k, v = (
            rand((c["B"], c["L"], c["Hkv"], c["D"])),
            rand((c["B"], c["L"], c["Hkv"], c["D"])),
        )
        group = c["Hq"] // c["Hkv"]
        qr = q.float().transpose(1, 2)
        kr = k.float().repeat_interleave(group, 2).transpose(1, 2)
        vr = v.float().repeat_interleave(group, 2).transpose(1, 2)
        score = (qr @ kr.transpose(-1, -2)) * c["D"] ** -0.5
        if c["causal"]:
            score.masked_fill_(
                ~torch.ones((c["L"], c["L"]), device=device, dtype=torch.bool).tril(),
                -torch.inf,
            )
        return (q, k, v), (score.softmax(-1) @ vr).transpose(1, 2).half()
    if op == "cumsum":
        g = rand((c["B"], c["S"], c["H"]))
        chunk = 64
        ref = (
            g.float()
            .reshape(c["B"], c["S"] // chunk, chunk, c["H"])
            .cumsum(2)
            .reshape(c["B"], c["S"], c["H"])
        )
        return (g,), ref
    if op == "conv2d":
        data = rand((c["N"], c["H"], c["W"], c["C"]))
        weight = rand((c["K"], c["K"], c["C"], c["F"]))
        ref = torch.nn.functional.conv2d(
            data.permute(0, 3, 1, 2).float(),
            weight.permute(3, 2, 0, 1).float(),
            stride=c["S"],
            padding=c["P"],
            dilation=c["D"],
        ).permute(0, 2, 3, 1)
        return (data, weight), ref.to(dtype)
    if op == "block_sparse_attention":
        shape = (c["B"], c["heads"], c["L"], c["D"])
        q, k, v = rand(shape), rand(shape), rand(shape)
        block = sparse_mask(c, device)
        score = (q.float() @ k.float().transpose(-1, -2)) * c["D"] ** -0.5
        score.masked_fill_(~dense_mask(block, c["L"]), -torch.inf)
        return (q, k, v, block), (score.softmax(-1) @ v.float()).half()
    raise ValueError("Unregistered baseline semantics")


def torch_callable(op, c):
    import torch
    import torch.nn.functional as F

    if op == "elementwise_add":
        return torch.add
    if op == "softmax":
        return lambda a: torch.softmax(a, -1)
    if op == "rmsnorm":
        return lambda a: F.rms_norm(a, (c["N"],), eps=1e-12)
    if op == "gemv":
        return torch.mv
    if op == "gemm":
        return torch.matmul
    if op == "w4a16":
        return lambda a, b: a @ unpack(b).T
    if op == "grouped_gemm":
        offsets = [0]
        for s in c["sizes"][:-1]:
            offsets.append(offsets[-1] + s)
        return lambda a, b, *meta: torch.cat(
            [
                a[o : o + s] @ b[i]
                for i, (o, s) in enumerate(zip(offsets, c["sizes"], strict=True))
            ]
        )
    if op == "gqa_prefill":
        return lambda q, k, v: F.scaled_dot_product_attention(
            q.transpose(1, 2),
            k.transpose(1, 2),
            v.transpose(1, 2),
            is_causal=c["causal"],
            enable_gqa=True,
        ).transpose(1, 2)
    if op == "gqa_decode":
        # This suite freezes all-visible mask metadata; no-mask SDPA is equivalent.
        return lambda q, k, v, mask: F.scaled_dot_product_attention(
            q.unsqueeze(2), k.transpose(1, 2), v.transpose(1, 2), enable_gqa=True
        ).squeeze(2)
    if op == "block_sparse_attention":
        # Metadata mask is invariant. Expand before timing, as declared by workload.
        expanded = dense_mask(sparse_mask(c, "cuda"), c["L"])
        return lambda q, k, v, mask: F.scaled_dot_product_attention(
            q, k, v, attn_mask=expanded
        )
    raise ValueError("Unknown torch baseline")


def run(payload, props):
    import torch

    source = payload["source"]
    Path("candidate.py").write_text(source)
    spec = importlib.util.spec_from_file_location(
        "candidate", Path("candidate.py").resolve()
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    op = payload["workload"]["operator"]
    for c in payload["workload"]["cases"]:
        row = {"case": c["name"], "status": "failed"}
        rows.append(row)
        stage = "build"
        try:
            start = time.monotonic()
            kernel = module.build(c, payload["assignment"])
            row["build_seconds"] = time.monotonic() - start
            if op == "matmul_bias_relu":
                row.update(kernel.artifact_manifest(c["name"]))
            elif payload["provider"] == "tilelang":
                cuda = kernel.get_kernel_source()
                Path(c["name"] + ".cu").write_text(cuda)
                library = getattr(kernel.adapter, "libpath", None)
                if not library:
                    library = getattr(
                        getattr(kernel.adapter, "lib_generator", None), "libpath", None
                    )
                if not library:
                    cache = getattr(kernel, "_tilelang_cache_path", None)
                    if cache:
                        library = Path(cache) / "executable.so"
                    else:
                        executable = getattr(kernel.adapter, "executable", None)
                        if executable is None and hasattr(
                            kernel.adapter, "get_exportable_executable"
                        ):
                            executable = kernel.adapter.get_exportable_executable()
                        if executable is None:
                            raise ValueError("Compiled library identity unavailable")
                        library = Path(c["name"] + "-executable.so")
                        executable.export_library(str(library))
                row.update(
                    cuda_source=cuda,
                    cuda_sha256=hashlib.sha256(cuda.encode()).hexdigest(),
                    binary_sha256=hashlib.sha256(
                        Path(library).read_bytes()
                    ).hexdigest(),
                )
                from worker import compiler_metadata

                row["compiler_metadata"] = compiler_metadata(kernel, c["name"])
                row["lowering_observations"] = {
                    "source_pipelined_loop": "T.Pipelined" in source,
                    "stage_controls": {
                        k: payload["assignment"][k]
                        for k in ("stages", "num_stages")
                        if type(payload["assignment"].get(k)) is int
                    },
                    "async_copy_tokens_seen": any(
                        token in cuda for token in ("cp_async", "cp.async", "tma_load")
                    ),
                    "limits": "Textual CUDA observations only; no instruction trace or proof of overlap. Control-name matching is limited to stages/num_stages.",
                }
            else:
                row["artifact_scope"] = (
                    "Torch library callable; wrapper hash and library versions, no fabricated device binary identity. SDPA default dispatch, not forced cuDNN/Flash."
                )
            if payload["phase"] == "compile":
                row["status"] = "compiled"
                continue
            stage = "finite_check"
            checks = []
            patterns = [(17, "random"), (29, "zeros"), (41, "scaled")]
            if op == "matmul_bias_relu":
                patterns += [(43, "bias_only"), (47, "relu_boundary")]
            for seed, pattern in patterns:
                args, ref = inputs(
                    op, c, seed, pattern, assignment=payload["assignment"]
                )
                if payload["assignment"]["recipe"] == "sparse_int32_mask":
                    args = (*args[:-1], args[-1].to(torch.int32))
                if payload["assignment"]["recipe"] == "gemv_thread":
                    args = (args[1], args[0])
                actual = kernel(*args)
                torch.cuda.synchronize()
                atol = 1e-4 if op == "softmax" else 0.01
                rtol = 1e-4 if ref.dtype == torch.float32 else 0.01
                passed = (
                    actual.shape == ref.shape
                    and actual.dtype == ref.dtype
                    and bool(torch.isfinite(actual).all())
                    and torch.allclose(actual, ref, rtol=rtol, atol=atol)
                )
                checks.append(
                    {
                        "seed": seed,
                        "pattern": pattern,
                        "passed": bool(passed),
                        "max_abs_error": float(
                            (actual.float() - ref.float()).abs().max()
                        ),
                        "atol": atol,
                        "rtol": rtol,
                    }
                )
            row["checks"] = checks
            row["correct"] = all(x["passed"] for x in checks)
            if not row["correct"]:
                row["status"] = "incorrect"
                continue
            if payload["phase"] == "check":
                row["status"] = "checked"
                continue
            args, _ = inputs(op, c, 17, "random", assignment=payload["assignment"])
            stage = "timing"
            if payload["assignment"]["recipe"] == "sparse_int32_mask":
                args = (*args[:-1], args[-1].to(torch.int32))
            if payload["assignment"]["recipe"] == "gemv_thread":
                args = (args[1], args[0])
            for _ in range(10):
                kernel(*args)
            if op == "matmul_bias_relu":
                # TVM's pool must already contain enough output allocations
                # for the complete capture; cudaMalloc is forbidden in capture.
                import gc

                pool_warmup = [kernel(*args) for _ in range(32)]
                torch.cuda.synchronize()
                del pool_warmup
                gc.collect()
            torch.cuda.synchronize()
            graph = torch.cuda.CUDAGraph()
            captured_outputs = []
            with torch.cuda.graph(graph):
                for _ in range(30):
                    if op == "matmul_bias_relu":
                        captured_outputs.append(kernel(*args))
                    else:
                        kernel(*args)
            graph.replay()
            torch.cuda.synchronize()
            if op == "matmul_bias_relu":
                # Detect wrong-stream / empty capture: replay must recompute
                # outputs after changing the inputs at the captured addresses.
                probe_args, probe_ref = inputs(op, c, 53, "random")
                for dst, src in zip(args, probe_args, strict=True):
                    dst.copy_(src)
                graph.replay()
                torch.cuda.synchronize()
                replay_ok = torch.allclose(
                    captured_outputs[-1], probe_ref, rtol=0.01, atol=0.01
                )
                row["capture_replay_check"] = {
                    "changed_input_seed": 53,
                    "passed": bool(replay_ok),
                }
                if not replay_ok:
                    raise ValueError(
                        "CUDA graph replay failed changed-input check; timing rejected"
                    )
                timed_args, _ = inputs(op, c, 17, "random")
                for dst, src in zip(args, timed_args, strict=True):
                    dst.copy_(src)
                graph.replay()
                torch.cuda.synchronize()
            samples = []
            for _ in range(7):
                start, stop = (
                    torch.cuda.Event(enable_timing=True),
                    torch.cuda.Event(enable_timing=True),
                )
                start.record()
                graph.replay()
                stop.record()
                stop.synchronize()
                samples.append(start.elapsed_time(stop) * 1000 / 30)
            row.update(
                status="measured",
                latency_us=statistics.median(samples),
                samples_us=samples,
                timing="cuda-event-graph-replay-v1",
                warmup=10,
                callable_invocations_per_sample=30,
                timed_seed=17,
                timed_pattern="random",
            )
        except Exception as error:
            detail = f"{type(error).__name__}: {error}"
            full = traceback.format_exc()
            print(full, file=sys.stderr)
            error_file = c["name"] + "-error.log"
            Path(error_file).write_text(full)
            row.update(
                failure_stage=stage,
                error_type=type(error).__name__,
                error=detail
                if len(detail) <= 12000
                else detail[:6000] + "\n[... middle omitted ...]\n" + detail[-6000:],
                error_file=error_file,
                error_sha256=hashlib.sha256(full.encode()).hexdigest(),
                full_error_in="remote-stderr.log",
            )
            # A failed CUDA launch may poison the process. One case per job is used.
    driver = subprocess.run(
        ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
        capture_output=True,
        text=True,
        timeout=10,
        check=True,
    ).stdout.strip()
    return {
        "phase": payload["phase"],
        "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
        "assignment": payload["assignment"],
        "cases": rows,
        "job_directory": str(Path.cwd()),
        "environment": {
            "hostname": os.uname().nodename,
            "gpu": props.name,
            "sms": props.multi_processor_count,
            "compute_capability": f"{props.major}.{props.minor}",
            "tilelang": importlib.metadata.version("tilelang"),
            "torch": torch.__version__,
            "driver": driver,
            "python": sys.version,
            "worker_sha256": hashlib.sha256(Path("worker.py").read_bytes()).hexdigest(),
            "baseline_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        },
    }
