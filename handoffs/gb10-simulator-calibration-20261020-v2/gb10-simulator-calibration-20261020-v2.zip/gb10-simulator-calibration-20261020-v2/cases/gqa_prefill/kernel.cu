#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void main_kernel(__grid_constant__ const CUtensorMap K_desc, __grid_constant__ const CUtensorMap Output_desc, __grid_constant__ const CUtensorMap Q_desc, __grid_constant__ const CUtensorMap V_desc);
extern "C" __global__ void __launch_bounds__(256, 1) main_kernel(__grid_constant__ const CUtensorMap K_desc, __grid_constant__ const CUtensorMap Output_desc, __grid_constant__ const CUtensorMap Q_desc, __grid_constant__ const CUtensorMap V_desc) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* O_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* Q_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* K_shared = ((void*)((char*)buf_dyn_shmem + 16384));
  void* V_shared = ((void*)((char*)buf_dyn_shmem + 32768));
  __shared__ __align__(16) uint64_t mbarrier_mem[5];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float acc_o[64];
  float logsum[2];
  float scores_max[2];
  float acc_s[32];
  float scores_max_prev[2];
  float scores_max_clear[2];
  float scores_scale[2];
  float scores_sum[2];
  half_t acc_s_cast[32];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(Q_desc);
    tl::prefetch_tma_descriptor(K_desc);
    tl::prefetch_tma_descriptor(V_desc);
    tl::prefetch_tma_descriptor(Output_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(128);
    mbarrier[3].init(128);
    mbarrier[4].init(1);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (tl::tl_shuffle_elect<256>()) {
    mbarrier[4].arrive_and_expect_tx(16384);
    #pragma unroll
    for (int i = 0; i < 2; ++i) {
      tl::tma_load(Q_desc, mbarrier[4], (&(((half_t*)Q_shared)[(i * 4096)])), (i * 64), (((int)blockIdx.x) * 64), ((int)blockIdx.y), 0);
    }
  }
  __syncthreads();
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    for (int k = 0; k < (((int)blockIdx.x) + 1); ++k) {
      mbarrier[2].wait(((k & 1) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[0].arrive_and_expect_tx(16384);
        #pragma unroll
        for (int i_1 = 0; i_1 < 2; ++i_1) {
          tl::tma_load(K_desc, mbarrier[0], (&(((half_t*)K_shared)[(i_1 * 4096)])), (i_1 * 64), (k * 64), (((int)blockIdx.y) >> 2), 0);
        }
      }
      mbarrier[3].wait(((k & 1) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[1].arrive_and_expect_tx(16384);
        #pragma unroll
        for (int i_2 = 0; i_2 < 2; ++i_2) {
          tl::tma_load(V_desc, mbarrier[1], (&(((half_t*)V_shared)[(i_2 * 4096)])), (i_2 * 64), (k * 64), (((int)blockIdx.y) >> 2), 0);
        }
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i_3 = 0; i_3 < 16; ++i_3) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(acc_o + (i_3 * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
    *(float2*)(logsum + 0) = make_float2(broadcast_var_1, broadcast_var_1);
    float broadcast_var_2 = -CUDART_INF_F;
    *(float2*)(scores_max + 0) = make_float2(broadcast_var_2, broadcast_var_2);
    for (int k_1 = 0; k_1 < (((int)blockIdx.x) + 1); ++k_1) {
      #pragma unroll
      for (int i_4 = 0; i_4 < 32; ++i_4) {
        float condval;
        if (((((((k_1 * 64) + ((i_4 >> 2) * 8)) + ((((int)threadIdx.x) & 3) * 2)) + (i_4 & 1)) + 64) <= ((((((int)blockIdx.x) * 64) + ((((int)threadIdx.x) >> 5) * 16)) + (((i_4 & 3) >> 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)))) {
          condval = 0x0p+0f/*0.000000e+00*/;
        } else {
          condval = -CUDART_INF_F;
        }
        acc_s[i_4] = condval;
      }
      if (k_1 == 0) {
        mbarrier[4].wait(0);
      }
      mbarrier[0].wait((k_1 & 1));
      {
        half_t A_local[8];
        half_t B_local[32];
        for (int ki = 0; ki < 8; ++ki) {
          tl::ptx_ldmatrix_x4((&(((half_t*)Q_shared)[(((((((ki >> 2) * 4096) + (((((int)threadIdx.x) & 127) >> 5) * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[0])));
          #pragma unroll
          for (int i_5 = 0; i_5 < 4; ++i_5) {
            tl::ptx_ldmatrix_x4((&(((half_t*)K_shared)[((((((((ki >> 2) * 4096) + (i_5 * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[(i_5 * 8)])));
          }
          for (int j = 0; j < 4; ++j) {
            tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_s + (j * 8)), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local + (j * 8)));
            tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_s + ((j * 8) + 4)), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local + ((j * 8) + 4)));
          }
        }
      }
      mbarrier[2].arrive();
      *(float2*)(scores_max_prev + 0) = *(float2*)(scores_max + 0);
      float broadcast_var_3 = -CUDART_INF_F;
      *(float2*)(scores_max + 0) = make_float2(broadcast_var_3, broadcast_var_3);
      #pragma unroll
      for (int i_6 = 0; i_6 < 2; ++i_6) {
        scores_max_clear[i_6] = -CUDART_INF_F;
        #pragma unroll
        for (int rv = 0; rv < 16; ++rv) {
          scores_max_clear[i_6] = max(scores_max_clear[i_6], acc_s[((((rv & 7) * 4) + (i_6 * 2)) + (rv >> 3))]);
        }
        scores_max_clear[i_6] = tl::AllReduce<tl::MaxOp, 4, 1, 128, tl::NamedBarrier<128>>::run(scores_max_clear[i_6]);
        scores_max[i_6] = max(scores_max[i_6], scores_max_clear[i_6]);
      }
      float2 __1;
        float2 v_ = *(float2*)(scores_max + 0);
        float2 v__1 = *(float2*)(scores_max_prev + 0);
        *(float2*)(&(__1.x)) = tl::max2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
      *(float2*)(scores_max + 0) = __1;
      float broadcast_var_4 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
      float broadcast_var_5 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
      float2 __2;
      float2 __3;
        float2 __4;
          float2 v__2 = *(float2*)(scores_max_prev + 0);
          float2 v__3 = make_float2(broadcast_var_4, broadcast_var_4);
          *(float2*)(&(__4.x)) = tl::mul2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
        float2 __5;
          float2 v__4 = *(float2*)(scores_max + 0);
          float2 v__5 = make_float2(broadcast_var_5, broadcast_var_5);
          *(float2*)(&(__5.x)) = tl::mul2(*(float2*)(&(v__4.x)), *(float2*)(&(v__5.x)));
        *(float2*)(&(__3.x)) = tl::sub2(*(float2*)(&(__4.x)), *(float2*)(&(__5.x)));
      __2.x = exp2f(__3.x);
      __2.y = exp2f(__3.y);
      *(float2*)(scores_scale + 0) = __2;
      #pragma unroll
      for (int i_7 = 0; i_7 < 16; ++i_7) {
        float broadcast_var_6 = 0x1.0527dbd5cafffp-3f/*1.275174e-01*/;
        float2 __6;
        float2 __7;
          float2 __8;
            float2 v__6 = *(float2*)(acc_s + (i_7 * 2));
            float2 v__7 = make_float2(broadcast_var_6, broadcast_var_6);
            *(float2*)(&(__8.x)) = tl::mul2(*(float2*)(&(v__6.x)), *(float2*)(&(v__7.x)));
          float2 v__8 = make_float2((scores_max[(i_7 & 1)] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/), (scores_max[(i_7 & 1)] * 0x1.0527dbd5cafffp-3f/*1.275174e-01*/));
          *(float2*)(&(__7.x)) = tl::sub2(*(float2*)(&(__8.x)), *(float2*)(&(v__8.x)));
        __6.x = exp2f(__7.x);
        __6.y = exp2f(__7.y);
        *(float2*)(acc_s + (i_7 * 2)) = __6;
      }
      #pragma unroll
      for (int i_8 = 0; i_8 < 2; ++i_8) {
        scores_sum[i_8] = 0x0p+0f/*0.000000e+00*/;
        #pragma unroll
        for (int rv_1 = 0; rv_1 < 16; ++rv_1) {
          scores_sum[i_8] = (scores_sum[i_8] + acc_s[((((rv_1 & 7) * 4) + (i_8 * 2)) + (rv_1 >> 3))]);
        }
        scores_sum[i_8] = tl::AllReduce<tl::SumOp, 4, 1, 128, tl::NamedBarrier<128>>::run(scores_sum[i_8]);
      }
      float2 __9;
        float2 v__9 = *(float2*)(logsum + 0);
        float2 v__10 = *(float2*)(scores_scale + 0);
        float2 v__11 = *(float2*)(scores_sum + 0);
        *(float2*)(&(__9.x)) = tl::fma2(*(float2*)(&(v__9.x)), *(float2*)(&(v__10.x)), *(float2*)(&(v__11.x)));
      *(float2*)(logsum + 0) = __9;
      #pragma unroll
      for (int i_9 = 0; i_9 < 8; ++i_9) {
        uint2 __10;
        float4 v__12 = *(float4*)(acc_s + (i_9 * 4));
        ((half2*)(&__10))[0] = __float22half2_rn(((float2*)(&v__12))[0]);
        ((half2*)(&__10))[1] = __float22half2_rn(((float2*)(&v__12))[1]);
        *(uint2*)(acc_s_cast + (i_9 * 4)) = __10;
      }
      #pragma unroll
      for (int i_10 = 0; i_10 < 32; ++i_10) {
        float2 __11;
          float2 v__13 = *(float2*)(acc_o + (i_10 * 2));
          float2 v__14 = make_float2(scores_scale[(i_10 & 1)], scores_scale[(i_10 & 1)]);
          *(float2*)(&(__11.x)) = tl::mul2(*(float2*)(&(v__13.x)), *(float2*)(&(v__14.x)));
        *(float2*)(acc_o + (i_10 * 2)) = __11;
      }
      mbarrier[1].wait((k_1 & 1));
      {
        half_t B_local_1[64];
        for (int ki_1 = 0; ki_1 < 4; ++ki_1) {
          #pragma unroll
          for (int i_11 = 0; i_11 < 8; ++i_11) {
            tl::ptx_ldmatrix_x4_trans((&(((half_t*)V_shared)[(((((((i_11 >> 2) * 4096) + (ki_1 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((i_11 & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (i_11 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_1[(i_11 * 8)])));
          }
          for (int j_1 = 0; j_1 < 8; ++j_1) {
            tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_o + (j_1 * 8)), reinterpret_cast<const unsigned*>(acc_s_cast + (ki_1 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + (j_1 * 8)));
            tl::mma_sync<tl::DataType::kFloat16, tl::DataType::kFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc_o + ((j_1 * 8) + 4)), reinterpret_cast<const unsigned*>(acc_s_cast + (ki_1 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + ((j_1 * 8) + 4)));
          }
        }
      }
      mbarrier[3].arrive();
    }
    #pragma unroll
    for (int i_12 = 0; i_12 < 32; ++i_12) {
      float2 __12;
        float2 v__15 = *(float2*)(acc_o + (i_12 * 2));
        float2 v__16 = make_float2(logsum[(i_12 & 1)], logsum[(i_12 & 1)]);
        __12.x = (v__15.x/v__16.x);
        __12.y = (v__15.y/v__16.y);
      *(float2*)(acc_o + (i_12 * 2)) = __12;
    }
    tl::__sync_thread_partial(3, 128);
    #pragma unroll
    for (int i_13 = 0; i_13 < 8; ++i_13) {
      tl::ptx_stmatrix_m8n8_x4((&(((half_t*)O_shared)[((((((((i_13 >> 2) * 4096) + ((((int)threadIdx.x) >> 5) * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((i_13 & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (i_13 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) - 4096)])), __pack_half2(((half_t)acc_o[(i_13 * 8)]), ((half_t)acc_o[((i_13 * 8) + 1)])), __pack_half2(((half_t)acc_o[((i_13 * 8) + 2)]), ((half_t)acc_o[((i_13 * 8) + 3)])), __pack_half2(((half_t)acc_o[((i_13 * 8) + 4)]), ((half_t)acc_o[((i_13 * 8) + 5)])), __pack_half2(((half_t)acc_o[((i_13 * 8) + 6)]), ((half_t)acc_o[((i_13 * 8) + 7)])));
    }
    tl::__sync_thread_partial(3, 128);
    if (tl::tl_shuffle_elect<128>()) {
      tl::fence_proxy_async();
      #pragma unroll
      for (int i_14 = 0; i_14 < 2; ++i_14) {
        tl::tma_store(Output_desc, (&(((half_t*)O_shared)[(i_14 * 4096)])), (i_14 * 64), (((int)blockIdx.x) * 64), ((int)blockIdx.y), 0);
      }
      tl::tma_store_arrive();
      tl::tma_store_wait<0, true>();
    }
  }
}

